package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Tune
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Discount
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BookingEntity
import com.example.data.model.CustomerPaymentEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.InventoryItemEntity
import com.example.data.model.JsonHelper
import com.example.data.model.OrderEntity
import com.example.data.model.PurchaseEntity
import com.example.ui.DatePreset
import com.example.ui.MainViewModel
import com.example.ui.PartySummary
import com.example.ui.ReportCategoryTab
import com.example.ui.components.MonthlySalesVsProfitChart
import com.example.ui.components.PaymentModesDoughnutChart
import com.example.ui.theme.SoePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VyaparAmber
import com.example.ui.theme.VyaparBlue
import com.example.ui.theme.VyaparDarkGreen
import com.example.ui.theme.VyaparGreen

@Composable
fun ReportsAnalyticsScreen(
  viewModel: MainViewModel,
  bookings: List<BookingEntity>,
  inventoryItems: List<InventoryItemEntity>,
  purchases: List<PurchaseEntity>,
  expenses: List<ExpenseEntity>,
  payments: List<CustomerPaymentEntity>,
  orders: List<OrderEntity>,
  datePreset: DatePreset,
  categoryTab: ReportCategoryTab,
  paymentFilter: String,
  searchQuery: String,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  // Advanced Dashboard Filter States from ViewModel
  val appLanguage by viewModel.appLanguage.collectAsStateWithLifecycle()
  val dbBookingStatus by viewModel.dashboardBookingStatus.collectAsStateWithLifecycle()
  val dbPaymentStatus by viewModel.dashboardPaymentStatus.collectAsStateWithLifecycle()
  val dbCustQuery by viewModel.dashboardCustomerQuery.collectAsStateWithLifecycle()
  val dbBookingIdQuery by viewModel.dashboardBookingIdQuery.collectAsStateWithLifecycle()
  val dbEventDateQuery by viewModel.dashboardEventDateQuery.collectAsStateWithLifecycle()
  val dbPayTypeFilter by viewModel.dashboardPaymentTypeFilter.collectAsStateWithLifecycle()
  val isFilterExpanded by viewModel.isDashboardFilterExpanded.collectAsStateWithLifecycle()

  // Filtered sales
  val filteredBookings = remember(
    bookings, paymentFilter, searchQuery,
    dbBookingStatus, dbPaymentStatus, dbCustQuery, dbBookingIdQuery, dbEventDateQuery, dbPayTypeFilter, datePreset
  ) {
    bookings.filter { b ->
      val effectivePayFilter = if (dbPayTypeFilter != "ALL") dbPayTypeFilter else paymentFilter
      val matchesMode = when (effectivePayFilter) {
        "UPI" -> b.paymentMode == "UPI"
        "CASH" -> b.paymentMode == "CASH"
        "CREDIT" -> b.paymentMode == "CREDIT" || b.balanceDue > 0
        "BANK" -> b.paymentMode == "BANK"
        else -> true
      }
      val matchesBookingStatus = when (dbBookingStatus) {
        "CONFIRMED" -> b.status == "CONFIRMED"
        "COMPLETED" -> b.status == "COMPLETED" || (b.status == "PAYMENT-IN" && b.balanceDue == 0.0)
        "CANCELLED" -> b.status == "CANCELLED"
        "PENDING" -> b.balanceDue > 0 && b.status != "CANCELLED"
        else -> true
      }
      val matchesPaymentStatus = when (dbPaymentStatus) {
        "PAID" -> b.balanceDue == 0.0
        "PENDING" -> b.balanceDue > 0.0
        "PARTIAL" -> b.advancePaid > 0.0 && b.balanceDue > 0.0
        else -> true
      }
      val matchesCust = dbCustQuery.isBlank() || b.customerName.contains(dbCustQuery, ignoreCase = true)
      val matchesBId = dbBookingIdQuery.isBlank() || b.id.toString().contains(dbBookingIdQuery) || b.invoiceNumber.contains(dbBookingIdQuery, ignoreCase = true)
      val matchesEventDate = dbEventDateQuery.isBlank() || b.eventDate.contains(dbEventDateQuery) || b.formattedDate.contains(dbEventDateQuery)

      val matchesQuery = b.customerName.contains(searchQuery, ignoreCase = true) ||
        b.invoiceNumber.contains(searchQuery, ignoreCase = true) ||
        b.eventType.contains(searchQuery, ignoreCase = true)

      matchesMode && matchesBookingStatus && matchesPaymentStatus && matchesCust && matchesBId && matchesEventDate && matchesQuery
    }
  }

  // Analytics Totals
  val totalSales = remember(filteredBookings) { filteredBookings.sumOf { it.totalAmount } }
  val totalSalesCost = remember(filteredBookings) { filteredBookings.sumOf { it.estimatedCost } }
  val netProfit = (totalSales - totalSalesCost).coerceAtLeast(0.0)
  val margin = if (totalSales > 0) ((netProfit / totalSales) * 100).toInt() else 0

  val totalPurchases = remember(purchases) { purchases.sumOf { it.totalAmount } }
  val totalExpenses = remember(expenses) { expenses.sumOf { it.amount } }
  val totalCustomerPaymentsIn = remember(payments) { payments.filter { it.paymentType == "PAYMENT_IN" }.sumOf { it.amount } }

  val totalUpi = remember(filteredBookings) { filteredBookings.filter { it.paymentMode == "UPI" }.sumOf { it.totalAmount } }
  val totalCash = remember(filteredBookings) { filteredBookings.filter { it.paymentMode == "CASH" }.sumOf { it.totalAmount } }
  val totalCredit = remember(filteredBookings) { filteredBookings.filter { it.paymentMode == "CREDIT" || it.balanceDue > 0 }.sumOf { it.balanceDue } }

  // Sub-navigation selector within ReportCategoryTab
  var selectedSubReport by remember { mutableStateOf("SUMMARY") }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp, vertical = 6.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Pro Header with Excel & Print buttons
    item {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = VyaparBlue,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "Sales, Accounts & Reports",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                  modifier = Modifier
                    .background(VyaparAmber, RoundedCornerShape(10.dp))
                    .padding(horizontal = 6.dp, vertical = 1.dp)
                ) {
                  Text(
                    text = "PRO",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Black
                  )
                }
              }
              Text(
                text = "SHREE OM EVENT UMARIA",
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFFE2E8F0)
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              IconButton(
                onClick = { viewModel.exportCsv(context) },
                modifier = Modifier
                  .size(34.dp)
                  .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                  .testTag("export_excel_button")
              ) {
                Icon(
                  imageVector = Icons.Default.FileDownload,
                  contentDescription = "Excel Export",
                  tint = Color.White,
                  modifier = Modifier.size(18.dp)
                )
              }

              IconButton(
                onClick = { viewModel.showToast("Print report generated successfully!") },
                modifier = Modifier
                  .size(34.dp)
                  .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                  .testTag("print_summary_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Print,
                  contentDescription = "Print Summary",
                  tint = Color.White,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Date Range Presets Row
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            val presets = listOf(
              DatePreset.TODAY to "Today",
              DatePreset.YESTERDAY to "Yesterday",
              DatePreset.THIS_WEEK to "This Week",
              DatePreset.THIS_MONTH to "This Month",
              DatePreset.LAST_MONTH to "Last Month",
              DatePreset.THIS_YEAR to "This Year",
              DatePreset.FY to "Fiscal Year (FY)"
            )

            presets.forEach { (preset, label) ->
              val isSelected = datePreset == preset
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(16.dp))
                  .background(if (isSelected) Color.White else Color.White.copy(alpha = 0.2f))
                  .clickable { viewModel.setDashboardDatePreset(preset) }
                  .padding(horizontal = 10.dp, vertical = 5.dp)
              ) {
                Text(
                  text = label,
                  fontSize = 11.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                  color = if (isSelected) VyaparBlue else Color.White
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Advanced Filter Toggle Button
          val activeFilterCount = (if (dbBookingStatus != "ALL") 1 else 0) +
            (if (dbPaymentStatus != "ALL") 1 else 0) +
            (if (dbPayTypeFilter != "ALL") 1 else 0) +
            (if (dbCustQuery.isNotBlank()) 1 else 0) +
            (if (dbBookingIdQuery.isNotBlank()) 1 else 0) +
            (if (dbEventDateQuery.isNotBlank()) 1 else 0)

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(Color.White.copy(alpha = 0.15f))
              .clickable { viewModel.toggleDashboardFilterExpanded() }
              .padding(horizontal = 10.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Icon(imageVector = Icons.Default.FilterList, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
              Text(
                text = if (isFilterExpanded) "Hide Advanced Filter ▲" else "Open Advanced Filter ▼",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
            if (activeFilterCount > 0) {
              Box(
                modifier = Modifier
                  .background(VyaparAmber, RoundedCornerShape(10.dp))
                  .padding(horizontal = 7.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "$activeFilterCount Active Filters",
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.Black
                )
              }
            }
          }

          // Expandable Advanced Filter Panel
          if (isFilterExpanded) {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color.White,
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Text(text = "Booking Status:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  listOf("ALL" to "All", "CONFIRMED" to "Confirmed", "COMPLETED" to "Completed", "PENDING" to "Pending Due", "CANCELLED" to "Cancelled").forEach { (code, label) ->
                    val isSel = dbBookingStatus == code
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) VyaparBlue else Color(0xFFF1F5F9))
                        .clickable {
                          viewModel.setDashboardFilterParams(
                            preset = datePreset,
                            fromDate = "",
                            toDate = "",
                            bStatus = code,
                            pStatus = dbPaymentStatus,
                            custQuery = dbCustQuery,
                            bIdQuery = dbBookingIdQuery,
                            eventDate = dbEventDateQuery,
                            payType = dbPayTypeFilter
                          )
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                      Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else TextPrimary)
                    }
                  }
                }

                Text(text = "Payment Status:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  listOf("ALL" to "All", "PAID" to "Paid in Full", "PENDING" to "Pending Due", "PARTIAL" to "Partial").forEach { (code, label) ->
                    val isSel = dbPaymentStatus == code
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) VyaparGreen else Color(0xFFF1F5F9))
                        .clickable {
                          viewModel.setDashboardFilterParams(
                            preset = datePreset,
                            fromDate = "",
                            toDate = "",
                            bStatus = dbBookingStatus,
                            pStatus = code,
                            custQuery = dbCustQuery,
                            bIdQuery = dbBookingIdQuery,
                            eventDate = dbEventDateQuery,
                            payType = dbPayTypeFilter
                          )
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                      Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else TextPrimary)
                    }
                  }
                }

                Text(text = "Payment Mode:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  listOf("ALL" to "All Modes", "UPI" to "UPI", "CASH" to "CASH", "CREDIT" to "CREDIT", "BANK" to "BANK").forEach { (mode, label) ->
                    val isSel = dbPayTypeFilter == mode
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) Color(0xFF4338CA) else Color(0xFFF1F5F9))
                        .clickable {
                          viewModel.setDashboardFilterParams(
                            preset = datePreset,
                            fromDate = "",
                            toDate = "",
                            bStatus = dbBookingStatus,
                            pStatus = dbPaymentStatus,
                            custQuery = dbCustQuery,
                            bIdQuery = dbBookingIdQuery,
                            eventDate = dbEventDateQuery,
                            payType = mode
                          )
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                      Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else TextPrimary)
                    }
                  }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  OutlinedTextField(
                    value = dbCustQuery,
                    onValueChange = { q ->
                      viewModel.setDashboardFilterParams(
                        preset = datePreset,
                        fromDate = "",
                        toDate = "",
                        bStatus = dbBookingStatus,
                        pStatus = dbPaymentStatus,
                        custQuery = q,
                        bIdQuery = dbBookingIdQuery,
                        eventDate = dbEventDateQuery,
                        payType = dbPayTypeFilter
                      )
                    },
                    label = { Text("Customer Name", fontSize = 10.sp) },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                  )

                  OutlinedTextField(
                    value = dbBookingIdQuery,
                    onValueChange = { q ->
                      viewModel.setDashboardFilterParams(
                        preset = datePreset,
                        fromDate = "",
                        toDate = "",
                        bStatus = dbBookingStatus,
                        pStatus = dbPaymentStatus,
                        custQuery = dbCustQuery,
                        bIdQuery = q,
                        eventDate = dbEventDateQuery,
                        payType = dbPayTypeFilter
                      )
                    },
                    label = { Text("Booking ID / Bill #", fontSize = 10.sp) },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                  )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  Button(
                    onClick = { viewModel.toggleDashboardFilterExpanded() },
                    colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                  ) {
                    Text(text = "Apply Filter (${filteredBookings.size} Results)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }

                  OutlinedButton(
                    onClick = { viewModel.resetDashboardFilters() },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(0.6f)
                  ) {
                    Text(text = "Reset", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }
        }
      }
    }

    // 2. Main Module Navigator
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        val modules = listOf(
          ReportCategoryTab.OVERVIEW to "📊 Dashboard Overview",
          ReportCategoryTab.DAY_BOOK to "📖 Day Book",
          ReportCategoryTab.ALL_TXN to "💳 All Transactions",
          ReportCategoryTab.BILL_PROFIT to "🏷️ Bill-Wise Profit",
          ReportCategoryTab.PNL to "📈 Profit & Loss (P&L)",
          ReportCategoryTab.CASHFLOW to "💵 Cashflow",
          ReportCategoryTab.BALANCE_SHEET to "🏛️ Balance Sheet",
          ReportCategoryTab.TRIAL_BALANCE to "⚖️ Trial Balance",
          ReportCategoryTab.PARTY_REPORTS to "👥 Party Reports",
          ReportCategoryTab.STOCK_REPORTS to "📦 Stock / Item Reports",
          ReportCategoryTab.EXPENSE_REPORTS to "🧾 Expense Reports",
          ReportCategoryTab.PURCHASE_REPORTS to "🛒 Purchase Reports",
          ReportCategoryTab.PAYMENT_HISTORY to "💰 Payment History",
          ReportCategoryTab.ORDERS_REPORT to "📋 Orders Report"
        )

        modules.forEach { (tab, title) ->
          val isSelected = categoryTab == tab
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(if (isSelected) VyaparBlue.copy(alpha = 0.12f) else Color.White)
              .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) VyaparBlue else Color(0xFFE2E8F0),
                shape = RoundedCornerShape(10.dp)
              )
              .clickable { viewModel.setReportCategoryTab(tab) }
              .padding(horizontal = 12.dp, vertical = 8.dp)
          ) {
            Text(
              text = title,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
              color = if (isSelected) VyaparBlue else TextSecondary
            )
          }
        }
      }
    }

    // 3. Dynamic Section Content depending on selected Report Category
    when (categoryTab) {
      ReportCategoryTab.OVERVIEW -> {
        // KPI Cards Grid (2x3)
        item {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              KpiCard(
                title = "Total Sales (Sale Report)",
                value = "₹ ${String.format("%,.2f", totalSales)}",
                subtext = "+18.4% vs previous",
                subtextColor = VyaparGreen,
                icon = Icons.Default.TrendingUp,
                iconBg = Color(0xFFDCFCE7),
                iconTint = VyaparGreen,
                modifier = Modifier.weight(1f),
                onClick = { viewModel.openFinancialSourceModal("TOTAL_SALES") }
              )

              KpiCard(
                title = "Net Profit",
                value = "₹ ${String.format("%,.2f", netProfit)}",
                subtext = "$margin% Margin",
                subtextColor = VyaparDarkGreen,
                icon = Icons.Default.AttachMoney,
                iconBg = Color(0xFFE0F2FE),
                iconTint = VyaparBlue,
                modifier = Modifier.weight(1f),
                onClick = { viewModel.openFinancialSourceModal("NET_PROFIT") }
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              KpiCard(
                title = "Total Purchases",
                value = "₹ ${String.format("%,.2f", totalPurchases)}",
                subtext = "${purchases.size} Bills Logged",
                subtextColor = TextSecondary,
                icon = Icons.Default.ShoppingCart,
                iconBg = Color(0xFFFEF3C7),
                iconTint = VyaparAmber,
                modifier = Modifier.weight(1f),
                onClick = { viewModel.openFinancialSourceModal("PURCHASES") }
              )

              KpiCard(
                title = "Total Expenses",
                value = "₹ ${String.format("%,.2f", totalExpenses)}",
                subtext = "${expenses.size} Expenses Recorded",
                subtextColor = TextSecondary,
                icon = Icons.Default.Receipt,
                iconBg = Color(0xFFFFE4E6),
                iconTint = SoePrimary,
                modifier = Modifier.weight(1f),
                onClick = { viewModel.openFinancialSourceModal("EXPENSES") }
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              KpiCard(
                title = "Pending Receivables",
                value = "₹ ${String.format("%,.2f", totalCredit)}",
                subtext = "Due from Customers",
                subtextColor = VyaparGreen,
                icon = Icons.Default.ArrowDownward,
                iconBg = Color(0xFFDCFCE7),
                iconTint = VyaparGreen,
                modifier = Modifier.weight(1f),
                onClick = { viewModel.openFinancialSourceModal("RECEIVABLES") }
              )

              KpiCard(
                title = "Stock Valuation",
                value = "₹ ${String.format("%,.2f", inventoryItems.sumOf { it.stock * it.purchaseCost })}",
                subtext = "${inventoryItems.size} Items in Stock",
                subtextColor = VyaparBlue,
                icon = Icons.Default.Inventory2,
                iconBg = Color(0xFFE0E7FF),
                iconTint = Color(0xFF4338CA),
                modifier = Modifier.weight(1f),
                onClick = { viewModel.openFinancialSourceModal("STOCK_VALUATION") }
              )
            }
          }
        }

        // Monthly Trend Chart
        item {
          Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(
                    text = "Monthly Sales & Profit Trend",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                  )
                  Text(
                    text = "Revenue (Blue) vs Net Profit (Green)",
                    fontSize = 10.sp,
                    color = TextSecondary
                  )
                }
                Box(
                  modifier = Modifier
                    .background(Color(0xFFE0F2FE), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(text = "2026", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
                }
              }

              Spacer(modifier = Modifier.height(10.dp))
              MonthlySalesVsProfitChart()
            }
          }
        }

        // Payment Modes Doughnut
        item {
          Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(
                text = "Payment Modes Breakdown",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Spacer(modifier = Modifier.height(10.dp))
              PaymentModesDoughnutChart(
                upiAmount = totalUpi,
                cashAmount = totalCash,
                creditAmount = totalCredit
              )
            }
          }
        }

        // Quick Entry Toolbar
        item {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFFF8FAFC),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = "Quick Entry Actions",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Spacer(modifier = Modifier.height(8.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Button(
                  onClick = { viewModel.openAddExpenseDialog() },
                  colors = ButtonDefaults.buttonColors(containerColor = SoePrimary),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("+ Add Expense", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                  onClick = { viewModel.openAddPurchaseDialog() },
                  colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("+ Add Purchase", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }

      ReportCategoryTab.DAY_BOOK -> {
        item {
          DayBookView(
            bookings = filteredBookings,
            expenses = expenses,
            purchases = purchases,
            payments = payments,
            onBookingClick = { viewModel.openInvoicePreview(it) },
            onExpenseClick = { viewModel.openExpenseDetail(it) },
            onPurchaseClick = { viewModel.openPurchaseDetail(it) },
            onPaymentClick = { viewModel.openPaymentReceipt(it) }
          )
        }
      }

      ReportCategoryTab.ALL_TXN -> {
        item {
          AllTransactionsView(
            bookings = filteredBookings,
            expenses = expenses,
            purchases = purchases,
            payments = payments,
            onBookingClick = { viewModel.openInvoicePreview(it) },
            onPurchaseClick = { viewModel.openPurchaseDetail(it) },
            onExpenseClick = { viewModel.openExpenseDetail(it) },
            onPaymentClick = { viewModel.openPaymentReceipt(it) }
          )
        }
      }

      ReportCategoryTab.BILL_PROFIT -> {
        item {
          BillWiseProfitView(bookings = filteredBookings, onBookingClick = { viewModel.openInvoicePreview(it) })
        }
      }

      ReportCategoryTab.PNL -> {
        item {
          ProfitAndLossView(
            totalSales = totalSales,
            totalSalesCost = totalSalesCost,
            totalExpenses = totalExpenses,
            totalPurchases = totalPurchases,
            netProfit = netProfit
          )
        }
      }

      ReportCategoryTab.CASHFLOW -> {
        item {
          CashflowView(
            totalUpi = totalUpi,
            totalCash = totalCash,
            totalExpenses = totalExpenses,
            totalPurchases = totalPurchases,
            paymentsIn = totalCustomerPaymentsIn
          )
        }
      }

      ReportCategoryTab.BALANCE_SHEET -> {
        item {
          BalanceSheetView(
            totalStockValue = inventoryItems.sumOf { it.stock * it.purchaseCost },
            receivables = totalCredit,
            bankBalance = totalUpi * 0.9,
            cashBalance = totalCash * 0.95,
            payables = purchases.sumOf { it.dueAmount }
          )
        }
      }

      ReportCategoryTab.TRIAL_BALANCE -> {
        item {
          TrialBalanceView(
            totalSales = totalSales,
            totalPurchases = totalPurchases,
            totalExpenses = totalExpenses,
            receivables = totalCredit,
            cashBank = totalUpi + totalCash
          )
        }
      }

      ReportCategoryTab.PARTY_REPORTS -> {
        item {
          PartyReportsView(
            bookings = bookings,
            onPartyClick = { viewModel.openPartyDetail(it) },
            onBookingClick = { viewModel.openInvoicePreview(it) }
          )
        }
      }

      ReportCategoryTab.STOCK_REPORTS -> {
        item {
          StockReportsView(
            items = inventoryItems,
            bookings = bookings,
            onItemClick = { viewModel.openItemDetail(it) }
          )
        }
      }

      ReportCategoryTab.EXPENSE_REPORTS -> {
        item {
          ExpenseReportsView(
            expenses = expenses,
            onAddExpenseClick = { viewModel.openAddExpenseDialog() },
            onExpenseClick = { viewModel.openExpenseDetail(it) }
          )
        }
      }

      ReportCategoryTab.PURCHASE_REPORTS -> {
        item {
          PurchaseReportsView(
            purchases = purchases,
            onAddPurchaseClick = { viewModel.openAddPurchaseDialog() },
            onPurchaseClick = { viewModel.openPurchaseDetail(it) }
          )
        }
      }

      ReportCategoryTab.PAYMENT_HISTORY -> {
        item {
          PaymentHistoryView(
            payments = payments,
            onRecordPaymentClick = { viewModel.openRecordPaymentDialog() },
            onPaymentClick = { viewModel.openPaymentReceipt(it) }
          )
        }
      }

      ReportCategoryTab.ORDERS_REPORT -> {
        item {
          OrdersReportView(
            orders = orders,
            onAddOrderClick = { viewModel.openAddOrderDialog() },
            onOrderClick = { viewModel.openOrderDetail(it) }
          )
        }
      }
    }

    // Bottom spacing
    item {
      Spacer(modifier = Modifier.height(72.dp))
    }
  }
}

@Composable
private fun KpiCard(
  title: String,
  value: String,
  subtext: String,
  subtextColor: Color,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  iconBg: Color,
  iconTint: Color,
  modifier: Modifier = Modifier,
  onClick: (() -> Unit)? = null
) {
  val clickableMod = if (onClick != null) modifier.clickable { onClick() } else modifier
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = clickableMod
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = title,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          color = TextSecondary,
          maxLines = 1
        )
        Box(
          modifier = Modifier
            .size(22.dp)
            .background(iconBg, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(13.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = value,
        fontSize = 14.sp,
        fontWeight = FontWeight.Black,
        color = TextPrimary,
        letterSpacing = (-0.5).sp
      )

      Spacer(modifier = Modifier.height(2.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = subtext,
          fontSize = 9.sp,
          fontWeight = FontWeight.SemiBold,
          color = subtextColor,
          maxLines = 1
        )
        if (onClick != null) {
          Text(
            text = "View Source >",
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            color = VyaparBlue
          )
        }
      }
    }
  }
}

// ----------------- SUB-VIEWS FOR EACH REPORT TYPE -----------------

@Composable
fun DayBookView(
  bookings: List<BookingEntity>,
  expenses: List<ExpenseEntity>,
  purchases: List<PurchaseEntity>,
  payments: List<CustomerPaymentEntity>,
  onBookingClick: (BookingEntity) -> Unit,
  onExpenseClick: (ExpenseEntity) -> Unit,
  onPurchaseClick: (PurchaseEntity) -> Unit,
  onPaymentClick: (CustomerPaymentEntity) -> Unit
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Daily Cash Book (Day Book - 10 Nov 2026)",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Box(
          modifier = Modifier
            .background(Color(0xFFDCFCE7), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(text = "TODAY", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      val totalIn = bookings.sumOf { it.advancePaid } + payments.filter { it.paymentType == "PAYMENT_IN" }.sumOf { it.amount }
      val totalOut = expenses.sumOf { it.amount } + purchases.sumOf { it.paidAmount }
      val netBalance = totalIn - totalOut

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = Color(0xFFF0FDF4),
          modifier = Modifier.weight(1f)
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(text = "Total Inflow (Money In)", fontSize = 10.sp, color = VyaparDarkGreen)
            Text(text = "+ ₹ ${String.format("%,.2f", totalIn)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
          }
        }

        Surface(
          shape = RoundedCornerShape(10.dp),
          color = Color(0xFFFEF2F2),
          modifier = Modifier.weight(1f)
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(text = "Total Outflow (Money Out)", fontSize = 10.sp, color = SoePrimary)
            Text(text = "- ₹ ${String.format("%,.2f", totalOut)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = SoePrimary)
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))
      Text(text = "Today's Key Transactions (Tap to inspect details):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
      Spacer(modifier = Modifier.height(6.dp))

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        bookings.take(4).forEach { b ->
          DayBookRow(
            title = "Sale Invoice: ${b.customerName}",
            sub = "${b.eventType} • ${b.paymentMode}",
            amount = "+ ₹${b.advancePaid}",
            isCredit = true,
            onClick = { onBookingClick(b) }
          )
        }
        purchases.take(2).forEach { p ->
          DayBookRow(
            title = "Purchase: ${p.vendorName}",
            sub = "${p.itemName} • Bill #${p.billNumber}",
            amount = "- ₹${p.paidAmount}",
            isCredit = false,
            onClick = { onPurchaseClick(p) }
          )
        }
        expenses.take(3).forEach { e ->
          DayBookRow(
            title = "Expense: ${e.expenseTitle}",
            sub = "${e.category} • ${e.paymentMode}",
            amount = "- ₹${e.amount}",
            isCredit = false,
            onClick = { onExpenseClick(e) }
          )
        }
        payments.take(2).forEach { pay ->
          val isIn = pay.paymentType == "PAYMENT_IN"
          DayBookRow(
            title = "Payment: ${pay.customerName}",
            sub = "${pay.paymentMode} • ${pay.note}",
            amount = if (isIn) "+ ₹${pay.amount}" else "- ₹${pay.amount}",
            isCredit = isIn,
            onClick = { onPaymentClick(pay) }
          )
        }
      }
    }
  }
}

@Composable
private fun DayBookRow(
  title: String,
  sub: String,
  amount: String,
  isCredit: Boolean,
  onClick: (() -> Unit)? = null
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .background(Color(0xFFF8FAFC))
      .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
      .padding(8.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
      Text(text = sub, fontSize = 9.sp, color = TextSecondary)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(
        text = amount,
        fontSize = 12.sp,
        fontWeight = FontWeight.Black,
        color = if (isCredit) VyaparGreen else SoePrimary
      )
      if (onClick != null) {
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = ">", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
      }
    }
  }
}

@Composable
fun AllTransactionsView(
  bookings: List<BookingEntity>,
  expenses: List<ExpenseEntity>,
  purchases: List<PurchaseEntity>,
  payments: List<CustomerPaymentEntity>,
  onBookingClick: (BookingEntity) -> Unit,
  onPurchaseClick: (PurchaseEntity) -> Unit,
  onExpenseClick: (ExpenseEntity) -> Unit,
  onPaymentClick: (CustomerPaymentEntity) -> Unit
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = "All Transactions Ledger", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
      Text(text = "Unified audit trail of sales, purchases, expenses and settlements (tap to inspect)", fontSize = 10.sp, color = TextSecondary)
      Spacer(modifier = Modifier.height(10.dp))

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        bookings.forEach { b ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFF8FAFC))
              .clickable { onBookingClick(b) }
              .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "SALE • ${b.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              Text(text = "${b.formattedDate} • ${b.invoiceNumber} • View Invoice >", fontSize = 10.sp, color = VyaparBlue)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text(text = "₹ ${String.format("%,.0f", b.totalAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
              Text(text = "Due: ₹${String.format("%,.0f", b.balanceDue)}", fontSize = 9.sp, color = TextSecondary)
            }
          }
        }

        purchases.forEach { p ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFFEF3C7).copy(alpha = 0.5f))
              .clickable { onPurchaseClick(p) }
              .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "PURCHASE • ${p.vendorName}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              Text(text = "${p.formattedDate} • ${p.itemName} • View Bill >", fontSize = 10.sp, color = Color(0xFFB45309))
            }
            Text(text = "- ₹ ${String.format("%,.0f", p.totalAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VyaparAmber)
          }
        }

        expenses.forEach { e ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFFFE4E6).copy(alpha = 0.5f))
              .clickable { onExpenseClick(e) }
              .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "EXPENSE • ${e.expenseTitle}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              Text(text = "${e.formattedDate} • ${e.category} • View Details >", fontSize = 10.sp, color = SoePrimary)
            }
            Text(text = "- ₹ ${String.format("%,.0f", e.amount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
          }
        }

        payments.forEach { pay ->
          val isIn = pay.paymentType == "PAYMENT_IN"
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFF1F5F9))
              .clickable { onPaymentClick(pay) }
              .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "${if (isIn) "PAYMENT IN" else "PAYMENT OUT"} • ${pay.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              Text(text = "${pay.formattedDate} • ${pay.paymentMode} • View Receipt >", fontSize = 10.sp, color = TextSecondary)
            }
            Text(
              text = if (isIn) "+ ₹${String.format("%,.0f", pay.amount)}" else "- ₹${String.format("%,.0f", pay.amount)}",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = if (isIn) VyaparGreen else SoePrimary
            )
          }
        }
      }
    }
  }
}

@Composable
fun BillWiseProfitView(
  bookings: List<BookingEntity>,
  onBookingClick: (BookingEntity) -> Unit
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = "Bill Wise Profit Report", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
      Text(text = "Revenue, estimated cost and net profit per invoice", fontSize = 10.sp, color = TextSecondary)
      Spacer(modifier = Modifier.height(10.dp))

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        bookings.forEach { b ->
          val cost = b.estimatedCost
          val profit = (b.totalAmount - cost).coerceAtLeast(0.0)
          val margin = if (b.totalAmount > 0) ((profit / b.totalAmount) * 100).toInt() else 0

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF8FAFC),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onBookingClick(b) }
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(text = "${b.salutation} ${b.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = b.invoiceNumber, fontSize = 10.sp, color = TextSecondary)
              }

              Spacer(modifier = Modifier.height(6.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(text = "Bill: ₹${String.format("%,.0f", b.totalAmount)}", fontSize = 11.sp, color = TextSecondary)
                Text(text = "Cost: ₹${String.format("%,.0f", cost)}", fontSize = 11.sp, color = TextSecondary)
                Text(text = "+ ₹${String.format("%,.0f", profit)} ($margin%)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ProfitAndLossView(
  totalSales: Double,
  totalSalesCost: Double,
  totalExpenses: Double,
  totalPurchases: Double,
  netProfit: Double
) {
  val grossProfit = (totalSales - totalSalesCost).coerceAtLeast(0.0)
  val totalOperatingExpenses = totalExpenses
  val finalNetProfit = (grossProfit - totalOperatingExpenses).coerceAtLeast(0.0)

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = "Profit & Loss Statement", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
      Text(text = "Financial Year 2026-27 (SHREE OM EVENT UMARIA)", fontSize = 10.sp, color = TextSecondary)
      Spacer(modifier = Modifier.height(12.dp))

      PnlLineItem("Gross Sales Revenue", "₹ ${String.format("%,.2f", totalSales)}", Color(0xFF1E293B))
      PnlLineItem("(-) Cost of Goods Sold (COGS)", "- ₹ ${String.format("%,.2f", totalSalesCost)}", Color(0xFFDC2626))
      Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFCBD5E1)))
      PnlLineItem("= Gross Profit", "₹ ${String.format("%,.2f", grossProfit)}", VyaparDarkGreen, isBold = true)

      Spacer(modifier = Modifier.height(8.dp))
      PnlLineItem("(-) Operating Expenses", "- ₹ ${String.format("%,.2f", totalOperatingExpenses)}", Color(0xFFDC2626))
      PnlLineItem("(-) Equipment Purchases (15% Dept)", "- ₹ ${String.format("%,.2f", totalPurchases * 0.15)}", Color(0xFFDC2626))
      Box(modifier = Modifier.fillMaxWidth().height(2.dp).background(VyaparGreen))

      Spacer(modifier = Modifier.height(4.dp))
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFFDCFCE7),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(10.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(text = "Net Profit After All Expenses:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
          Text(text = "₹ ${String.format("%,.2f", finalNetProfit)}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
        }
      }
    }
  }
}

@Composable
private fun PnlLineItem(title: String, value: String, color: Color, isBold: Boolean = false) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = title, fontSize = 11.sp, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium, color = TextPrimary)
    Text(text = value, fontSize = 11.sp, fontWeight = if (isBold) FontWeight.Black else FontWeight.SemiBold, color = color)
  }
}

@Composable
fun CashflowView(
  totalUpi: Double,
  totalCash: Double,
  totalExpenses: Double,
  totalPurchases: Double,
  paymentsIn: Double
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = "Cashflow Statement", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
      Text(text = "Cash inflow, outflow and liquid balance position", fontSize = 10.sp, color = TextSecondary)
      Spacer(modifier = Modifier.height(12.dp))

      val totalInflow = totalUpi + totalCash + paymentsIn
      val totalOutflow = totalExpenses + totalPurchases
      val netCashflow = totalInflow - totalOutflow

      PnlLineItem("Cash Inflow (From Events & Bookings)", "+ ₹ ${String.format("%,.2f", totalInflow)}", VyaparGreen)
      PnlLineItem("Cash Outflow (Purchases & Operations)", "- ₹ ${String.format("%,.2f", totalOutflow)}", SoePrimary)
      Spacer(modifier = Modifier.height(6.dp))
      Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE2E8F0)))
      Spacer(modifier = Modifier.height(6.dp))
      PnlLineItem("Net Cashflow", "₹ ${String.format("%,.2f", netCashflow)}", if (netCashflow >= 0) VyaparGreen else SoePrimary, isBold = true)

      Spacer(modifier = Modifier.height(12.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFEFF6FF), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(text = "Bank / UPI Balance:", fontSize = 10.sp, color = VyaparBlue)
            Text(text = "₹ ${String.format("%,.0f", totalUpi)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VyaparBlue)
          }
        }
        Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFF0FDF4), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(text = "Cash in Hand:", fontSize = 10.sp, color = VyaparGreen)
            Text(text = "₹ ${String.format("%,.0f", totalCash)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
          }
        }
      }
    }
  }
}

@Composable
fun BalanceSheetView(
  totalStockValue: Double,
  receivables: Double,
  bankBalance: Double,
  cashBalance: Double,
  payables: Double
) {
  val totalAssets = totalStockValue + receivables + bankBalance + cashBalance
  val totalLiabilities = payables
  val ownerEquity = totalAssets - totalLiabilities

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = "Balance Sheet", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
      Text(text = "Assets & Liabilities Summary", fontSize = 10.sp, color = TextSecondary)
      Spacer(modifier = Modifier.height(12.dp))

      Text(text = "ASSETS:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
      PnlLineItem("• Inventory Stock Value", "₹ ${String.format("%,.2f", totalStockValue)}", TextPrimary)
      PnlLineItem("• Accounts Receivable (Customers)", "₹ ${String.format("%,.2f", receivables)}", TextPrimary)
      PnlLineItem("• Bank / UPI Balance", "₹ ${String.format("%,.2f", bankBalance)}", TextPrimary)
      PnlLineItem("• Cash in Hand", "₹ ${String.format("%,.2f", cashBalance)}", TextPrimary)
      Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE2E8F0)))
      PnlLineItem("Total Assets", "₹ ${String.format("%,.2f", totalAssets)}", VyaparDarkGreen, isBold = true)

      Spacer(modifier = Modifier.height(10.dp))
      Text(text = "LIABILITIES & EQUITY:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
      PnlLineItem("• Accounts Payable (Vendors)", "₹ ${String.format("%,.2f", totalLiabilities)}", SoePrimary)
      PnlLineItem("• Owner Equity", "₹ ${String.format("%,.2f", ownerEquity)}", TextPrimary)
      Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE2E8F0)))
      PnlLineItem("Total Liabilities & Equity", "₹ ${String.format("%,.2f", totalAssets)}", Color(0xFF1E293B), isBold = true)
    }
  }
}

@Composable
fun TrialBalanceView(
  totalSales: Double,
  totalPurchases: Double,
  totalExpenses: Double,
  receivables: Double,
  cashBank: Double
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = "Trial Balance", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
      Text(text = "Debit and credit account reconciliation", fontSize = 10.sp, color = TextSecondary)
      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFFF1F5F9))
          .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(text = "Account Head", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
          Text(text = "Debit (₹)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          Text(text = "Credit (₹)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }

      TrialBalanceRow("Sales Account", "-", String.format("%,.0f", totalSales))
      TrialBalanceRow("Purchase Account", String.format("%,.0f", totalPurchases), "-")
      TrialBalanceRow("Expense Accounts", String.format("%,.0f", totalExpenses), "-")
      TrialBalanceRow("Debtors Receivable", String.format("%,.0f", receivables), "-")
      TrialBalanceRow("Bank & Cash Account", String.format("%,.0f", cashBank), "-")

      Box(modifier = Modifier.fillMaxWidth().height(2.dp).background(VyaparBlue))
      Spacer(modifier = Modifier.height(4.dp))
      Text(text = "✓ Debits and credits are balanced", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
    }
  }
}

@Composable
private fun TrialBalanceRow(title: String, dr: String, cr: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 5.dp, horizontal = 8.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = title, fontSize = 11.sp, color = TextPrimary)
    Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
      Text(text = dr, fontSize = 11.sp, color = TextPrimary, modifier = Modifier.width(60.dp))
      Text(text = cr, fontSize = 11.sp, color = TextPrimary, modifier = Modifier.width(60.dp))
    }
  }
}

@Composable
fun PartyReportsView(
  bookings: List<BookingEntity>,
  onPartyClick: (PartySummary) -> Unit,
  onBookingClick: (BookingEntity) -> Unit
) {
  val partyMap = remember(bookings) {
    bookings.groupBy { it.customerName }
  }

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = "Party Reports (All Parties & Statements)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
      Text(text = "Customer ledger, item breakdown and profit analysis (tap to open ledger)", fontSize = 10.sp, color = TextSecondary)
      Spacer(modifier = Modifier.height(10.dp))

      partyMap.forEach { (party, partyBookings) ->
        val totalBilled = partyBookings.sumOf { it.totalAmount }
        val totalDue = partyBookings.sumOf { it.balanceDue }
        val totalProfit = partyBookings.sumOf { (it.totalAmount - it.estimatedCost).coerceAtLeast(0.0) }
        val firstBooking = partyBookings.first()
        val partySummary = PartySummary(
          name = party,
          salutation = firstBooking.salutation,
          phone = firstBooking.customerPhone,
          address = firstBooking.eventVenueAddress,
          totalBookings = partyBookings.size,
          totalDue = totalDue,
          totalBilled = totalBilled
        )

        Surface(
          shape = RoundedCornerShape(10.dp),
          color = Color(0xFFF8FAFC),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onPartyClick(partySummary) }
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(text = "👤 $party", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "${partyBookings.size} Bookings", fontSize = 10.sp, color = TextSecondary)
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Open Ledger >", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
              }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "Billed: ₹${String.format("%,.0f", totalBilled)}", fontSize = 11.sp, color = TextSecondary)
              Text(text = "Due: ₹${String.format("%,.0f", totalDue)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (totalDue > 0) SoePrimary else VyaparGreen)
              Text(text = "Profit: +₹${String.format("%,.0f", totalProfit)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
            }
          }
        }
      }
    }
  }
}

@Composable
fun StockReportsView(
  items: List<InventoryItemEntity>,
  bookings: List<BookingEntity>,
  onItemClick: (InventoryItemEntity) -> Unit
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = "Stock & Inventory Reports (Stock Summary)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
      Text(text = "Batch numbers, serials and low stock threshold alerts (tap to adjust)", fontSize = 10.sp, color = TextSecondary)
      Spacer(modifier = Modifier.height(10.dp))

      items.forEach { itm ->
        val isLow = itm.stock <= itm.minAlertStock
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = if (isLow) Color(0xFFFFF1F2) else Color(0xFFF8FAFC),
          border = androidx.compose.foundation.BorderStroke(1.dp, if (isLow) Color(0xFFFECDD3) else Color(0xFFE2E8F0)),
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onItemClick(itm) }
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(text = itm.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(
                  text = "Category: ${itm.category} • Batch: ${itm.batchNumber} • S/N: ${itm.serialNumber}",
                  fontSize = 10.sp,
                  color = TextSecondary
                )
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(
                  text = "${itm.stock} ${itm.unit}",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Black,
                  color = if (isLow) SoePrimary else VyaparGreen
                )
                Text(text = "View Details >", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
              }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "Cost: ₹${itm.purchaseCost} | Rate: ₹${itm.rate}", fontSize = 10.sp, color = TextSecondary)
              Text(text = "Discount: ${itm.defaultDiscountPercent}%", fontSize = 10.sp, color = VyaparAmber)
              Text(text = "Value: ₹${String.format("%,.0f", itm.stock * itm.purchaseCost)}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
          }
        }
      }
    }
  }
}

@Composable
fun ExpenseReportsView(
  expenses: List<ExpenseEntity>,
  onAddExpenseClick: () -> Unit,
  onExpenseClick: (ExpenseEntity) -> Unit
) {
  val categoryMap = remember(expenses) { expenses.groupBy { it.category } }

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "Expense Reports (Expense Transaction Report)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = "Category breakdown and operational expenditure records", fontSize = 10.sp, color = TextSecondary)
        }
        Button(
          onClick = onAddExpenseClick,
          colors = ButtonDefaults.buttonColors(containerColor = SoePrimary),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("report_add_expense_btn")
        ) {
          Text("+ Add Expense", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Category Summary
      Text(text = "Expense Summary by Category:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
      Spacer(modifier = Modifier.height(4.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        categoryMap.forEach { (cat, list) ->
          val sum = list.sumOf { it.amount }
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFFFE4E6),
            modifier = Modifier.padding(vertical = 2.dp)
          ) {
            Column(modifier = Modifier.padding(8.dp)) {
              Text(text = cat, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
              Text(text = "₹ ${String.format("%,.0f", sum)}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = TextPrimary)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
      Text(text = "All Expense Transactions:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
      Spacer(modifier = Modifier.height(6.dp))

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        expenses.forEach { exp ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFF8FAFC))
              .clickable { onExpenseClick(exp) }
              .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = exp.expenseTitle, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              Text(text = "${exp.formattedDate} • ${exp.category} • ${exp.paymentMode} • View Voucher >", fontSize = 10.sp, color = TextSecondary)
            }
            Text(text = "₹ ${String.format("%,.2f", exp.amount)}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = SoePrimary)
          }
        }
      }
    }
  }
}

@Composable
fun PurchaseReportsView(
  purchases: List<PurchaseEntity>,
  onAddPurchaseClick: () -> Unit,
  onPurchaseClick: (PurchaseEntity) -> Unit
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "Purchase Report", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = "Supplier procurement and vendor payables tracking", fontSize = 10.sp, color = TextSecondary)
        }
        Button(
          onClick = onAddPurchaseClick,
          colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("report_add_purchase_btn")
        ) {
          Text("+ Add Purchase", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        purchases.forEach { pur ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF8FAFC),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onPurchaseClick(pur) }
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(text = pur.vendorName, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(
                  text = "${pur.itemName} (${pur.quantity} ${pur.unit} @ ₹${pur.rate})",
                  fontSize = 10.sp,
                  color = TextSecondary
                )
                Text(text = "${pur.formattedDate} • ${pur.billNumber} • View Bill >", fontSize = 9.sp, color = VyaparBlue)
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(text = "₹ ${String.format("%,.0f", pur.totalAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                if (pur.dueAmount > 0) {
                  Text(text = "Due: ₹${String.format("%,.0f", pur.dueAmount)}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
                } else {
                  Text(text = "Paid in Full", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun PaymentHistoryView(
  payments: List<CustomerPaymentEntity>,
  onRecordPaymentClick: () -> Unit,
  onPaymentClick: (CustomerPaymentEntity) -> Unit
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "Customer Payment History", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = "Client deposits, clearances, and digital receipts", fontSize = 10.sp, color = TextSecondary)
        }
        Button(
          onClick = onRecordPaymentClick,
          colors = ButtonDefaults.buttonColors(containerColor = VyaparGreen),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("report_record_payment_btn")
        ) {
          Text("+ Record Payment", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        payments.forEach { pay ->
          val isIn = pay.paymentType == "PAYMENT_IN"
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFF8FAFC))
              .clickable { onPaymentClick(pay) }
              .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = pay.customerName, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              Text(text = "${pay.formattedDate} • ${pay.paymentMode} • ${pay.note} • View Receipt >", fontSize = 10.sp, color = TextSecondary)
            }
            Text(
              text = if (isIn) "+ ₹${String.format("%,.0f", pay.amount)}" else "- ₹${String.format("%,.0f", pay.amount)}",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = if (isIn) VyaparGreen else SoePrimary
            )
          }
        }
      }
    }
  }
}

@Composable
fun OrdersReportView(
  orders: List<OrderEntity>,
  onAddOrderClick: () -> Unit,
  onOrderClick: (OrderEntity) -> Unit
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "Orders Report (Sale & Purchase Orders)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = "Upcoming event order delivery status and advances", fontSize = 10.sp, color = TextSecondary)
        }
        Button(
          onClick = onAddOrderClick,
          colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("report_add_order_btn")
        ) {
          Text("+ Add Order", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        orders.forEach { ord ->
          val isSale = ord.orderType == "SALE_ORDER"
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF8FAFC),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onOrderClick(ord) }
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "${if (isSale) "Sale Order" else "Purchase Order"}: ${ord.partyName}",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(text = "${ord.orderNumber} • Delivery: ${ord.deliveryDate} • Status: ${ord.status} >", fontSize = 10.sp, color = VyaparBlue)
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(text = "₹ ${String.format("%,.0f", ord.totalAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = "Adv: ₹${String.format("%,.0f", ord.advanceAmount)}", fontSize = 9.sp, color = VyaparGreen)
              }
            }
          }
        }
      }
    }
  }
}
