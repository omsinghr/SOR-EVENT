package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.BookingEntity
import com.example.data.model.BusinessProfileEntity
import com.example.data.model.JsonHelper
import java.io.File
import java.io.FileOutputStream

object PdfInvoiceGenerator {

  /**
   * Generates a professional A4 PDF invoice for the given booking and returns the File.
   */
  fun generateInvoicePdf(
    context: Context,
    booking: BookingEntity,
    profile: BusinessProfileEntity
  ): File? {
    val pdfDocument = PdfDocument()
    // Standard A4 dimensions in points (72 points per inch)
    val pageWidth = 595
    val pageHeight = 842
    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas: Canvas = page.canvas

    val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Background
    canvas.drawColor(Color.WHITE)

    // 1. Top Decorative Brand Banner
    paint.color = Color.parseColor("#1E40AF") // Vyapar Blue
    canvas.drawRect(0f, 0f, pageWidth.toFloat(), 95f, paint)

    paint.color = Color.parseColor("#D97706") // Golden Amber Accent
    canvas.drawRect(0f, 95f, pageWidth.toFloat(), 99f, paint)

    // Brand Name in Header
    paint.color = Color.WHITE
    paint.textSize = 20f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("SHREE OM EVENT & DECORATION", 24f, 38f, paint)

    paint.textSize = 10f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    canvas.drawText("Complete Event Management • Sound System • Stage Truss • Special FX", 24f, 54f, paint)

    val phoneStr = if (profile.phone1.isNotBlank()) profile.phone1 else "9584249750"
    val emailStr = if (profile.email.isNotBlank()) profile.email else "shriomeventumaria@gmail.com"
    val addressStr = if (profile.address.isNotBlank()) profile.address else "Station Road, Umaria (M.P.)"

    paint.textSize = 9f
    canvas.drawText("Mob: $phoneStr | Email: $emailStr", 24f, 70f, paint)
    canvas.drawText("Office / Venue: $addressStr", 24f, 84f, paint)

    // 2. Invoice Document Title & Header Box
    var currentY = 120f

    paint.color = Color.parseColor("#0F172A")
    paint.textSize = 15f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("EVENT BOOKING INVOICE / TAX INVOICE", 24f, currentY, paint)

    // Status Pill
    val isPaid = booking.balanceDue == 0.0
    val pillBg = if (isPaid) Color.parseColor("#DCFCE7") else Color.parseColor("#FEF3C7")
    val pillTextColor = if (isPaid) Color.parseColor("#166534") else Color.parseColor("#B45309")
    val statusText = if (isPaid) "PAID IN FULL" else "CONFIRMED • ADVANCE RECEIVED"

    paint.color = pillBg
    canvas.drawRoundRect(RectF(pageWidth - 210f, currentY - 14f, pageWidth - 24f, currentY + 4f), 6f, 6f, paint)
    paint.color = pillTextColor
    paint.textSize = 9f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText(statusText, pageWidth - 200f, currentY - 2f, paint)

    currentY += 15f
    paint.color = Color.parseColor("#E2E8F0")
    paint.strokeWidth = 1f
    canvas.drawLine(24f, currentY, pageWidth - 24f, currentY, paint)

    // 3. Metadata Grid (Bill To & Invoice Details)
    currentY += 14f

    // Customer Box Left
    paint.color = Color.parseColor("#F8FAFC")
    canvas.drawRoundRect(RectF(24f, currentY, 300f, currentY + 95f), 8f, 8f, paint)
    paint.color = Color.parseColor("#E2E8F0")
    paint.style = Paint.Style.STROKE
    canvas.drawRoundRect(RectF(24f, currentY, 300f, currentY + 95f), 8f, 8f, paint)
    paint.style = Paint.Style.FILL

    paint.color = Color.parseColor("#64748B")
    paint.textSize = 9f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("CUSTOMER DETAILS", 34f, currentY + 16f, paint)

    paint.color = Color.parseColor("#0F172A")
    paint.textSize = 12f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("${booking.salutation} ${booking.customerName}", 34f, currentY + 34f, paint)

    paint.color = Color.parseColor("#334155")
    paint.textSize = 9.5f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    canvas.drawText("Mobile: ${booking.customerPhone}", 34f, currentY + 50f, paint)
    canvas.drawText("Alt Phone: ${if (booking.customerAltPhone.isNotBlank()) booking.customerAltPhone else "N/A"}", 34f, currentY + 64f, paint)
    val venueTruncated = if (booking.eventVenueAddress.length > 40) booking.eventVenueAddress.take(40) + "..." else booking.eventVenueAddress
    canvas.drawText("Venue: $venueTruncated", 34f, currentY + 78f, paint)

    // Invoice Meta Right
    paint.color = Color.parseColor("#F8FAFC")
    canvas.drawRoundRect(RectF(315f, currentY, pageWidth - 24f, currentY + 95f), 8f, 8f, paint)
    paint.color = Color.parseColor("#E2E8F0")
    paint.style = Paint.Style.STROKE
    canvas.drawRoundRect(RectF(315f, currentY, pageWidth - 24f, currentY + 95f), 8f, 8f, paint)
    paint.style = Paint.Style.FILL

    paint.color = Color.parseColor("#64748B")
    paint.textSize = 9f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("INVOICE & EVENT DETAILS", 325f, currentY + 16f, paint)

    paint.color = Color.parseColor("#334155")
    paint.textSize = 9.5f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    canvas.drawText("Invoice No: ${booking.invoiceNumber}", 325f, currentY + 34f, paint)
    canvas.drawText("Booking ID: #${booking.id}", 325f, currentY + 50f, paint)
    canvas.drawText("Event Date: ${booking.formattedDate}", 325f, currentY + 64f, paint)
    canvas.drawText("Event Package: ${booking.eventType}", 325f, currentY + 78f, paint)

    currentY += 115f

    // 4. Items Table Header
    paint.color = Color.parseColor("#1E293B") // Dark Slate
    canvas.drawRoundRect(RectF(24f, currentY, pageWidth - 24f, currentY + 22f), 4f, 4f, paint)

    paint.color = Color.WHITE
    paint.textSize = 9f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("S.N.", 32f, currentY + 15f, paint)
    canvas.drawText("ITEM DESCRIPTION", 65f, currentY + 15f, paint)
    canvas.drawText("QTY / UNIT", 300f, currentY + 15f, paint)
    canvas.drawText("RATE (₹)", 385f, currentY + 15f, paint)
    canvas.drawText("DISC", 450f, currentY + 15f, paint)
    canvas.drawText("AMOUNT (₹)", 505f, currentY + 15f, paint)

    currentY += 24f

    // 5. Items Rows
    val items = JsonHelper.deserializeBookingItems(booking.itemsJson)
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    paint.textSize = 9f

    var index = 1
    var calcDiscount = 0.0

    if (items.isEmpty()) {
      // Single event package item
      paint.color = Color.parseColor("#0F172A")
      canvas.drawText("1", 32f, currentY + 14f, paint)
      canvas.drawText("Complete Event Setup: ${booking.eventType}", 65f, currentY + 14f, paint)
      canvas.drawText("1 Package", 300f, currentY + 14f, paint)
      canvas.drawText(String.format("%,.0f", booking.totalAmount), 385f, currentY + 14f, paint)
      canvas.drawText("0%", 450f, currentY + 14f, paint)
      canvas.drawText(String.format("%,.0f", booking.totalAmount), 505f, currentY + 14f, paint)

      currentY += 20f
      paint.color = Color.parseColor("#E2E8F0")
      canvas.drawLine(24f, currentY, pageWidth - 24f, currentY, paint)
    } else {
      for (item in items) {
        val rowBg = if (index % 2 == 0) Color.parseColor("#F8FAFC") else Color.WHITE
        paint.color = rowBg
        canvas.drawRect(24f, currentY, pageWidth - 24f, currentY + 20f, paint)

        paint.color = Color.parseColor("#0F172A")
        canvas.drawText("$index", 32f, currentY + 14f, paint)
        canvas.drawText(item.name.take(38), 65f, currentY + 14f, paint)
        canvas.drawText("${item.qty} ${item.unit}", 300f, currentY + 14f, paint)
        canvas.drawText(String.format("%,.0f", item.rate), 385f, currentY + 14f, paint)
        canvas.drawText("0%", 450f, currentY + 14f, paint)
        canvas.drawText(String.format("%,.0f", item.total), 505f, currentY + 14f, paint)

        currentY += 20f
        paint.color = Color.parseColor("#E2E8F0")
        canvas.drawLine(24f, currentY, pageWidth - 24f, currentY, paint)
        index++
      }
    }

    // 6. Financial Summary Box (Right Aligned)
    currentY += 12f

    // Notes Left Box
    val notesBoxRight = 280f
    paint.color = Color.parseColor("#F8FAFC")
    canvas.drawRoundRect(RectF(24f, currentY, notesBoxRight, currentY + 110f), 6f, 6f, paint)
    paint.color = Color.parseColor("#E2E8F0")
    paint.style = Paint.Style.STROKE
    canvas.drawRoundRect(RectF(24f, currentY, notesBoxRight, currentY + 110f), 6f, 6f, paint)
    paint.style = Paint.Style.FILL

    paint.color = Color.parseColor("#0F172A")
    paint.textSize = 9.5f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("PAYMENT METHOD & REMARKS", 32f, currentY + 16f, paint)

    paint.color = Color.parseColor("#475569")
    paint.textSize = 8.5f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    canvas.drawText("Payment Mode: ${booking.paymentMode}", 32f, currentY + 32f, paint)
    canvas.drawText("Status: ${booking.status}", 32f, currentY + 46f, paint)
    canvas.drawText("Thank you for choosing Shree Om Event!", 32f, currentY + 62f, paint)
    canvas.drawText("Official Support: $phoneStr", 32f, currentY + 76f, paint)

    // Totals Box Right
    val summaryBoxLeft = 300f
    paint.color = Color.parseColor("#F8FAFC")
    canvas.drawRoundRect(RectF(summaryBoxLeft, currentY, pageWidth - 24f, currentY + 110f), 6f, 6f, paint)
    paint.color = Color.parseColor("#E2E8F0")
    paint.style = Paint.Style.STROKE
    canvas.drawRoundRect(RectF(summaryBoxLeft, currentY, pageWidth - 24f, currentY + 110f), 6f, 6f, paint)
    paint.style = Paint.Style.FILL

    val labelX = summaryBoxLeft + 12f
    val valueX = pageWidth - 36f
    var sumY = currentY + 18f

    // Gross Total
    paint.color = Color.parseColor("#475569")
    paint.textSize = 9.5f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    canvas.drawText("Total Booking Amount:", labelX, sumY, paint)
    val totalFormatted = "₹ " + String.format("%,.2f", booking.totalAmount)
    paint.textAlign = Paint.Align.RIGHT
    paint.color = Color.parseColor("#0F172A")
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText(totalFormatted, valueX, sumY, paint)
    paint.textAlign = Paint.Align.LEFT

    // Total Discount
    sumY += 18f
    paint.color = Color.parseColor("#475569")
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    canvas.drawText("Total Discount:", labelX, sumY, paint)
    paint.textAlign = Paint.Align.RIGHT
    paint.color = Color.parseColor("#15803D")
    canvas.drawText("₹ 0.00", valueX, sumY, paint)
    paint.textAlign = Paint.Align.LEFT

    // Advance Paid
    sumY += 18f
    paint.color = Color.parseColor("#166534")
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("Advance Payment Received:", labelX, sumY, paint)
    val advFormatted = "₹ " + String.format("%,.2f", booking.advancePaid)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText(advFormatted, valueX, sumY, paint)
    paint.textAlign = Paint.Align.LEFT

    // Divider
    sumY += 8f
    paint.color = Color.parseColor("#CBD5E1")
    canvas.drawLine(labelX, sumY, valueX, sumY, paint)

    // Balance Due
    sumY += 18f
    val balColor = if (booking.balanceDue > 0) Color.parseColor("#DC2626") else Color.parseColor("#16A34A")
    paint.color = balColor
    paint.textSize = 11f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("BALANCE DUE:", labelX, sumY, paint)
    val balFormatted = "₹ " + String.format("%,.2f", booking.balanceDue)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText(balFormatted, valueX, sumY, paint)
    paint.textAlign = Paint.Align.LEFT

    currentY += 125f

    // 7. Terms and Conditions Section (Small neat text at bottom)
    paint.color = Color.parseColor("#0F172A")
    paint.textSize = 9f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("TERMS & CONDITIONS:", 24f, currentY, paint)

    currentY += 12f
    paint.color = Color.parseColor("#64748B")
    paint.textSize = 7.5f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)

    val termsList = listOf(
      "1. 50% advance deposit is required to confirm booking dates and reserve equipment.",
      "2. The client / organizer must provide uninterrupted 220V power supply and safe wiring at venue.",
      "3. A minimum safety radius of 15 feet must be maintained around stage special effects and pyros.",
      "4. The remaining balance amount must be settled immediately upon setup and delivery at event venue.",
      "5. Cancellations within 48 hours prior to event start time will forfeit advance deposit."
    )

    for (t in termsList) {
      canvas.drawText(t, 24f, currentY, paint)
      currentY += 11f
    }

    // 8. Signatures Bottom
    currentY += 15f
    paint.color = Color.parseColor("#CBD5E1")
    canvas.drawLine(24f, currentY, 160f, currentY, paint)
    canvas.drawLine(pageWidth - 190f, currentY, pageWidth - 24f, currentY, paint)

    currentY += 12f
    paint.color = Color.parseColor("#475569")
    paint.textSize = 8.5f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    canvas.drawText("Customer Acceptance / Signature", 24f, currentY, paint)

    paint.textAlign = Paint.Align.RIGHT
    paint.color = Color.parseColor("#1E40AF")
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("For SHREE OM EVENT & DECORATION", pageWidth - 24f, currentY, paint)
    paint.textAlign = Paint.Align.LEFT

    pdfDocument.finishPage(page)

    // Save PDF to Documents Directory
    return try {
      val docsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
      if (!docsDir.exists()) docsDir.mkdirs()
      val file = File(docsDir, "Invoice_${booking.invoiceNumber.replace("/", "_")}.pdf")
      val outputStream = FileOutputStream(file)
      pdfDocument.writeTo(outputStream)
      outputStream.flush()
      outputStream.close()
      pdfDocument.close()
      file
    } catch (e: Exception) {
      e.printStackTrace()
      pdfDocument.close()
      null
    }
  }

  /**
   * Shares the generated PDF file via WhatsApp, Gmail or other apps.
   */
  fun shareInvoicePdf(
    context: Context,
    booking: BookingEntity,
    profile: BusinessProfileEntity
  ) {
    val file = generateInvoicePdf(context, booking, profile)
    if (file == null || !file.exists()) {
      Toast.makeText(context, "Unable to generate PDF", Toast.LENGTH_SHORT).show()
      return
    }

    try {
      val uri: Uri = FileProvider.getUriForFile(
        context,
        "com.example.fileprovider",
        file
      )

      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "Invoice #${booking.invoiceNumber} - Shree Om Event")
        val message = """
*SHREE OM EVENT & DECORATION*
*Invoice / Booking Confirmation #${booking.invoiceNumber}*

Dear *${booking.salutation} ${booking.customerName}*,
Your event booking confirmation invoice is attached as PDF.

📅 Event Date: ${booking.formattedDate}
📍 Venue: ${booking.eventVenueAddress}
🎉 Service: ${booking.eventType}

💰 Total Amount: ₹${String.format("%,.2f", booking.totalAmount)}
✅ Advance Paid: ₹${String.format("%,.2f", booking.advancePaid)}
🔴 Balance Due: ₹${String.format("%,.2f", booking.balanceDue)}

Thank you for choosing Shree Om Event & Decoration!
📞 Contact: ${profile.phone1}
        """.trimIndent()
        putExtra(Intent.EXTRA_TEXT, message)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }

      context.startActivity(Intent.createChooser(shareIntent, "Share Invoice PDF"))
    } catch (e: Exception) {
      e.printStackTrace()
      Toast.makeText(context, "Sharing error: ${e.message}", Toast.LENGTH_SHORT).show()
    }
  }

  /**
   * Downloads or opens the generated PDF in an external PDF Viewer app.
   */
  fun openOrDownloadInvoicePdf(
    context: Context,
    booking: BookingEntity,
    profile: BusinessProfileEntity
  ) {
    val file = generateInvoicePdf(context, booking, profile)
    if (file == null || !file.exists()) {
      Toast.makeText(context, "Could not generate PDF", Toast.LENGTH_SHORT).show()
      return
    }

    Toast.makeText(context, "PDF saved: ${file.name}", Toast.LENGTH_LONG).show()

    try {
      val uri: Uri = FileProvider.getUriForFile(
        context,
        "com.example.fileprovider",
        file
      )
      val viewIntent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/pdf")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(Intent.createChooser(viewIntent, "Open Invoice PDF"))
    } catch (e: Exception) {
      // If no PDF viewer app is installed
      Toast.makeText(context, "Invoice PDF saved to Documents folder: ${file.name}", Toast.LENGTH_LONG).show()
    }
  }
}
