package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Shree Om Event Brand Colors
val SoePrimary = Color(0xFFF5003B)
val SoePrimaryDark = Color(0xFFB91C1C)
val SoePrimaryLight = Color(0xFFFFEBEE)
val SoePrimarySubtle = Color(0xFFFFF5F7)

// Vyapar Pro Accent Colors
val VyaparBlue = Color(0xFF1976D2)
val VyaparDarkBlue = Color(0xFF0D47A1)
val VyaparLightBlue = Color(0xFFE3F2FD)

val VyaparGreen = Color(0xFF00C853)
val VyaparDarkGreen = Color(0xFF15803D)
val VyaparLightGreen = Color(0xFFDCFCE7)

val VyaparAmber = Color(0xFFF59E0B)
val VyaparDarkAmber = Color(0xFFB45309)
val VyaparLightAmber = Color(0xFFFEF3C7)

val VyaparRed = Color(0xFFE11D48)
val VyaparLightRed = Color(0xFFFFE4E6)

val SurfaceLight = Color(0xFFEEF3F9)
val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceSlate = Color(0xFFF1F5F9)

val TextPrimary = Color(0xFF1E293B)
val TextSecondary = Color(0xFF64748B)
val TextMuted = Color(0xFF94A3B8)
val BorderColor = Color(0xFFE2E8F0)
