package com.example

import com.example.data.model.BookingItem
import com.example.data.model.JsonHelper
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }


  @Test
  fun testBalanceDueCalculation() {
    val total = 25000.0
    val advance = 20000.0
    val due = (total - advance).coerceAtLeast(0.0)
    assertEquals(5000.0, due, 0.001)
  }
}
