package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.BookingEntity
import com.example.data.model.BookingItem
import com.example.data.model.BusinessProfileEntity
import com.example.data.model.CustomerPaymentEntity
import com.example.data.model.EmployeeAttendanceEntity
import com.example.data.model.EmployeeEntity
import com.example.data.model.EmployeePaymentEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.InventoryItemEntity
import com.example.data.model.ItemPriceHistoryEntity
import com.example.data.model.JsonHelper
import com.example.data.model.NotificationEntity
import com.example.data.model.OrderEntity
import com.example.data.model.PurchaseEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    BookingEntity::class,
    InventoryItemEntity::class,
    ItemPriceHistoryEntity::class,
    BusinessProfileEntity::class,
    NotificationEntity::class,
    PurchaseEntity::class,
    ExpenseEntity::class,
    CustomerPaymentEntity::class,
    OrderEntity::class,
    EmployeeEntity::class,
    EmployeeAttendanceEntity::class,
    EmployeePaymentEntity::class
  ],
  version = 2,
  exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
  abstract fun bookingDao(): BookingDao
  abstract fun inventoryDao(): InventoryDao
  abstract fun itemPriceHistoryDao(): ItemPriceHistoryDao
  abstract fun businessProfileDao(): BusinessProfileDao
  abstract fun notificationDao(): NotificationDao
  abstract fun purchaseDao(): PurchaseDao
  abstract fun expenseDao(): ExpenseDao
  abstract fun customerPaymentDao(): CustomerPaymentDao
  abstract fun orderDao(): OrderDao
  abstract fun employeeDao(): EmployeeDao
  abstract fun employeeAttendanceDao(): EmployeeAttendanceDao
  abstract fun employeePaymentDao(): EmployeePaymentDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "shree_om_event_db"
        )
          .fallbackToDestructiveMigration()
          .addCallback(DatabaseCallback())
          .build()
        INSTANCE = instance
        instance
      }
    }

    private class DatabaseCallback : RoomDatabase.Callback() {
      override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        INSTANCE?.let { database ->
          CoroutineScope(Dispatchers.IO).launch {
            populateInitialData(database)
          }
        }
      }
    }

    private suspend fun populateInitialData(db: AppDatabase) {
      // 1. Initial Business Profile
      db.businessProfileDao().insertOrUpdate(BusinessProfileEntity())

      // 2. Initial Stock Items (with batch, serial, category, market price, etc.)
      val initialItems = listOf(
        InventoryItemEntity(
          id = "itm_1",
          name = "Cold Pyro Gun Entry",
          stock = 12.0,
          unit = "Pieces",
          rate = 600.0,
          purchaseCost = 350.0,
          minAlertStock = 5.0,
          category = "Pyro & FX",
          batchNumber = "B-2026-01",
          serialNumber = "SN-CPG-101",
          defaultDiscountPercent = 5.0,
          sku = "SKU-CPG-01",
          currentMarketPrice = 650.0,
          supplierName = "Gwalior Fireworks Suppliers",
          supplierMobile = "9425112233",
          purchaseDate = "2026-10-15",
          description = "Cold spark gun for wedding bridal and groom entry fx",
          previousPurchasePrice = 300.0,
          priceChangeDate = "2026-10-15"
        ),
        InventoryItemEntity(
          id = "itm_2",
          name = "Dry Ice / Low Fog Machine",
          stock = 4.0,
          unit = "Pieces",
          rate = 3500.0,
          purchaseCost = 2200.0,
          minAlertStock = 2.0,
          category = "Special Effects",
          batchNumber = "B-2026-02",
          serialNumber = "SN-FOG-201",
          defaultDiscountPercent = 0.0,
          sku = "SKU-FOG-02",
          currentMarketPrice = 3800.0,
          supplierName = "Indore Electronics Traders",
          supplierMobile = "9826334455",
          purchaseDate = "2026-09-20",
          description = "Dense cloud low fog effect machine for varmala stage",
          previousPurchasePrice = 2000.0,
          priceChangeDate = "2026-09-20"
        ),
        InventoryItemEntity(
          id = "itm_3",
          name = "Dry Ice Pellets",
          stock = 50.0,
          unit = "Kg",
          rate = 250.0,
          purchaseCost = 140.0,
          minAlertStock = 10.0,
          category = "Consumables",
          batchNumber = "B-2026-03",
          serialNumber = "SN-ICE-301",
          defaultDiscountPercent = 0.0,
          sku = "SKU-ICE-03",
          currentMarketPrice = 260.0,
          supplierName = "Jabalpur Dry Ice Depot",
          supplierMobile = "9826334455",
          purchaseDate = "2026-11-01",
          description = "High density dry ice pellets for low fog",
          previousPurchasePrice = 120.0,
          priceChangeDate = "2026-11-01"
        ),
        InventoryItemEntity(
          id = "itm_4",
          name = "Matka Pyro Waterfall",
          stock = 20.0,
          unit = "Pieces",
          rate = 450.0,
          purchaseCost = 260.0,
          minAlertStock = 6.0,
          category = "Pyro & FX",
          batchNumber = "B-2026-01",
          serialNumber = "SN-MPW-401",
          defaultDiscountPercent = 5.0,
          sku = "SKU-MPW-04",
          currentMarketPrice = 480.0,
          supplierName = "Gwalior Fireworks & Event Suppliers",
          supplierMobile = "9425112233",
          purchaseDate = "2026-10-15",
          description = "Stage backdrop & pyro waterfall effect",
          previousPurchasePrice = 240.0,
          priceChangeDate = "2026-10-15"
        ),
        InventoryItemEntity(
          id = "itm_5",
          name = "Paper Blaster Machine",
          stock = 3.0,
          unit = "Pieces",
          rate = 2000.0,
          purchaseCost = 1200.0,
          minAlertStock = 1.0,
          category = "Special Effects",
          batchNumber = "B-2026-04",
          serialNumber = "SN-PBM-501",
          defaultDiscountPercent = 0.0,
          sku = "SKU-PBM-05",
          currentMarketPrice = 2200.0,
          supplierName = "Indore Event Electronics",
          supplierMobile = "9300556677",
          purchaseDate = "2026-08-10",
          description = "Golden and colorful confetti paper blaster machine",
          previousPurchasePrice = 1100.0,
          priceChangeDate = "2026-08-10"
        ),
        InventoryItemEntity(
          id = "itm_6",
          name = "Truss Setup (Square Truss)",
          stock = 6.0,
          unit = "Set",
          rate = 8000.0,
          purchaseCost = 5000.0,
          minAlertStock = 2.0,
          category = "Stage & Truss",
          batchNumber = "B-2026-05",
          serialNumber = "SN-TRS-601",
          defaultDiscountPercent = 10.0,
          sku = "SKU-TRS-06",
          currentMarketPrice = 8500.0,
          supplierName = "Indore Truss & Stage Hardware",
          supplierMobile = "9300556677",
          purchaseDate = "2026-07-22",
          description = "Heavy duty aluminium square truss frame",
          previousPurchasePrice = 4800.0,
          priceChangeDate = "2026-07-22"
        ),
        InventoryItemEntity(
          id = "itm_7",
          name = "Bubble Smoke Machine",
          stock = 2.0,
          unit = "Pieces",
          rate = 1500.0,
          purchaseCost = 900.0,
          minAlertStock = 1.0,
          category = "Special Effects",
          batchNumber = "B-2026-04",
          serialNumber = "SN-BSM-701",
          defaultDiscountPercent = 0.0,
          sku = "SKU-BSM-07",
          currentMarketPrice = 1600.0,
          supplierName = "Indore Event Electronics",
          supplierMobile = "9826334455",
          purchaseDate = "2026-08-10",
          description = "Smoke filled colorful bubble maker machine",
          previousPurchasePrice = 850.0,
          priceChangeDate = "2026-08-10"
        ),
        InventoryItemEntity(
          id = "itm_8",
          name = "Side Jali (Truss Mount)",
          stock = 10.0,
          unit = "Pieces",
          rate = 1200.0,
          purchaseCost = 750.0,
          minAlertStock = 4.0,
          category = "Stage Hardware",
          batchNumber = "B-2026-05",
          serialNumber = "SN-SJL-801",
          defaultDiscountPercent = 0.0,
          sku = "SKU-SJL-08",
          currentMarketPrice = 1300.0,
          supplierName = "Indore Truss & Stage Hardware",
          supplierMobile = "9300556677",
          purchaseDate = "2026-07-22",
          description = "Truss mounting side mesh / safety jali",
          previousPurchasePrice = 700.0,
          priceChangeDate = "2026-07-22"
        ),
        InventoryItemEntity(
          id = "itm_9",
          name = "Wall Stand (Stage Frame)",
          stock = 8.0,
          unit = "Set",
          rate = 2500.0,
          purchaseCost = 1600.0,
          minAlertStock = 2.0,
          category = "Stage Hardware",
          batchNumber = "B-2026-05",
          serialNumber = "SN-WST-901",
          defaultDiscountPercent = 0.0,
          sku = "SKU-WST-09",
          currentMarketPrice = 2700.0,
          supplierName = "Indore Truss & Stage Hardware",
          supplierMobile = "9300556677",
          purchaseDate = "2026-07-22",
          description = "Stage backdrop wall stand frame set",
          previousPurchasePrice = 1500.0,
          priceChangeDate = "2026-07-22"
        )
      )
      db.inventoryDao().insertAll(initialItems)

      // 3. Initial Price History for comparison
      val initialPriceHistory = listOf(
        ItemPriceHistoryEntity(
          itemId = "itm_1",
          itemName = "Cold Pyro Gun Entry",
          previousPrice = 300.0,
          newPrice = 350.0,
          currentMarketPrice = 650.0,
          changeDate = "2026-10-15",
          changeFormattedDate = "15 Oct, 26",
          supplierName = "Gwalior Fireworks & Event Suppliers",
          reason = "Raw materials and pyro powder rate increase"
        ),
        ItemPriceHistoryEntity(
          itemId = "itm_2",
          itemName = "Dry Ice / Low Fog Machine",
          previousPrice = 2000.0,
          newPrice = 2200.0,
          currentMarketPrice = 3800.0,
          changeDate = "2026-09-20",
          changeFormattedDate = "20 Sep, 26",
          supplierName = "Indore Event Electronics",
          reason = "Electronic components & motor upgrade"
        ),
        ItemPriceHistoryEntity(
          itemId = "itm_3",
          itemName = "Dry Ice Pellets",
          previousPrice = 120.0,
          newPrice = 140.0,
          currentMarketPrice = 260.0,
          changeDate = "2026-11-01",
          changeFormattedDate = "01 Nov, 26",
          supplierName = "Jabalpur Dry Ice Depot",
          reason = "Transport and cold storage freight hike"
        )
      )
      db.itemPriceHistoryDao().insertAll(initialPriceHistory)

      // 4. Initial Bookings
      val items37 = listOf(
        BookingItem("itm_1", "Cold Pyro Gun Entry", 6.0, "Pieces", 600.0, 3600.0),
        BookingItem("itm_2", "Dry Ice / Low Fog Machine", 1.0, "Pieces", 3500.0, 3500.0)
      )
      val items36 = listOf(
        BookingItem("itm_1", "Cold Pyro Gun Entry", 8.0, "Pieces", 600.0, 4800.0),
        BookingItem("itm_4", "Matka Pyro Waterfall", 8.0, "Pieces", 450.0, 3600.0)
      )
      val items35 = listOf(
        BookingItem("itm_6", "Truss Setup (Square Truss)", 1.0, "Set", 8000.0, 8000.0),
        BookingItem("itm_5", "Paper Blaster Machine", 2.0, "Pieces", 2000.0, 4000.0)
      )
      val items34 = listOf(
        BookingItem("itm_1", "Cold Pyro Fountain (8 Pcs)", 8.0, "Pieces", 800.0, 6400.0),
        BookingItem("itm_2", "Royal Palki Bridal Entry Theme", 1.0, "Pieces", 16000.0, 16000.0),
        BookingItem("itm_5", "Confetti Blaster & Special Lights", 2.0, "Pieces", 2800.0, 5600.0)
      )

      val initialBookings = listOf(
        BookingEntity(
          id = 37,
          invoiceNumber = "INV-2026-037",
          salutation = "Mr.",
          customerName = "Mukesh Singh",
          customerPhone = "9876543210",
          customerAltPhone = "9123456780",
          customerAddress = "Station Road, Umaria",
          eventVenueAddress = "Hotel Grand, Rewa Road, Umaria",
          eventDate = "2026-07-17",
          formattedDate = "17 Jul, 26",
          eventType = "Wedding & Reception",
          itemsJson = JsonHelper.serializeBookingItems(items37),
          totalAmount = 25000.0,
          advancePaid = 20000.0,
          balanceDue = 5000.0,
          estimatedCost = 15000.0,
          paymentMode = "UPI",
          status = "CONFIRMED",
          isStockDeducted = true
        ),
        BookingEntity(
          id = 36,
          invoiceNumber = "INV-2026-036",
          salutation = "Mr.",
          customerName = "Man Singh",
          customerPhone = "9988776655",
          customerAltPhone = "",
          customerAddress = "Gandhi Chowk, Umaria",
          eventVenueAddress = "Anand Bhawan Marriage Garden",
          eventDate = "2026-07-06",
          formattedDate = "06 Jul, 26",
          eventType = "Bride & Groom Entry",
          itemsJson = JsonHelper.serializeBookingItems(items36),
          totalAmount = 12000.0,
          advancePaid = 12000.0,
          balanceDue = 0.0,
          estimatedCost = 7500.0,
          paymentMode = "CASH",
          status = "COMPLETED",
          isStockDeducted = true
        ),
        BookingEntity(
          id = 35,
          invoiceNumber = "INV-2026-035",
          salutation = "Mrs.",
          customerName = "Pooja Singh",
          customerPhone = "9765432109",
          customerAltPhone = "9425100000",
          customerAddress = "Ward 8, Nowrozabad",
          eventVenueAddress = "Shanti Niketan Marriage Hall",
          eventDate = "2026-06-28",
          formattedDate = "28 Jun, 26",
          eventType = "Haldi & Sangeet Setup",
          itemsJson = JsonHelper.serializeBookingItems(items35),
          totalAmount = 18000.0,
          advancePaid = 8000.0,
          balanceDue = 10000.0,
          estimatedCost = 11000.0,
          paymentMode = "UPI",
          status = "CONFIRMED",
          isStockDeducted = true
        ),
        BookingEntity(
          id = 34,
          invoiceNumber = "INV-2026-081",
          salutation = "Mr.",
          customerName = "Rajesh Verma (Wedding Event)",
          customerPhone = "9584249750",
          customerAltPhone = "",
          customerAddress = "Station Road, Umaria",
          eventVenueAddress = "Royal Palace Garden, Main Road",
          eventDate = "2026-11-10",
          formattedDate = "10 Nov, 26",
          eventType = "Bridal Entry Theme",
          itemsJson = JsonHelper.serializeBookingItems(items34),
          totalAmount = 28000.0,
          advancePaid = 28000.0,
          balanceDue = 0.0,
          estimatedCost = 17200.0,
          paymentMode = "UPI",
          status = "COMPLETED",
          isStockDeducted = true
        ),
        BookingEntity(
          id = 33,
          invoiceNumber = "INV-2026-078",
          salutation = "Mr.",
          customerName = "Suresh Patel (Sound & Orchestra)",
          customerPhone = "9926345678",
          customerAltPhone = "",
          customerAddress = "Chandia Road, Umaria",
          eventVenueAddress = "Community Hall, Chandia",
          eventDate = "2026-11-05",
          formattedDate = "05 Nov, 26",
          eventType = "Sound & Light Setup",
          itemsJson = "[]",
          totalAmount = 14000.0,
          advancePaid = 0.0,
          balanceDue = 14000.0,
          estimatedCost = 9000.0,
          paymentMode = "CREDIT",
          status = "PENDING DUE",
          isStockDeducted = true
        )
      )
      db.bookingDao().insertAll(initialBookings)

      // 5. Initial Purchases
      val initialPurchases = listOf(
        PurchaseEntity(
          billNumber = "PUR-2026-01",
          vendorName = "Gwalior Fireworks & Event Suppliers",
          vendorPhone = "9425112233",
          purchaseDate = "2026-11-01",
          formattedDate = "01 Nov, 26",
          itemName = "Cold Spark Pyro Refill Cartridge",
          quantity = 50.0,
          unit = "Pieces",
          rate = 350.0,
          totalAmount = 17500.0,
          paidAmount = 17500.0,
          dueAmount = 0.0,
          paymentMode = "UPI",
          category = "Pyro & FX"
        ),
        PurchaseEntity(
          billNumber = "PUR-2026-02",
          vendorName = "Jabalpur Dry Ice Depot",
          vendorPhone = "9826334455",
          purchaseDate = "2026-11-04",
          formattedDate = "04 Nov, 26",
          itemName = "High Grade Dry Ice Block",
          quantity = 60.0,
          unit = "Kg",
          rate = 140.0,
          totalAmount = 8400.0,
          paidAmount = 5000.0,
          dueAmount = 3400.0,
          paymentMode = "UPI",
          category = "Consumables"
        ),
        PurchaseEntity(
          billNumber = "PUR-2026-03",
          vendorName = "Indore Truss & Stage Hardware",
          vendorPhone = "9300556677",
          purchaseDate = "2026-10-25",
          formattedDate = "25 Oct, 26",
          itemName = "Aluminium Truss Clamp & Coupler Set",
          quantity = 24.0,
          unit = "Pieces",
          rate = 650.0,
          totalAmount = 15600.0,
          paidAmount = 15600.0,
          dueAmount = 0.0,
          paymentMode = "BANK",
          category = "Stage Hardware"
        )
      )
      db.purchaseDao().insertAll(initialPurchases)

      // 6. Initial Expenses
      val initialExpenses = listOf(
        ExpenseEntity(
          expenseTitle = "Generator Diesel & Operator Charge",
          category = "Generator & Diesel",
          amount = 3500.0,
          expenseDate = "2026-11-09",
          formattedDate = "09 Nov, 26",
          paymentMode = "CASH",
          remarks = "40 Litres Diesel for Hotel Grand event"
        ),
        ExpenseEntity(
          expenseTitle = "Event Labor & Loading Wages",
          category = "Labor & Wages",
          amount = 4500.0,
          expenseDate = "2026-11-08",
          formattedDate = "08 Nov, 26",
          paymentMode = "CASH",
          remarks = "1 Day wages for 6 skilled technicians"
        ),
        ExpenseEntity(
          expenseTitle = "Pickup Transport Freight",
          category = "Transport & Freight",
          amount = 2200.0,
          expenseDate = "2026-11-07",
          formattedDate = "07 Nov, 26",
          paymentMode = "UPI",
          remarks = "Freight from Karkeli to Umaria venue"
        ),
        ExpenseEntity(
          expenseTitle = "Team Snacks & Meals",
          category = "Catering & Snacks",
          amount = 1200.0,
          expenseDate = "2026-11-06",
          formattedDate = "06 Nov, 26",
          paymentMode = "CASH",
          remarks = "Staff refreshments during stage setup"
        )
      )
      db.expenseDao().insertAll(initialExpenses)

      // 7. Customer Payments
      val initialPayments = listOf(
        CustomerPaymentEntity(
          customerName = "Mukesh Singh",
          customerPhone = "9876543210",
          paymentDate = "2026-07-17",
          formattedDate = "17 Jul, 26",
          amount = 20000.0,
          paymentType = "PAYMENT_IN",
          paymentMode = "UPI",
          receiptNumber = "REC-2026-101",
          bookingId = 37,
          note = "Advance Booking Payment"
        ),
        CustomerPaymentEntity(
          customerName = "Rajesh Verma",
          customerPhone = "9584249750",
          paymentDate = "2026-11-10",
          formattedDate = "10 Nov, 26",
          amount = 28000.0,
          paymentType = "PAYMENT_IN",
          paymentMode = "UPI",
          receiptNumber = "REC-2026-102",
          bookingId = 34,
          note = "Full Payment Received"
        )
      )
      db.customerPaymentDao().insertAll(initialPayments)

      // 8. Orders
      val initialOrders = listOf(
        OrderEntity(
          orderNumber = "SO-2026-01",
          orderType = "SALE_ORDER",
          partyName = "Amit Chaturvedi (Tilak Ceremony)",
          partyPhone = "9827110000",
          orderDate = "2026-11-08",
          deliveryDate = "2026-11-20",
          itemsJson = "[]",
          totalAmount = 22000.0,
          advanceAmount = 5000.0,
          status = "OPEN"
        ),
        OrderEntity(
          orderNumber = "PO-2026-01",
          orderType = "PURCHASE_ORDER",
          partyName = "Gwalior Fireworks & Event Suppliers",
          partyPhone = "9425112233",
          orderDate = "2026-11-09",
          deliveryDate = "2026-11-18",
          itemsJson = "[]",
          totalAmount = 14000.0,
          advanceAmount = 4000.0,
          status = "OPEN"
        )
      )
      db.orderDao().insertAll(initialOrders)

      // 9. Initial Employees
      val initialEmployees = listOf(
        EmployeeEntity(
          employeeId = "EMP-001",
          name = "Rohit Vishwakarma",
          mobile = "9826112233",
          address = "Gandhi Chowk, Umaria",
          joiningDate = "2026-01-05",
          category = "Sound & Mic Operator",
          dailyWage = 700.0,
          isActive = true
        ),
        EmployeeEntity(
          employeeId = "EMP-002",
          name = "Sunil Barman",
          mobile = "9977889900",
          address = "Station Road, Umaria",
          joiningDate = "2026-02-10",
          category = "Lighting & Pyro Technician",
          dailyWage = 650.0,
          isActive = true
        ),
        EmployeeEntity(
          employeeId = "EMP-003",
          name = "Vikas Yadav",
          mobile = "9424556677",
          address = "Karkeli, Umaria",
          joiningDate = "2026-03-01",
          category = "Stage Decorator & Truss Fitter",
          dailyWage = 600.0,
          isActive = true
        ),
        EmployeeEntity(
          employeeId = "EMP-004",
          name = "Amit Kol",
          mobile = "9131223344",
          address = "Camp Umaria",
          joiningDate = "2026-04-15",
          category = "Loading & Transport Helper",
          dailyWage = 500.0,
          isActive = true
        )
      )
      db.employeeDao().insertAll(initialEmployees)

      // 10. Initial Employee Attendance
      val initialAttendance = listOf(
        EmployeeAttendanceEntity(
          employeeId = "EMP-001",
          employeeName = "Rohit Vishwakarma",
          date = "2026-11-10",
          formattedDate = "10 Nov, 26",
          status = "PRESENT",
          dailyRate = 700.0,
          eventReference = "Mukesh Singh Wedding (#37)",
          notes = "Sound console & wireless mic operator"
        ),
        EmployeeAttendanceEntity(
          employeeId = "EMP-002",
          employeeName = "Sunil Barman",
          date = "2026-11-10",
          formattedDate = "10 Nov, 26",
          status = "PRESENT",
          dailyRate = 650.0,
          eventReference = "Mukesh Singh Wedding (#37)",
          notes = "Cold pyro & fog machine operation"
        ),
        EmployeeAttendanceEntity(
          employeeId = "EMP-003",
          employeeName = "Vikas Yadav",
          date = "2026-11-09",
          formattedDate = "09 Nov, 26",
          status = "HALF_DAY",
          dailyRate = 600.0,
          eventReference = "Truss Pre-fitting",
          notes = "Afternoon stage truss assembly"
        ),
        EmployeeAttendanceEntity(
          employeeId = "EMP-004",
          employeeName = "Amit Kol",
          date = "2026-11-08",
          formattedDate = "08 Nov, 26",
          status = "PRESENT",
          dailyRate = 500.0,
          eventReference = "Loading & Unloading",
          notes = "Warehouse goods dispatch & return"
        )
      )
      db.employeeAttendanceDao().insertAll(initialAttendance)

      // 11. Initial Employee Payments
      val initialEmpPayments = listOf(
        EmployeePaymentEntity(
          employeeId = "EMP-001",
          employeeName = "Rohit Vishwakarma",
          paymentDate = "2026-11-05",
          formattedDate = "05 Nov, 26",
          amount = 3500.0,
          paymentMode = "CASH",
          relatedEvent = "Festival Week Wages",
          paymentReference = "SAL-2026-11-01",
          remainingBalance = 0.0,
          paymentType = "SALARY",
          notes = "5 days full payment settlement"
        ),
        EmployeePaymentEntity(
          employeeId = "EMP-002",
          employeeName = "Sunil Barman",
          paymentDate = "2026-11-06",
          formattedDate = "06 Nov, 26",
          amount = 1500.0,
          paymentMode = "UPI",
          relatedEvent = "Advance Wages",
          paymentReference = "ADV-2026-11-02",
          remainingBalance = 1000.0,
          paymentType = "ADVANCE",
          notes = "Advance payment issued"
        )
      )
      db.employeePaymentDao().insertAll(initialEmpPayments)

      // 12. Initial Notifications
      val initialNotifications = listOf(
        NotificationEntity(
          title = "Balance Payment Alert",
          message = "Pooja Singh (#35) has ₹10,000 pending balance due. Send WhatsApp reminder.",
          type = "DUE_ALERT",
          isRead = false
        ),
        NotificationEntity(
          title = "Low Stock Alert",
          message = "Cold Pyro Gun stock is only 12 pcs remaining. Plan new supply purchase.",
          type = "LOW_STOCK",
          isRead = false
        ),
        NotificationEntity(
          title = "Employee & ERP Active",
          message = "Employee attendance, wage calculations, and admin ERP reports are active.",
          type = "SYNC",
          isRead = true
        )
      )
      initialNotifications.forEach { db.notificationDao().insertNotification(it) }
    }
  }
}
