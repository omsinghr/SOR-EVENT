package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppTab
import com.example.ui.HomeSubTab
import com.example.ui.theme.SoePrimary
import com.example.ui.theme.SoePrimaryDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VyaparAmber
import com.example.ui.theme.VyaparBlue
import com.example.ui.theme.VyaparGreen
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import com.example.ui.util.AppLanguage
import com.example.ui.util.AppStrings

@Composable
fun TopHeaderBar(
  activeTab: AppTab,
  homeSubTab: HomeSubTab,
  onHomeSubTabChange: (HomeSubTab) -> Unit,
  unreadCount: Int,
  isSyncing: Boolean,
  onSyncClick: () -> Unit,
  onAlertsClick: () -> Unit,
  onSettingsClick: () -> Unit,
  currentLanguage: AppLanguage = AppLanguage.ENGLISH,
  onToggleLanguage: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  var currentTime by remember { mutableStateOf("11:51") }

  LaunchedEffect(Unit) {
    while (true) {
      val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
      currentTime = sdf.format(Date())
      delay(30000)
    }
  }

  Surface(
    modifier = modifier.fillMaxWidth(),
    color = Color.White,
    shadowElevation = 2.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .statusBarsPadding()
        .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
      // Status Bar Mockup
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = currentTime,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          color = TextSecondary
        )
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Box(
            modifier = Modifier
              .background(Color(0xFFF1F5F9), RoundedCornerShape(4.dp))
              .padding(horizontal = 4.dp, vertical = 1.dp)
          ) {
            Text(
              text = "VoLTE 5G",
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              color = TextSecondary
            )
          }
          Icon(
            imageVector = Icons.Default.Wifi,
            contentDescription = "Wi-Fi",
            tint = TextSecondary,
            modifier = Modifier.size(13.dp)
          )
          Icon(
            imageVector = Icons.Default.BatteryFull,
            contentDescription = "Battery",
            tint = VyaparGreen,
            modifier = Modifier.size(14.dp)
          )
        }
      }

      // Main Branding Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Circular SOE Gradient Badge
          Box(
            modifier = Modifier
              .size(40.dp)
              .background(
                brush = Brush.linearGradient(listOf(SoePrimary, VyaparAmber)),
                shape = CircleShape
              )
              .padding(2.dp)
              .clip(CircleShape)
              .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "SOE",
              color = Color.White,
              fontWeight = FontWeight.Black,
              fontSize = 13.sp,
              letterSpacing = (-0.5).sp
            )
          }

          Column {
            Text(
              text = "SHREE OM EVENT UMARIA",
              fontSize = 15.sp,
              fontWeight = FontWeight.ExtraBold,
              color = TextPrimary,
              letterSpacing = (-0.3).sp
            )
            Text(
              text = "Event ERP & Stock Manager",
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
              color = TextSecondary
            )
          }
        }

        // Header Actions (Language, Sync, Notifications, Admin)
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          // Language Switcher Pill (Clean English ERP)
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(16.dp))
              .background(Color(0xFFEFF6FF))
              .border(
                1.dp,
                Color(0xFF3B82F6),
                RoundedCornerShape(16.dp)
              )
              .clickable(onClick = onToggleLanguage)
              .padding(horizontal = 8.dp, vertical = 4.dp)
              .testTag("language_toggle_button"),
            contentAlignment = Alignment.Center
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
              Text(
                text = "🌐",
                fontSize = 11.sp
              )
              Text(
                text = "EN",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1D4ED8)
              )
            }
          }

          // Cloud Sync button
          val infiniteTransition = rememberInfiniteTransition(label = "sync")
          val rotation by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
              animation = tween(1000, easing = LinearEasing),
              repeatMode = RepeatMode.Restart
            ),
            label = "spin"
          )

          IconButton(
            onClick = onSyncClick,
            modifier = Modifier.testTag("sync_button")
          ) {
            if (isSyncing) {
              Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = "Syncing",
                tint = VyaparBlue,
                modifier = Modifier
                  .size(20.dp)
                  .rotate(rotation)
              )
            } else {
              Icon(
                imageVector = Icons.Default.CloudDone,
                contentDescription = "Synced",
                tint = VyaparGreen,
                modifier = Modifier.size(20.dp)
              )
            }
          }

          // Bell Notification Button with Badge
          Box(contentAlignment = Alignment.TopEnd) {
            IconButton(
              onClick = onAlertsClick,
              modifier = Modifier.testTag("notification_button")
            ) {
              Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Alerts",
                tint = TextPrimary,
                modifier = Modifier.size(20.dp)
              )
            }
            if (unreadCount > 0) {
              Box(
                modifier = Modifier
                  .offset(x = (-6).dp, y = 6.dp)
                  .size(16.dp)
                  .background(SoePrimary, CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = if (unreadCount > 9) "9+" else unreadCount.toString(),
                  color = Color.White,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          // Admin / Settings gear
          IconButton(
            onClick = onSettingsClick,
            modifier = Modifier.testTag("admin_settings_button")
          ) {
            Icon(
              imageVector = Icons.Default.Settings,
              contentDescription = "Settings",
              tint = TextSecondary,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }

      // Pill Tabs (Only visible when HOME is active)
      if (activeTab == AppTab.HOME) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Pill 1: Transaction Details
          val isTxn = homeSubTab == HomeSubTab.TRANSACTIONS
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(24.dp))
              .background(if (isTxn) Color(0xFFFFEBEE) else Color.White)
              .border(
                width = if (isTxn) 2.dp else 1.dp,
                color = if (isTxn) SoePrimary else Color(0xFFCBD5E1),
                shape = RoundedCornerShape(24.dp)
              )
              .clickable { onHomeSubTabChange(HomeSubTab.TRANSACTIONS) }
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Transaction Details",
              fontSize = 12.sp,
              fontWeight = if (isTxn) FontWeight.Bold else FontWeight.Medium,
              color = if (isTxn) SoePrimary else TextSecondary
            )
          }

          // Pill 2: Party Details
          val isParty = homeSubTab == HomeSubTab.PARTY
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(24.dp))
              .background(if (isParty) Color(0xFFFFEBEE) else Color.White)
              .border(
                width = if (isParty) 2.dp else 1.dp,
                color = if (isParty) SoePrimary else Color(0xFFCBD5E1),
                shape = RoundedCornerShape(24.dp)
              )
              .clickable { onHomeSubTabChange(HomeSubTab.PARTY) }
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Party Directory",
              fontSize = 12.sp,
              fontWeight = if (isParty) FontWeight.Bold else FontWeight.Medium,
              color = if (isParty) SoePrimary else TextSecondary
            )
          }
        }
      }
    }
  }
}

@Composable
fun AddSaleFab(
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Button(
    onClick = onClick,
    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE50938)),
    shape = RoundedCornerShape(28.dp),
    elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp, pressedElevation = 12.dp),
    border = androidx.compose.foundation.BorderStroke(2.dp, Color.White),
    modifier = modifier.testTag("add_new_sale_fab")
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
      Box(
        modifier = Modifier
          .size(24.dp)
          .background(Color.White.copy(alpha = 0.25f), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "₹",
          color = Color.White,
          fontWeight = FontWeight.Black,
          fontSize = 13.sp
        )
      }
      Text(
        text = "Add New Sale",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        letterSpacing = 0.3.sp
      )
    }
  }
}

@Composable
fun BottomNavBar(
  activeTab: AppTab,
  onTabSelected: (AppTab) -> Unit,
  currentLanguage: AppLanguage = AppLanguage.ENGLISH,
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier
      .fillMaxWidth()
      .navigationBarsPadding(),
    color = Color.White,
    shadowElevation = 12.dp,
    border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0xFFE2E8F0))
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 6.dp, horizontal = 2.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // 1. HOME
      BottomNavItem(
        icon = Icons.Default.Home,
        label = AppStrings.tabHome(currentLanguage),
        isSelected = activeTab == AppTab.HOME,
        onClick = { onTabSelected(AppTab.HOME) },
        testTag = "nav_home"
      )

      // 2. DASHBOARD (Analytics)
      BottomNavItem(
        icon = Icons.Default.BarChart,
        label = AppStrings.tabDashboard(currentLanguage),
        isSelected = activeTab == AppTab.DASHBOARD,
        onClick = { onTabSelected(AppTab.DASHBOARD) },
        testTag = "nav_dashboard"
      )

      // 3. ITEMS (Stock)
      BottomNavItem(
        icon = Icons.Default.Inventory2,
        label = AppStrings.tabItems(currentLanguage),
        isSelected = activeTab == AppTab.ITEMS,
        onClick = { onTabSelected(AppTab.ITEMS) },
        testTag = "nav_items"
      )

      // 4. ALERTS / OVERDUE
      BottomNavItem(
        icon = Icons.Default.Menu,
        label = AppStrings.tabAlerts(currentLanguage),
        isSelected = activeTab == AppTab.ALERTS,
        onClick = { onTabSelected(AppTab.ALERTS) },
        testTag = "nav_alerts"
      )

      // 5. ADMIN (Admin ERP Dashboard)
      BottomNavItem(
        icon = Icons.Default.AdminPanelSettings,
        label = AppStrings.tabAdmin(currentLanguage),
        isSelected = activeTab == AppTab.ADMIN,
        onClick = { onTabSelected(AppTab.ADMIN) },
        testTag = "nav_admin"
      )
    }
  }
}

@Composable
private fun BottomNavItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  isSelected: Boolean,
  onClick: () -> Unit,
  testTag: String
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clickable(onClick = onClick)
      .padding(horizontal = 6.dp, vertical = 4.dp)
      .testTag(testTag)
  ) {
    Icon(
      imageVector = icon,
      contentDescription = label,
      tint = if (isSelected) VyaparBlue else Color(0xFF94A3B8),
      modifier = Modifier.size(22.dp)
    )
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = label,
      fontSize = 10.sp,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
      color = if (isSelected) VyaparBlue else Color(0xFF64748B)
    )
  }
}

@Composable
private fun BottomNavCrownItem(
  label: String,
  isSelected: Boolean,
  onClick: () -> Unit,
  testTag: String
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clickable(onClick = onClick)
      .padding(horizontal = 6.dp, vertical = 4.dp)
      .testTag(testTag)
  ) {
    Box(
      modifier = Modifier
        .size(22.dp)
        .background(VyaparAmber, CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = "₹",
        color = Color.White,
        fontWeight = FontWeight.Black,
        fontSize = 11.sp
      )
    }
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = label,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      color = if (isSelected) VyaparAmber else Color(0xFFD97706)
    )
  }
}
