package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

data class BookingItem(
  val id: String = "",
  val name: String,
  val qty: Double,
  val unit: String,
  val rate: Double,
  val total: Double
)

@Entity(tableName = "bookings")
data class BookingEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val invoiceNumber: String,
  val salutation: String,
  val customerName: String,
  val customerPhone: String,
  val customerAltPhone: String = "",
  val customerAddress: String = "",
  val eventVenueAddress: String,
  val eventDate: String, // YYYY-MM-DD
  val formattedDate: String,
  val eventType: String,
  val itemsJson: String, // JSON representation of List<BookingItem>
  val totalAmount: Double,
  val advancePaid: Double,
  val balanceDue: Double,
  val estimatedCost: Double,
  val paymentMode: String, // "CASH", "UPI", "BANK", "CREDIT"
  val status: String, // "CONFIRMED", "PAYMENT-IN", "PENDING DUE", "CANCELLED", "COMPLETED"
  val createdAt: Long = System.currentTimeMillis(),
  val synced: Boolean = true,
  val isStockDeducted: Boolean = true
)

@Entity(tableName = "inventory_items")
data class InventoryItemEntity(
  @PrimaryKey
  val id: String,
  val name: String,
  val stock: Double,
  val unit: String, // "Pieces", "Kg", "Set", "Pkt"
  val rate: Double,
  val purchaseCost: Double = 0.0,
  val minAlertStock: Double = 5.0,
  val category: String = "Pyro & FX",
  val batchNumber: String = "B-2026-01",
  val serialNumber: String = "SN-SOE-001",
  val defaultDiscountPercent: Double = 0.0,
  val sku: String = id,
  val currentMarketPrice: Double = rate,
  val supplierName: String = "Gwalior Fireworks & Event Suppliers",
  val supplierMobile: String = "9425112233",
  val purchaseDate: String = "2026-10-15",
  val description: String = "",
  val itemImage: String = "",
  val previousPurchasePrice: Double = purchaseCost,
  val priceChangeDate: String = "2026-10-15"
)

@Entity(tableName = "item_price_history")
data class ItemPriceHistoryEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val itemId: String,
  val itemName: String,
  val previousPrice: Double,
  val newPrice: Double,
  val currentMarketPrice: Double = newPrice,
  val changeDate: String, // YYYY-MM-DD
  val changeFormattedDate: String,
  val supplierName: String = "",
  val reason: String = "Purchase Rate Update"
)

@Entity(tableName = "purchases")
data class PurchaseEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val billNumber: String,
  val vendorName: String,
  val vendorPhone: String = "",
  val purchaseDate: String,
  val formattedDate: String,
  val itemName: String,
  val quantity: Double,
  val unit: String,
  val rate: Double,
  val totalAmount: Double,
  val paidAmount: Double,
  val dueAmount: Double,
  val paymentMode: String = "UPI", // CASH, UPI, BANK, CREDIT
  val category: String = "Raw Material"
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val expenseTitle: String,
  val category: String, // "Generator & Diesel", "Labor & Wages", "Transport & Freight", "Tent & Decoration", "Catering & Snacks", "Other"
  val amount: Double,
  val expenseDate: String,
  val formattedDate: String,
  val paymentMode: String = "CASH",
  val remarks: String = "",
  val linkedBookingId: Long? = null
)

@Entity(tableName = "customer_payments")
data class CustomerPaymentEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val customerName: String,
  val customerPhone: String,
  val paymentDate: String,
  val formattedDate: String,
  val amount: Double,
  val paymentType: String, // "PAYMENT_IN" (Deposit) or "PAYMENT_OUT" (Refund/Expense)
  val paymentMode: String, // "CASH", "UPI", "BANK"
  val receiptNumber: String,
  val bookingId: Long? = null,
  val note: String = ""
)

@Entity(tableName = "orders")
data class OrderEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val orderNumber: String,
  val orderType: String, // "SALE_ORDER" or "PURCHASE_ORDER"
  val partyName: String,
  val partyPhone: String,
  val orderDate: String,
  val deliveryDate: String,
  val itemsJson: String,
  val totalAmount: Double,
  val advanceAmount: Double,
  val status: String = "OPEN" // "OPEN", "COMPLETED", "CANCELLED"
)

@Entity(tableName = "employees")
data class EmployeeEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val employeeId: String, // e.g. "EMP-001"
  val name: String,
  val mobile: String,
  val address: String = "Station Road, Umaria",
  val joiningDate: String = "2026-01-10",
  val category: String = "Sound Operator", // Designation / Role
  val dailyWage: Double = 600.0, // Daily Wage
  val photoUrl: String = "",
  val isActive: Boolean = true
)

@Entity(tableName = "employee_attendance")
data class EmployeeAttendanceEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val employeeId: String,
  val employeeName: String,
  val date: String, // YYYY-MM-DD
  val formattedDate: String,
  val status: String, // "PRESENT", "ABSENT", "HALF_DAY", "LEAVE"
  val dailyRate: Double = 600.0,
  val eventReference: String = "",
  val notes: String = ""
)

@Entity(tableName = "employee_payments")
data class EmployeePaymentEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val employeeId: String,
  val employeeName: String,
  val paymentDate: String,
  val formattedDate: String,
  val amount: Double,
  val paymentMode: String = "CASH", // CASH, UPI, BANK
  val relatedEvent: String = "",
  val paymentReference: String = "",
  val remainingBalance: Double = 0.0,
  val paymentType: String = "SALARY", // SALARY, ADVANCE, BONUS
  val notes: String = ""
)

@Entity(tableName = "business_profile")
data class BusinessProfileEntity(
  @PrimaryKey
  val id: Int = 1,
  val businessName: String = "SHREE OM EVENT UMARIA",
  val tagline: String = "Event Booking & Stock Manager ERP",
  val gstin: String = "",
  val showGstin: Boolean = false,
  val phone1: String = "9584249750",
  val showPhone1: Boolean = true,
  val phone2: String = "9876543210",
  val email: String = "shriomeventumaria@gmail.com",
  val address: String = "Village -Near By Society Karkeli,(Rampur) District- Umaria, Madhya Pradesh",
  val pincode: String = "484661",
  val description: String = "Event Management, Wedding Entry, Sound & Stage Decoration",
  val state: String = "Madhya Pradesh",
  val businessType: String = "Service",
  val showBusinessType: Boolean = true,
  val category: String = "Events & Decorations",
  val showCategory: Boolean = true,
  val pan: String = "",
  val terms: String = "Thank you for choosing Shree Om Event! We look forward to serving you again.",
  val cardTheme: String = "classic-red", // "classic-red", "royal-blue", "emerald-green", "dark-gold"
  val digitalSignaturePoints: String = "", // serialized points of signature
  val dailyBookingLimit: Int = 3,
  val adminPin: String = "1234",
  val apiSyncUrl: String = "https://api.shreeomevent.in/v1/sync",
  val apiWebhookUrl: String = "https://api.shreeomevent.in/v1/webhook",
  val isRealtimeSyncEnabled: Boolean = true,
  val lastSyncedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val title: String,
  val message: String,
  val type: String, // "DUE_ALERT", "LOW_STOCK", "CAPACITY_WARNING", "SYNC"
  val timestamp: Long = System.currentTimeMillis(),
  val isRead: Boolean = false
)
