package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BusinessProfileEntity
import com.example.ui.MainViewModel
import com.example.ui.components.ThemePickerDialog
import com.example.ui.components.VisitingCardView
import com.example.ui.theme.SoePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VyaparBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusinessProfileScreen(
  viewModel: MainViewModel,
  profile: BusinessProfileEntity,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  // Tabs: Basic Details vs Business Details
  var selectedTab by remember { mutableStateOf(0) } // 0 = Basic, 1 = Business
  var showThemePicker by remember { mutableStateOf(false) }

  // Form mutable states synced from profile
  var businessName by remember(profile) { mutableStateOf(profile.businessName) }
  var gstin by remember(profile) { mutableStateOf(profile.gstin) }
  var showGstin by remember(profile) { mutableStateOf(profile.showGstin) }
  var phone1 by remember(profile) { mutableStateOf(profile.phone1) }
  var showPhone1 by remember(profile) { mutableStateOf(profile.showPhone1) }
  var phone2 by remember(profile) { mutableStateOf(profile.phone2) }
  var email by remember(profile) { mutableStateOf(profile.email) }
  var address by remember(profile) { mutableStateOf(profile.address) }
  var pincode by remember(profile) { mutableStateOf(profile.pincode) }
  var description by remember(profile) { mutableStateOf(profile.description) }

  var state by remember(profile) { mutableStateOf(profile.state) }
  var stateExpanded by remember { mutableStateOf(false) }
  var businessType by remember(profile) { mutableStateOf(profile.businessType) }
  var businessTypeExpanded by remember { mutableStateOf(false) }
  var showBusinessType by remember(profile) { mutableStateOf(profile.showBusinessType) }
  var category by remember(profile) { mutableStateOf(profile.category) }
  var categoryExpanded by remember { mutableStateOf(false) }
  var showCategory by remember(profile) { mutableStateOf(profile.showCategory) }
  var pan by remember(profile) { mutableStateOf(profile.pan) }
  var terms by remember(profile) { mutableStateOf(profile.terms) }

  // Live updated profile instance for preview
  val liveProfile = remember(
    profile, businessName, gstin, showGstin, phone1, showPhone1, phone2,
    email, address, pincode, description, state, businessType, showBusinessType,
    category, showCategory, pan, terms
  ) {
    profile.copy(
      businessName = businessName,
      gstin = gstin,
      showGstin = showGstin,
      phone1 = phone1,
      showPhone1 = showPhone1,
      phone2 = phone2,
      email = email,
      address = address,
      pincode = pincode,
      description = description,
      state = state,
      businessType = businessType,
      showBusinessType = showBusinessType,
      category = category,
      showCategory = showCategory,
      pan = pan,
      terms = terms
    )
  }

  if (showThemePicker) {
    ThemePickerDialog(
      currentTheme = profile.cardTheme,
      onDismiss = { showThemePicker = false },
      onSelectTheme = { themeKey ->
        viewModel.saveBusinessProfile(profile.copy(cardTheme = themeKey))
        showThemePicker = false
      }
    )
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp, vertical = 6.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Live Visiting Card Preview
    item {
      VisitingCardView(
        profile = liveProfile,
        onShareClick = { viewModel.shareVisitingCard(context, liveProfile) },
        onThemeSelectClick = { showThemePicker = true }
      )
    }

    // 2. Segment Tabs (Basic Details vs Business Details)
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color.White, RoundedCornerShape(12.dp))
          .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
      ) {
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selectedTab == 0) SoePrimary else Color.Transparent)
            .clickable { selectedTab = 0 }
            .padding(vertical = 10.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "Basic Details",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (selectedTab == 0) Color.White else TextSecondary
          )
        }

        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selectedTab == 1) SoePrimary else Color.Transparent)
            .clickable { selectedTab = 1 }
            .padding(vertical = 10.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "Business Details",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (selectedTab == 1) Color.White else TextSecondary
          )
        }
      }
    }

    // 3. Form Content
    if (selectedTab == 0) {
      // TAB 1: BASIC DETAILS
      item {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = Color.White,
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            // Business Name
            OutlinedTextField(
              value = businessName,
              onValueChange = { businessName = it },
              label = { Text("Business Name") },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("profile_business_name_input"),
              singleLine = true
            )

            // GSTIN + Show Toggle
            Column {
              OutlinedTextField(
                value = gstin,
                onValueChange = { gstin = it },
                label = { Text("GSTIN (Optional)") },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("profile_gstin_input"),
                singleLine = true
              )
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(text = "Show on card", fontSize = 11.sp, color = TextSecondary)
                Spacer(modifier = Modifier.width(6.dp))
                Switch(
                  checked = showGstin,
                  onCheckedChange = { showGstin = it },
                  colors = SwitchDefaults.colors(checkedThumbColor = SoePrimary)
                )
              }
            }

            // Phone 1 + Show Toggle
            Column {
              OutlinedTextField(
                value = phone1,
                onValueChange = { phone1 = it },
                label = { Text("Phone Number 1") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("profile_phone1_input"),
                singleLine = true
              )
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(text = "Show on card", fontSize = 11.sp, color = TextSecondary)
                Spacer(modifier = Modifier.width(6.dp))
                Switch(
                  checked = showPhone1,
                  onCheckedChange = { showPhone1 = it },
                  colors = SwitchDefaults.colors(checkedThumbColor = SoePrimary)
                )
              }
            }

            // Phone 2
            OutlinedTextField(
              value = phone2,
              onValueChange = { phone2 = it },
              label = { Text("Phone Number 2 (Optional)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )

            // Email ID
            OutlinedTextField(
              value = email,
              onValueChange = { email = it },
              label = { Text("Email ID") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )

            // Address
            OutlinedTextField(
              value = address,
              onValueChange = { address = it },
              label = { Text("Business Address") },
              modifier = Modifier.fillMaxWidth(),
              minLines = 2
            )

            // Pincode
            OutlinedTextField(
              value = pincode,
              onValueChange = { pincode = it },
              label = { Text("Pincode") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )

            // Description
            OutlinedTextField(
              value = description,
              onValueChange = { description = it },
              label = { Text("Business Description / Services") },
              modifier = Modifier.fillMaxWidth(),
              minLines = 2
            )
          }
        }
      }
    } else {
      // TAB 2: BUSINESS DETAILS
      item {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = Color.White,
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            // State Dropdown
            val states = listOf("Madhya Pradesh", "Uttar Pradesh", "Maharashtra", "Delhi", "Rajasthan", "Gujarat", "Other")
            ExposedDropdownMenuBox(
              expanded = stateExpanded,
              onExpandedChange = { stateExpanded = it }
            ) {
              OutlinedTextField(
                value = state,
                onValueChange = {},
                readOnly = true,
                label = { Text("State") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = stateExpanded) },
                modifier = Modifier
                  .menuAnchor()
                  .fillMaxWidth()
              )
              ExposedDropdownMenu(
                expanded = stateExpanded,
                onDismissRequest = { stateExpanded = false }
              ) {
                states.forEach { s ->
                  DropdownMenuItem(text = { Text(s) }, onClick = { state = s; stateExpanded = false })
                }
              }
            }

            // Business Type
            val businessTypes = listOf("Service", "Retailer", "Wholesaler", "Distributor", "Manufacturer", "Event Agency")
            Column {
              ExposedDropdownMenuBox(
                expanded = businessTypeExpanded,
                onExpandedChange = { businessTypeExpanded = it }
              ) {
                OutlinedTextField(
                  value = businessType,
                  onValueChange = {},
                  readOnly = true,
                  label = { Text("Business Type") },
                  trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = businessTypeExpanded) },
                  modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
                )
                ExposedDropdownMenu(
                  expanded = businessTypeExpanded,
                  onDismissRequest = { businessTypeExpanded = false }
                ) {
                  businessTypes.forEach { bt ->
                    DropdownMenuItem(text = { Text(bt) }, onClick = { businessType = bt; businessTypeExpanded = false })
                  }
                }
              }
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(text = "Show on card", fontSize = 11.sp, color = TextSecondary)
                Spacer(modifier = Modifier.width(6.dp))
                Switch(
                  checked = showBusinessType,
                  onCheckedChange = { showBusinessType = it },
                  colors = SwitchDefaults.colors(checkedThumbColor = SoePrimary)
                )
              }
            }

            // Business Category
            val categories = listOf("Events & Decorations", "Sound & Stage", "Photography & Video", "Catering & Tent", "Pyrotechnics")
            Column {
              ExposedDropdownMenuBox(
                expanded = categoryExpanded,
                onExpandedChange = { categoryExpanded = it }
              ) {
                OutlinedTextField(
                  value = category,
                  onValueChange = {},
                  readOnly = true,
                  label = { Text("Business Category") },
                  trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                  modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
                )
                ExposedDropdownMenu(
                  expanded = categoryExpanded,
                  onDismissRequest = { categoryExpanded = false }
                ) {
                  categories.forEach { cat ->
                    DropdownMenuItem(text = { Text(cat) }, onClick = { category = cat; categoryExpanded = false })
                  }
                }
              }
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(text = "Show on card", fontSize = 11.sp, color = TextSecondary)
                Spacer(modifier = Modifier.width(6.dp))
                Switch(
                  checked = showCategory,
                  onCheckedChange = { showCategory = it },
                  colors = SwitchDefaults.colors(checkedThumbColor = SoePrimary)
                )
              }
            }

            // PAN Number
            OutlinedTextField(
              value = pan,
              onValueChange = { pan = it.uppercase() },
              label = { Text("PAN Number (Optional)") },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )

            // Invoice Notes / Terms
            OutlinedTextField(
              value = terms,
              onValueChange = { terms = it },
              label = { Text("Invoice Notes / Terms & Conditions") },
              modifier = Modifier.fillMaxWidth(),
              minLines = 2
            )
          }
        }
      }
    }

    // 4. Save and Cancel Actions
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedButton(
          onClick = { viewModel.showToast("Changes discarded") },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.weight(1f)
        ) {
          Text("Cancel", fontWeight = FontWeight.Bold)
        }

        Button(
          onClick = {
            viewModel.saveBusinessProfile(liveProfile)
          },
          colors = ButtonDefaults.buttonColors(containerColor = SoePrimary),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .weight(1f)
            .testTag("save_profile_button")
        ) {
          Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(4.dp))
          Text("Save Profile", fontWeight = FontWeight.Bold, color = Color.White)
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(60.dp))
    }
  }
}
