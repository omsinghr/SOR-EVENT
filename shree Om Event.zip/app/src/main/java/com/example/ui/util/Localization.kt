package com.example.ui.util

enum class AppLanguage {
  ENGLISH,
  HINDI
}

object AppStrings {
  // Navigation
  fun tabHome(lang: AppLanguage) = "HOME"
  fun tabDashboard(lang: AppLanguage) = "DASHBOARD"
  fun tabItems(lang: AppLanguage) = "ITEMS"
  fun tabAlerts(lang: AppLanguage) = "ALERTS"
  fun tabAdmin(lang: AppLanguage) = "ADMIN"

  // App Title & Brand
  fun brandName(lang: AppLanguage) = "SHREE OM EVENT & DECORATION"
  fun brandSubtitle(lang: AppLanguage) = "Umaria (M.P.) • Event ERP Manager"

  // Top Header Sub-Tabs
  fun subtabTransactions(lang: AppLanguage) = "TRANSACTIONS"
  fun subtabParties(lang: AppLanguage) = "PARTIES"
  fun subtabCalendar(lang: AppLanguage) = "CALENDAR"

  // Quick Action Buttons
  fun addNewSale(lang: AppLanguage) = "+ Add New Sale"
  fun addNewItem(lang: AppLanguage) = "+ Add Item"
  fun syncNow(lang: AppLanguage) = "🔄 Sync Now"
  fun syncing(lang: AppLanguage) = "Syncing in progress..."
  fun offlineMode(lang: AppLanguage) = "Offline Mode Ready"

  // Dashboard & KPI Cards
  fun totalSales(lang: AppLanguage) = "Total Sales (Sale Report)"
  fun netProfit(lang: AppLanguage) = "Net Profit"
  fun totalPurchases(lang: AppLanguage) = "Total Purchases"
  fun totalExpenses(lang: AppLanguage) = "Total Expenses"
  fun pendingReceivables(lang: AppLanguage) = "Pending Receivables"
  fun stockValuation(lang: AppLanguage) = "Stock Valuation"
  fun viewSource(lang: AppLanguage) = "View Source >"

  // Date Presets
  fun today(lang: AppLanguage) = "Today"
  fun yesterday(lang: AppLanguage) = "Yesterday"
  fun thisWeek(lang: AppLanguage) = "This Week"
  fun thisMonth(lang: AppLanguage) = "This Month"
  fun lastMonth(lang: AppLanguage) = "Last Month"
  fun thisYear(lang: AppLanguage) = "This Year"
  fun financialYear(lang: AppLanguage) = "Fiscal Year (FY)"

  // Filter Labels
  fun advancedFilterToggle(isExpanded: Boolean, lang: AppLanguage): String {
    return if (isExpanded) "Hide Advanced Filter ▲" else "Open Advanced Filter ▼"
  }
  fun bookingStatus(lang: AppLanguage) = "Booking Status:"
  fun paymentStatus(lang: AppLanguage) = "Payment Status:"
  fun paymentMode(lang: AppLanguage) = "Payment Mode:"
  fun applyFilter(count: Int, lang: AppLanguage) = "Apply Filter ($count Results)"
  fun reset(lang: AppLanguage) = "Reset"
  fun searchCustomer(lang: AppLanguage) = "Customer Name"
  fun searchBookingId(lang: AppLanguage) = "Booking ID / Bill #"

  // Status Codes
  fun all(lang: AppLanguage) = "All"
  fun confirmed(lang: AppLanguage) = "Confirmed"
  fun completed(lang: AppLanguage) = "Completed"
  fun pending(lang: AppLanguage) = "Pending Due"
  fun cancelled(lang: AppLanguage) = "Cancelled"
  fun paid(lang: AppLanguage) = "Paid in Full"
  fun partial(lang: AppLanguage) = "Partial"

  // Admin ERP Sections
  fun adminTitle(lang: AppLanguage) = "Admin ERP Dashboard"
  fun secBookings(lang: AppLanguage) = "📋 Bookings"
  fun secAdvance(lang: AppLanguage) = "💰 Advance"
  fun secCompleted(lang: AppLanguage) = "🏆 Completed"
  fun secCollection(lang: AppLanguage) = "💳 Collection"
  fun secCostProfit(lang: AppLanguage) = "📈 Cost & Profit"
  fun secEmployees(lang: AppLanguage) = "👷 Employees"
  fun secSettings(lang: AppLanguage) = "⚙️ Settings & Backup"

  // Common Financial Terms
  fun totalAmount(lang: AppLanguage) = "Total Amount"
  fun discount(lang: AppLanguage) = "Discount"
  fun netPayable(lang: AppLanguage) = "Net Payable"
  fun advancePaid(lang: AppLanguage) = "Advance Paid"
  fun balanceDue(lang: AppLanguage) = "Balance Due"

  // Inventory Subtabs
  fun stockList(lang: AppLanguage) = "📦 Stock List"
  fun purchaseHistory(lang: AppLanguage) = "🛒 Purchase Bills"
  fun priceComparison(lang: AppLanguage) = "📊 Price Comparison"
  fun valuation(lang: AppLanguage) = "💰 Stock Valuation"

  // Language Selection
  fun language(lang: AppLanguage) = "App Language"
  fun selectLanguage(lang: AppLanguage) = "Change Language"
}
