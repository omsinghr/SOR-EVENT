package com.example.data.model

import org.json.JSONArray
import org.json.JSONObject

object JsonHelper {
  fun serializeBookingItems(items: List<BookingItem>): String {
    val array = JSONArray()
    for (item in items) {
      val obj = JSONObject()
      obj.put("id", item.id)
      obj.put("name", item.name)
      obj.put("qty", item.qty)
      obj.put("unit", item.unit)
      obj.put("rate", item.rate)
      obj.put("total", item.total)
      array.put(obj)
    }
    return array.toString()
  }

  fun deserializeBookingItems(json: String?): List<BookingItem> {
    if (json.isNullOrBlank()) return emptyList()
    val list = mutableListOf<BookingItem>()
    try {
      val array = JSONArray(json)
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        list.add(
          BookingItem(
            id = obj.optString("id", ""),
            name = obj.optString("name", ""),
            qty = obj.optDouble("qty", 1.0),
            unit = obj.optString("unit", "Pieces"),
            rate = obj.optDouble("rate", 0.0),
            total = obj.optDouble("total", 0.0)
          )
        )
      }
    } catch (_: Exception) {
      // Fallback empty list on parsing failure
    }
    return list
  }
}
