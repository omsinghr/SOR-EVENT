package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Shree Om Event", appName)
  }

  @Test
  fun `test booking items JSON serialization in android environment`() {
    val items = listOf(
      com.example.data.model.BookingItem("itm_1", "Cold Pyro Gun Entry", 6.0, "Pieces", 600.0, 3600.0),
      com.example.data.model.BookingItem("itm_2", "Dry Ice / Low Fog Machine", 1.0, "Pieces", 3500.0, 3500.0)
    )
    val json = com.example.data.model.JsonHelper.serializeBookingItems(items)
    val deserialized = com.example.data.model.JsonHelper.deserializeBookingItems(json)
    assertEquals(2, deserialized.size)
    assertEquals("Cold Pyro Gun Entry", deserialized[0].name)
    assertEquals(6.0, deserialized[0].qty, 0.001)
    assertEquals(3600.0, deserialized[0].total, 0.001)
  }
}
