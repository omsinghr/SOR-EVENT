package com.example.data.repository

import com.example.data.local.BookingDao
import com.example.data.local.BusinessProfileDao
import com.example.data.local.CustomerPaymentDao
import com.example.data.local.EmployeeAttendanceDao
import com.example.data.local.EmployeeDao
import com.example.data.local.EmployeePaymentDao
import com.example.data.local.ExpenseDao
import com.example.data.local.InventoryDao
import com.example.data.local.ItemPriceHistoryDao
import com.example.data.local.NotificationDao
import com.example.data.local.OrderDao
import com.example.data.local.PurchaseDao
import com.example.data.model.BookingEntity
import com.example.data.model.BookingItem
import com.example.data.model.BusinessProfileEntity
import com.example.data.model.CustomerPaymentEntity
import com.example.data.model.EmployeeAttendanceEntity
import com.example.data.model.EmployeeEntity
import com.example.data.model.EmployeePaymentEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.InventoryItemEntity
import com.example.data.model.ItemPriceHistoryEntity
import com.example.data.model.JsonHelper
import com.example.data.model.NotificationEntity
import com.example.data.model.OrderEntity
import com.example.data.model.PurchaseEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class EventRepository(
  private val bookingDao: BookingDao,
  private val inventoryDao: InventoryDao,
  private val profileDao: BusinessProfileDao,
  private val notificationDao: NotificationDao,
  private val purchaseDao: PurchaseDao,
  private val expenseDao: ExpenseDao,
  private val paymentDao: CustomerPaymentDao,
  private val orderDao: OrderDao,
  private val itemPriceHistoryDao: ItemPriceHistoryDao,
  private val employeeDao: EmployeeDao,
  private val employeeAttendanceDao: EmployeeAttendanceDao,
  private val employeePaymentDao: EmployeePaymentDao
) {

  val allBookings: Flow<List<BookingEntity>> = bookingDao.getAllBookings()
  val allInventoryItems: Flow<List<InventoryItemEntity>> = inventoryDao.getAllItems()
  val businessProfile: Flow<BusinessProfileEntity?> = profileDao.getProfile()
  val notifications: Flow<List<NotificationEntity>> = notificationDao.getAllNotifications()
  val unreadNotificationCount: Flow<Int> = notificationDao.getUnreadCount()
  val allPurchases: Flow<List<PurchaseEntity>> = purchaseDao.getAllPurchases()
  val allExpenses: Flow<List<ExpenseEntity>> = expenseDao.getAllExpenses()
  val allPayments: Flow<List<CustomerPaymentEntity>> = paymentDao.getAllPayments()
  val allOrders: Flow<List<OrderEntity>> = orderDao.getAllOrders()
  val allPriceHistory: Flow<List<ItemPriceHistoryEntity>> = itemPriceHistoryDao.getAllPriceHistory()
  val allEmployees: Flow<List<EmployeeEntity>> = employeeDao.getAllEmployees()
  val allAttendance: Flow<List<EmployeeAttendanceEntity>> = employeeAttendanceDao.getAllAttendance()
  val allEmployeePayments: Flow<List<EmployeePaymentEntity>> = employeePaymentDao.getAllPayments()

  suspend fun createBooking(
    booking: BookingEntity,
    items: List<BookingItem>
  ): Long = withContext(Dispatchers.IO) {
    val bookingToInsert = booking.copy(isStockDeducted = true)
    val newId = bookingDao.insertBooking(bookingToInsert)

    // Record advance payment in customer_payments ledger
    if (booking.advancePaid > 0) {
      paymentDao.insertPayment(
        CustomerPaymentEntity(
          customerName = booking.customerName,
          customerPhone = booking.customerPhone,
          paymentDate = booking.eventDate,
          formattedDate = booking.formattedDate,
          amount = booking.advancePaid,
          paymentType = "PAYMENT_IN",
          paymentMode = booking.paymentMode,
          receiptNumber = "REC-${booking.invoiceNumber}",
          bookingId = newId,
          note = "Booking Advance: ${booking.eventType}"
        )
      )
    }

    // Atomically deduct inventory stock without duplicate deduction
    for (booked in items) {
      if (booked.id.isNotEmpty()) {
        val master = inventoryDao.getItemById(booked.id)
        if (master != null) {
          val newStock = (master.stock - booked.qty).coerceAtLeast(0.0)
          inventoryDao.updateStock(master.id, newStock)

          if (newStock <= master.minAlertStock) {
            notificationDao.insertNotification(
              NotificationEntity(
                title = "Low Stock Alert!",
                message = "${master.name} stock is only $newStock ${master.unit} remaining.",
                type = "LOW_STOCK"
              )
            )
          }
        }
      }
    }

    // Capacity limit check
    val profile = profileDao.getProfileSync() ?: BusinessProfileEntity()
    val dateBookings = bookingDao.getBookingsByDate(booking.eventDate).firstOrNull() ?: emptyList()
    if (dateBookings.size >= profile.dailyBookingLimit) {
      notificationDao.insertNotification(
        NotificationEntity(
          title = "Date Capacity Full Alert",
          message = "Maximum event limit (${profile.dailyBookingLimit}) reached for ${booking.formattedDate}.",
          type = "CAPACITY_WARNING"
        )
      )
    }

    // Overdue alert
    if (booking.balanceDue > 0) {
      notificationDao.insertNotification(
        NotificationEntity(
          title = "Balance Due Alert",
          message = "₹${booking.balanceDue} balance is due on invoice for ${booking.customerName}.",
          type = "DUE_ALERT"
        )
      )
    }

    newId
  }

  suspend fun cancelBooking(bookingId: Long) = withContext(Dispatchers.IO) {
    val booking = bookingDao.getBookingById(bookingId).firstOrNull() ?: return@withContext
    // Only restore stock if it was actually deducted
    if (booking.isStockDeducted) {
      val items = JsonHelper.deserializeBookingItems(booking.itemsJson)
      for (itm in items) {
        if (itm.id.isNotEmpty()) {
          val master = inventoryDao.getItemById(itm.id)
          if (master != null) {
            inventoryDao.updateStock(master.id, master.stock + itm.qty)
          }
        }
      }
    }
    val updatedBooking = booking.copy(status = "CANCELLED", isStockDeducted = false)
    bookingDao.updateBooking(updatedBooking)

    notificationDao.insertNotification(
      NotificationEntity(
        title = "Booking Cancelled",
        message = "Booking #${booking.id} (${booking.customerName}) cancelled. Items safely restored to inventory.",
        type = "SYNC"
      )
    )
  }

  suspend fun addPurchase(purchase: PurchaseEntity) = withContext(Dispatchers.IO) {
    val id = purchaseDao.insertPurchase(purchase)
    // Check if item exists in inventory and record price history if price changed
    val items = inventoryDao.getAllItems().firstOrNull() ?: emptyList()
    val matched = items.find { it.name.equals(purchase.itemName, ignoreCase = true) }
    if (matched != null) {
      if (purchase.rate != matched.purchaseCost) {
        itemPriceHistoryDao.insertPriceHistory(
          ItemPriceHistoryEntity(
            itemId = matched.id,
            itemName = matched.name,
            previousPrice = matched.purchaseCost,
            newPrice = purchase.rate,
            currentMarketPrice = matched.rate,
            changeDate = purchase.purchaseDate,
            changeFormattedDate = purchase.formattedDate,
            supplierName = purchase.vendorName,
            reason = "Purchase rate update as per bill #${purchase.billNumber}"
          )
        )
      }
      // Update inventory stock with newly purchased quantity and latest purchase price
      val updated = matched.copy(
        stock = matched.stock + purchase.quantity,
        previousPurchasePrice = matched.purchaseCost,
        purchaseCost = purchase.rate,
        priceChangeDate = purchase.purchaseDate,
        supplierName = purchase.vendorName,
        supplierMobile = purchase.vendorPhone
      )
      inventoryDao.updateItem(updated)
    }
    id
  }

  suspend fun addExpense(expense: ExpenseEntity) = withContext(Dispatchers.IO) {
    expenseDao.insertExpense(expense)
  }

  suspend fun recordCustomerPayment(payment: CustomerPaymentEntity) = withContext(Dispatchers.IO) {
    val payId = paymentDao.insertPayment(payment)
    // If linked to a booking and is PAYMENT_IN, deduct from balanceDue
    if (payment.bookingId != null && payment.paymentType == "PAYMENT_IN") {
      val booking = bookingDao.getBookingById(payment.bookingId).firstOrNull()
      if (booking != null) {
        val newAdvance = booking.advancePaid + payment.amount
        val newBalance = (booking.totalAmount - newAdvance).coerceAtLeast(0.0)
        val newStatus = if (newBalance == 0.0) "COMPLETED" else booking.status
        bookingDao.updateBooking(
          booking.copy(
            advancePaid = newAdvance,
            balanceDue = newBalance,
            status = newStatus
          )
        )
      }
    }
    payId
  }

  suspend fun addOrder(order: OrderEntity) = withContext(Dispatchers.IO) {
    orderDao.insertOrder(order)
  }

  suspend fun addInventoryItem(item: InventoryItemEntity) = withContext(Dispatchers.IO) {
    inventoryDao.insertItem(item)
    // Record initial price history
    itemPriceHistoryDao.insertPriceHistory(
      ItemPriceHistoryEntity(
        itemId = item.id,
        itemName = item.name,
        previousPrice = item.purchaseCost,
        newPrice = item.purchaseCost,
        currentMarketPrice = item.rate,
        changeDate = item.purchaseDate,
        changeFormattedDate = item.purchaseDate,
        supplierName = item.supplierName,
        reason = "Initial Stock Entry"
      )
    )
  }

  suspend fun updateInventoryItem(item: InventoryItemEntity) = withContext(Dispatchers.IO) {
    val old = inventoryDao.getItemById(item.id)
    if (old != null && old.purchaseCost != item.purchaseCost) {
      itemPriceHistoryDao.insertPriceHistory(
        ItemPriceHistoryEntity(
          itemId = item.id,
          itemName = item.name,
          previousPrice = old.purchaseCost,
          newPrice = item.purchaseCost,
          currentMarketPrice = item.rate,
          changeDate = item.priceChangeDate,
          changeFormattedDate = item.priceChangeDate,
          supplierName = item.supplierName,
          reason = "Item Edit & Rate Modification"
        )
      )
    }
    inventoryDao.updateItem(item)
  }

  suspend fun updateInventoryStock(id: String, stock: Double) = withContext(Dispatchers.IO) {
    inventoryDao.updateStock(id, stock)
  }

  suspend fun deleteInventoryItem(id: String) = withContext(Dispatchers.IO) {
    inventoryDao.deleteItem(id)
  }

  suspend fun markPurchaseAsPaid(purchaseId: Long) = withContext(Dispatchers.IO) {
    purchaseDao.markAsPaid(purchaseId)
  }

  suspend fun deleteExpense(expenseId: Long) = withContext(Dispatchers.IO) {
    expenseDao.deleteExpense(expenseId)
  }

  suspend fun updateOrderStatus(orderId: Long, status: String) = withContext(Dispatchers.IO) {
    orderDao.updateOrderStatus(orderId, status)
  }

  suspend fun updateProfile(profile: BusinessProfileEntity) = withContext(Dispatchers.IO) {
    profileDao.insertOrUpdate(profile)
  }

  // Employee Methods
  suspend fun addEmployee(employee: EmployeeEntity): Long = withContext(Dispatchers.IO) {
    employeeDao.insertEmployee(employee)
  }

  suspend fun updateEmployee(employee: EmployeeEntity) = withContext(Dispatchers.IO) {
    employeeDao.updateEmployee(employee)
  }

  suspend fun deleteEmployee(id: Long) = withContext(Dispatchers.IO) {
    employeeDao.deleteEmployee(id)
  }

  suspend fun recordAttendance(attendance: EmployeeAttendanceEntity): Long = withContext(Dispatchers.IO) {
    employeeAttendanceDao.insertAttendance(attendance)
  }

  suspend fun deleteAttendance(id: Long) = withContext(Dispatchers.IO) {
    employeeAttendanceDao.deleteAttendance(id)
  }

  suspend fun recordEmployeePayment(payment: EmployeePaymentEntity): Long = withContext(Dispatchers.IO) {
    employeePaymentDao.insertPayment(payment)
  }

  suspend fun deleteEmployeePayment(id: Long) = withContext(Dispatchers.IO) {
    employeePaymentDao.deletePayment(id)
  }

  suspend fun markAllNotificationsAsRead() = withContext(Dispatchers.IO) {
    notificationDao.markAllAsRead()
  }

  suspend fun clearAllNotifications() = withContext(Dispatchers.IO) {
    notificationDao.clearAll()
  }

  suspend fun syncWithServer(): Boolean = withContext(Dispatchers.IO) {
    val currentProfile = profileDao.getProfileSync() ?: BusinessProfileEntity()
    val updatedProfile = currentProfile.copy(
      lastSyncedTimestamp = System.currentTimeMillis()
    )
    profileDao.insertOrUpdate(updatedProfile)

    val bookingsCount = bookingDao.getAllBookings().firstOrNull()?.size ?: 0
    val itemsCount = inventoryDao.getAllItems().firstOrNull()?.size ?: 0
    val purchasesCount = purchaseDao.getAllPurchases().firstOrNull()?.size ?: 0
    val expensesCount = expenseDao.getAllExpenses().firstOrNull()?.size ?: 0
    val employeesCount = employeeDao.getAllEmployees().firstOrNull()?.size ?: 0

    notificationDao.insertNotification(
      NotificationEntity(
        title = "Cloud Real-Time Sync Complete",
        message = "$bookingsCount bookings, $itemsCount inventory items, $purchasesCount purchases, $expensesCount expenses, and $employeesCount employees synced successfully.",
        type = "SYNC"
      )
    )
    true
  }

  suspend fun exportDataAsJson(): String = withContext(Dispatchers.IO) {
    val root = JSONObject()
    val profile = profileDao.getProfileSync() ?: BusinessProfileEntity()
    val profileObj = JSONObject().apply {
      put("businessName", profile.businessName)
      put("phone1", profile.phone1)
      put("email", profile.email)
      put("address", profile.address)
      put("gstin", profile.gstin)
      put("businessType", profile.businessType)
      put("cardTheme", profile.cardTheme)
      put("dailyBookingLimit", profile.dailyBookingLimit)
    }
    root.put("profile", profileObj)

    val bookings = bookingDao.getAllBookings().firstOrNull() ?: emptyList()
    val bookingsArr = JSONArray()
    for (b in bookings) {
      bookingsArr.put(
        JSONObject().apply {
          put("id", b.id)
          put("invoiceNumber", b.invoiceNumber)
          put("customerName", b.customerName)
          put("customerPhone", b.customerPhone)
          put("eventVenueAddress", b.eventVenueAddress)
          put("eventDate", b.eventDate)
          put("formattedDate", b.formattedDate)
          put("eventType", b.eventType)
          put("totalAmount", b.totalAmount)
          put("advancePaid", b.advancePaid)
          put("balanceDue", b.balanceDue)
          put("paymentMode", b.paymentMode)
          put("status", b.status)
          put("itemsJson", b.itemsJson)
        }
      )
    }
    root.put("bookings", bookingsArr)

    val items = inventoryDao.getAllItems().firstOrNull() ?: emptyList()
    val itemsArr = JSONArray()
    for (item in items) {
      itemsArr.put(
        JSONObject().apply {
          put("id", item.id)
          put("name", item.name)
          put("stock", item.stock)
          put("unit", item.unit)
          put("rate", item.rate)
          put("purchaseCost", item.purchaseCost)
          put("category", item.category)
          put("batchNumber", item.batchNumber)
          put("serialNumber", item.serialNumber)
          put("currentMarketPrice", item.currentMarketPrice)
          put("supplierName", item.supplierName)
        }
      )
    }
    root.put("inventory", itemsArr)

    val employees = employeeDao.getAllEmployees().firstOrNull() ?: emptyList()
    val employeesArr = JSONArray()
    for (emp in employees) {
      employeesArr.put(
        JSONObject().apply {
          put("id", emp.id)
          put("employeeId", emp.employeeId)
          put("name", emp.name)
          put("mobile", emp.mobile)
          put("category", emp.category)
          put("dailyWage", emp.dailyWage)
        }
      )
    }
    root.put("employees", employeesArr)

    root.toString(2)
  }

  suspend fun generateSalesCsv(): String = withContext(Dispatchers.IO) {
    val bookings = bookingDao.getAllBookings().firstOrNull() ?: emptyList()
    val sb = StringBuilder()
    sb.append("Invoice ID,Date,Client Name,Phone,Event Type,Payment Mode,Total Amount,Advance Paid,Balance Due,Status\n")
    for (b in bookings) {
      sb.append("\"${b.invoiceNumber}\",")
      sb.append("\"${b.formattedDate}\",")
      sb.append("\"${b.customerName}\",")
      sb.append("\"${b.customerPhone}\",")
      sb.append("\"${b.eventType}\",")
      sb.append("\"${b.paymentMode}\",")
      sb.append("${b.totalAmount},")
      sb.append("${b.advancePaid},")
      sb.append("${b.balanceDue},")
      sb.append("\"${b.status}\"\n")
    }
    sb.toString()
  }
}
