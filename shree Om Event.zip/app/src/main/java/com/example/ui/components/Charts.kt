package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VyaparAmber
import com.example.ui.theme.VyaparBlue
import com.example.ui.theme.VyaparGreen

data class MonthlyData(
  val month: String,
  val sales: Double,
  val profit: Double
)

@Composable
fun MonthlySalesVsProfitChart(
  data: List<MonthlyData> = listOf(
    MonthlyData("Jul", 35000.0, 12000.0),
    MonthlyData("Aug", 48000.0, 17500.0),
    MonthlyData("Sep", 52000.0, 19200.0),
    MonthlyData("Oct", 78000.0, 29000.0),
    MonthlyData("Nov", 82500.0, 31200.0),
    MonthlyData("Dec", 95000.0, 36000.0)
  ),
  modifier: Modifier = Modifier
) {
  val maxVal = data.maxOfOrNull { it.sales } ?: 100000.0

  Column(modifier = modifier.fillMaxWidth()) {
    // Legend
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 8.dp),
      horizontalArrangement = Arrangement.End,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .background(VyaparBlue, RoundedCornerShape(2.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "Sales", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
      }
      Spacer(modifier = Modifier.width(12.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .background(VyaparGreen, RoundedCornerShape(2.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "Profit", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
      }
    }

    // Canvas Chart
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(170.dp)
    ) {
      Canvas(modifier = Modifier.fillMaxWidth().height(140.dp)) {
        val w = size.width
        val h = size.height
        val barGroupWidth = w / data.size
        val barWidth = 12.dp.toPx()
        val spacing = 3.dp.toPx()

        // Background horizontal grid lines
        val gridLines = 4
        for (i in 0..gridLines) {
          val y = (h / gridLines) * i
          drawLine(
            color = Color(0xFFF1F5F9),
            start = Offset(0f, y),
            end = Offset(w, y),
            strokeWidth = 1.dp.toPx()
          )
        }

        // Draw Bars
        data.forEachIndexed { index, item ->
          val groupCenterX = barGroupWidth * index + barGroupWidth / 2f
          val salesH = ((item.sales / maxVal) * h * 0.9f).toFloat().coerceAtLeast(4f)
          val profitH = ((item.profit / maxVal) * h * 0.9f).toFloat().coerceAtLeast(4f)

          // Sales Bar (Blue)
          drawRoundRect(
            color = Color(0xFF1976D2),
            topLeft = Offset(groupCenterX - barWidth - spacing / 2f, h - salesH),
            size = Size(barWidth, salesH),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
          )

          // Profit Bar (Green)
          drawRoundRect(
            color = Color(0xFF00C853),
            topLeft = Offset(groupCenterX + spacing / 2f, h - profitH),
            size = Size(barWidth, profitH),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
          )
        }
      }

      // X-Axis Labels Row below Canvas
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .align(Alignment.BottomCenter)
          .padding(top = 142.dp),
        horizontalArrangement = Arrangement.SpaceAround
      ) {
        data.forEach { item ->
          Text(
            text = item.month,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextSecondary
          )
        }
      }
    }
  }
}

@Composable
fun PaymentModesDoughnutChart(
  upiAmount: Double,
  cashAmount: Double,
  creditAmount: Double,
  modifier: Modifier = Modifier
) {
  val total = (upiAmount + cashAmount + creditAmount).coerceAtLeast(1.0)
  val upiRatio = (upiAmount / total).toFloat()
  val cashRatio = (cashAmount / total).toFloat()
  val creditRatio = (creditAmount / total).toFloat()

  Row(
    modifier = modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Canvas Doughnut
    Box(
      modifier = Modifier.size(110.dp),
      contentAlignment = Alignment.Center
    ) {
      Canvas(modifier = Modifier.size(100.dp)) {
        val strokeWidth = 18.dp.toPx()
        val radius = (size.minDimension - strokeWidth) / 2f
        val center = Offset(size.width / 2f, size.height / 2f)

        var startAngle = -90f

        // UPI slice
        val upiSweep = upiRatio * 360f
        drawArc(
          color = Color(0xFF00C853),
          startAngle = startAngle,
          sweepAngle = upiSweep,
          useCenter = false,
          topLeft = Offset(center.x - radius, center.y - radius),
          size = Size(radius * 2, radius * 2),
          style = Stroke(width = strokeWidth)
        )
        startAngle += upiSweep

        // Cash slice
        val cashSweep = cashRatio * 360f
        drawArc(
          color = Color(0xFFF57C00),
          startAngle = startAngle,
          sweepAngle = cashSweep,
          useCenter = false,
          topLeft = Offset(center.x - radius, center.y - radius),
          size = Size(radius * 2, radius * 2),
          style = Stroke(width = strokeWidth)
        )
        startAngle += cashSweep

        // Credit slice
        val creditSweep = creditRatio * 360f
        if (creditSweep > 0) {
          drawArc(
            color = Color(0xFFD32F2F),
            startAngle = startAngle,
            sweepAngle = creditSweep,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = strokeWidth)
          )
        }
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = "${(upiRatio * 100).toInt()}%",
          fontSize = 15.sp,
          fontWeight = FontWeight.Black,
          color = TextPrimary
        )
        Text(
          text = "Online",
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold,
          color = TextSecondary
        )
      }
    }

    // Legend & Amounts
    Column(
      modifier = Modifier.weight(1f),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // UPI
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .background(VyaparGreen, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "UPI / Online", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
          }
          Text(
            text = "₹ ${String.format("%,.0f", upiAmount)}",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        }
      }

      // Cash
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .background(VyaparAmber, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Cash", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
          }
          Text(
            text = "₹ ${String.format("%,.0f", cashAmount)}",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        }
      }

      // Credit / Due
      if (creditAmount > 0) {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .background(Color(0xFFD32F2F), CircleShape)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = "Credit / Due", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
            }
            Text(
              text = "₹ ${String.format("%,.0f", creditAmount)}",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFFD32F2F)
            )
          }
        }
      }
    }
  }
}
