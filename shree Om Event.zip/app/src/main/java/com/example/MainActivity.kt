package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FabPosition
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.AppTab
import com.example.ui.HomeSubTab
import com.example.ui.MainViewModel
import com.example.ui.components.AddEmployeeDialog
import com.example.ui.components.AddExpenseDialog
import com.example.ui.components.AddOrderDialog
import com.example.ui.components.AddPurchaseDialog
import com.example.ui.components.AddSaleFab
import com.example.ui.components.AdminPinDialog
import com.example.ui.components.BottomNavBar
import com.example.ui.components.DailyLimitDialog
import com.example.ui.components.EmployeeDetailDialog
import com.example.ui.components.ExpenseDetailDialog
import com.example.ui.components.FinancialFigureSourceModal
import com.example.ui.components.InvoicePreviewDialog
import com.example.ui.components.ItemDetailDialog
import com.example.ui.components.ItemPriceComparisonModal
import com.example.ui.components.NewBookingDialog
import com.example.ui.components.NewItemDialog
import com.example.ui.components.OrderDetailDialog
import com.example.ui.components.PartyLedgerDialog
import com.example.ui.components.PaymentReceiptDialog
import com.example.ui.components.PurchaseDetailDialog
import com.example.ui.components.RecordAttendanceDialog
import com.example.ui.components.RecordEmployeePaymentDialog
import com.example.ui.components.RecordPaymentDialog
import com.example.ui.components.TopHeaderBar
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AlertsScreen
import com.example.ui.screens.BusinessProfileScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.ReportsAnalyticsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SurfaceLight

class MainActivity : ComponentActivity() {

  private val viewModel: MainViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        MainApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun MainApp(viewModel: MainViewModel) {
  val context = LocalContext.current

  // Collect data states
  val appLanguage by viewModel.appLanguage.collectAsStateWithLifecycle()
  val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
  val homeSubTab by viewModel.homeSubTab.collectAsStateWithLifecycle()
  val statusFilter by viewModel.statusFilter.collectAsStateWithLifecycle()
  val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

  val bookings by viewModel.allBookings.collectAsStateWithLifecycle()
  val inventoryItems by viewModel.allItems.collectAsStateWithLifecycle()
  val profile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val notifications by viewModel.notifications.collectAsStateWithLifecycle()
  val unreadNotificationsCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()

  val purchases by viewModel.allPurchases.collectAsStateWithLifecycle()
  val expenses by viewModel.allExpenses.collectAsStateWithLifecycle()
  val payments by viewModel.allPayments.collectAsStateWithLifecycle()
  val orders by viewModel.allOrders.collectAsStateWithLifecycle()

  val employees by viewModel.allEmployees.collectAsStateWithLifecycle()
  val attendance by viewModel.allAttendance.collectAsStateWithLifecycle()
  val employeePayments by viewModel.allEmployeePayments.collectAsStateWithLifecycle()
  val priceHistory by viewModel.allPriceHistory.collectAsStateWithLifecycle()

  val datePreset by viewModel.datePreset.collectAsStateWithLifecycle()
  val reportCategoryTab by viewModel.reportCategoryTab.collectAsStateWithLifecycle()
  val reportsPaymentFilter by viewModel.reportsPaymentFilter.collectAsStateWithLifecycle()
  val reportsSearchQuery by viewModel.reportsSearchQuery.collectAsStateWithLifecycle()

  val showNewBookingModal by viewModel.showNewBookingModal.collectAsStateWithLifecycle()
  val showNewItemModal by viewModel.showNewItemModal.collectAsStateWithLifecycle()
  val showInvoicePreviewModal by viewModel.showInvoicePreviewModal.collectAsStateWithLifecycle()
  val selectedBookingForInvoice by viewModel.selectedBookingForInvoice.collectAsStateWithLifecycle()
  val showDailyLimitDialog by viewModel.showDailyLimitDialog.collectAsStateWithLifecycle()
  val showAdminPinDialog by viewModel.showAdminPinDialog.collectAsStateWithLifecycle()
  val showAddExpenseDialog by viewModel.showAddExpenseDialog.collectAsStateWithLifecycle()
  val showAddPurchaseDialog by viewModel.showAddPurchaseDialog.collectAsStateWithLifecycle()
  val showRecordPaymentDialog by viewModel.showRecordPaymentDialog.collectAsStateWithLifecycle()
  val showAddOrderDialog by viewModel.showAddOrderDialog.collectAsStateWithLifecycle()

  val selectedPartyForDetail by viewModel.selectedPartyForDetail.collectAsStateWithLifecycle()
  val showPartyDetailDialog by viewModel.showPartyDetailDialog.collectAsStateWithLifecycle()

  val selectedItemForDetail by viewModel.selectedItemForDetail.collectAsStateWithLifecycle()
  val showItemDetailDialog by viewModel.showItemDetailDialog.collectAsStateWithLifecycle()

  val selectedPurchaseForDetail by viewModel.selectedPurchaseForDetail.collectAsStateWithLifecycle()
  val showPurchaseDetailDialog by viewModel.showPurchaseDetailDialog.collectAsStateWithLifecycle()

  val selectedExpenseForDetail by viewModel.selectedExpenseForDetail.collectAsStateWithLifecycle()
  val showExpenseDetailDialog by viewModel.showExpenseDetailDialog.collectAsStateWithLifecycle()

  val selectedPaymentForDetail by viewModel.selectedPaymentForDetail.collectAsStateWithLifecycle()
  val showPaymentReceiptDialog by viewModel.showPaymentReceiptDialog.collectAsStateWithLifecycle()

  val selectedOrderForDetail by viewModel.selectedOrderForDetail.collectAsStateWithLifecycle()
  val showOrderDetailDialog by viewModel.showOrderDetailDialog.collectAsStateWithLifecycle()

  // New ERP Dialogs
  val selectedFinancialFigureType by viewModel.selectedFinancialFigureType.collectAsStateWithLifecycle()
  val showFinancialFigureModal by viewModel.showFinancialFigureModal.collectAsStateWithLifecycle()

  val showAddEmployeeDialog by viewModel.showAddEmployeeDialog.collectAsStateWithLifecycle()
  val showRecordAttendanceDialog by viewModel.showRecordAttendanceDialog.collectAsStateWithLifecycle()
  val showRecordEmployeePaymentDialog by viewModel.showRecordEmployeePaymentDialog.collectAsStateWithLifecycle()
  val selectedEmployeeForDetail by viewModel.selectedEmployeeForDetail.collectAsStateWithLifecycle()
  val showEmployeeDetailDialog by viewModel.showEmployeeDetailDialog.collectAsStateWithLifecycle()

  val selectedItemForPriceHistory by viewModel.selectedItemForPriceHistory.collectAsStateWithLifecycle()
  val showPriceHistoryModal by viewModel.showPriceHistoryModal.collectAsStateWithLifecycle()

  val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
  val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()
  val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

  // Handle toast notifications
  LaunchedEffect(toastMessage) {
    toastMessage?.let { msg ->
      Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
      viewModel.clearToast()
    }
  }

  // BackHandler to handle intuitive back navigation
  BackHandler(enabled = activeTab != AppTab.HOME || homeSubTab != HomeSubTab.TRANSACTIONS) {
    if (activeTab != AppTab.HOME) {
      viewModel.setActiveTab(AppTab.HOME)
    } else if (homeSubTab != HomeSubTab.TRANSACTIONS) {
      viewModel.setHomeSubTab(HomeSubTab.TRANSACTIONS)
    }
  }

  Scaffold(
    topBar = {
      TopHeaderBar(
        activeTab = activeTab,
        homeSubTab = homeSubTab,
        onHomeSubTabChange = { viewModel.setHomeSubTab(it) },
        unreadCount = unreadNotificationsCount,
        isSyncing = isSyncing,
        onSyncClick = { viewModel.syncNow() },
        onAlertsClick = { viewModel.setActiveTab(AppTab.ALERTS) },
        onSettingsClick = {
          viewModel.setActiveTab(AppTab.ADMIN)
        },
        currentLanguage = appLanguage,
        onToggleLanguage = { viewModel.toggleAppLanguage() }
      )
    },
    floatingActionButton = {
      AddSaleFab(onClick = { viewModel.openNewBookingModal() })
    },
    floatingActionButtonPosition = FabPosition.Center,
    bottomBar = {
      BottomNavBar(
        activeTab = activeTab,
        onTabSelected = { tab ->
          viewModel.setActiveTab(tab)
        },
        currentLanguage = appLanguage
      )
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(SurfaceLight)
        .padding(innerPadding)
    ) {
      when (activeTab) {
        AppTab.HOME -> {
          HomeScreen(
            viewModel = viewModel,
            bookings = bookings,
            subTab = homeSubTab,
            statusFilter = statusFilter,
            searchQuery = searchQuery
          )
        }
        AppTab.DASHBOARD -> {
          ReportsAnalyticsScreen(
            viewModel = viewModel,
            bookings = bookings,
            inventoryItems = inventoryItems,
            purchases = purchases,
            expenses = expenses,
            payments = payments,
            orders = orders,
            datePreset = datePreset,
            categoryTab = reportCategoryTab,
            paymentFilter = reportsPaymentFilter,
            searchQuery = reportsSearchQuery
          )
        }
        AppTab.ITEMS -> {
          InventoryScreen(
            viewModel = viewModel,
            items = inventoryItems,
            purchases = purchases,
            priceHistory = priceHistory
          )
        }
        AppTab.ALERTS -> {
          AlertsScreen(
            viewModel = viewModel,
            bookings = bookings,
            notifications = notifications
          )
        }
        AppTab.PROFILE -> {
          BusinessProfileScreen(
            viewModel = viewModel,
            profile = profile
          )
        }
        AppTab.ADMIN -> {
          AdminPanelScreen(
            viewModel = viewModel,
            profile = profile,
            isAdminUnlocked = isAdminUnlocked,
            isSyncing = isSyncing,
            bookings = bookings,
            inventoryItems = inventoryItems,
            purchases = purchases,
            expenses = expenses,
            payments = payments,
            employees = employees,
            attendance = attendance,
            employeePayments = employeePayments,
            priceHistory = priceHistory
          )
        }
      }
    }
  }

  // Modals & Dialogs
  if (showNewBookingModal) {
    NewBookingDialog(
      availableInventory = inventoryItems,
      dailyBookingLimit = profile.dailyBookingLimit,
      existingBookingsOnDate = bookings.count { it.eventDate == "2026-07-17" && it.status != "CANCELLED" },
      onDismiss = { viewModel.closeNewBookingModal() },
      onSubmit = { sal, name, phone, altPhone, cAddr, vAddr, date, type, items, total, adv, mode, autoWa ->
        viewModel.createBooking(
          salutation = sal,
          name = name,
          phone = phone,
          altPhone = altPhone,
          custAddress = cAddr,
          venueAddress = vAddr,
          eventDate = date,
          eventType = type,
          items = items,
          totalAmount = total,
          advancePaid = adv,
          payMode = mode,
          autoWhatsApp = autoWa,
          context = context
        )
      }
    )
  }

  if (showNewItemModal) {
    NewItemDialog(
      onDismiss = { viewModel.closeNewItemModal() },
      onSave = { name, stock, unit, rate, category, purchaseCost, minAlert, batch, serial, discount, sku, marketPrice, suppName, suppMobile, pDate, desc ->
        viewModel.addNewInventoryItem(
          name = name,
          stock = stock,
          unit = unit,
          rate = rate,
          category = category,
          purchaseCost = purchaseCost,
          minAlertStock = minAlert,
          batchNumber = batch,
          serialNumber = serial,
          defaultDiscountPercent = discount,
          sku = sku,
          currentMarketPrice = marketPrice,
          supplierName = suppName,
          supplierMobile = suppMobile,
          purchaseDate = pDate,
          description = desc
        )
      }
    )
  }

  if (showInvoicePreviewModal && selectedBookingForInvoice != null) {
    InvoicePreviewDialog(
      booking = selectedBookingForInvoice!!,
      profile = profile,
      onDismiss = { viewModel.closeInvoicePreview() },
      onShareWhatsApp = {
        viewModel.shareInvoiceViaWhatsApp(context, selectedBookingForInvoice!!)
      },
      onDownloadPdf = {
        viewModel.openOrDownloadInvoicePdf(context, selectedBookingForInvoice!!)
      },
      onSharePdf = {
        viewModel.shareInvoicePdf(context, selectedBookingForInvoice!!)
      }
    )
  }

  if (showDailyLimitDialog) {
    DailyLimitDialog(
      currentLimit = profile.dailyBookingLimit,
      onDismiss = { viewModel.closeDailyLimitDialog() },
      onSave = { newLim ->
        viewModel.saveDailyLimit(newLim)
      }
    )
  }

  if (showAdminPinDialog) {
    AdminPinDialog(
      onDismiss = { viewModel.closeAdminPinDialog() },
      onVerify = { pin ->
        if (viewModel.verifyAdminPin(pin)) {
          viewModel.setActiveTab(AppTab.ADMIN)
        }
      }
    )
  }

  if (showAddExpenseDialog) {
    AddExpenseDialog(
      onDismiss = { viewModel.closeAddExpenseDialog() },
      onSave = { title, cat, amt, dt, mode, rem ->
        viewModel.createExpense(title, cat, amt, dt, mode, rem)
      }
    )
  }

  if (showAddPurchaseDialog) {
    AddPurchaseDialog(
      onDismiss = { viewModel.closeAddPurchaseDialog() },
      onSave = { vName, itmName, qty, unit, rt, paid, mode ->
        viewModel.createPurchase(vName, itmName, qty, unit, rt, paid, mode)
      }
    )
  }

  if (showRecordPaymentDialog) {
    RecordPaymentDialog(
      onDismiss = { viewModel.closeRecordPaymentDialog() },
      onSave = { customer, phone, amount, type, mode, note ->
        viewModel.recordPayment(customer, phone, amount, type, mode, note)
      }
    )
  }

  if (showAddOrderDialog) {
    AddOrderDialog(
      onDismiss = { viewModel.closeAddOrderDialog() },
      onSave = { party, phone, type, total, adv ->
        viewModel.createOrder(party, phone, type, total, adv)
      }
    )
  }

  if (showPartyDetailDialog && selectedPartyForDetail != null) {
    val party = selectedPartyForDetail!!
    val partyBookings = bookings.filter { it.customerName.equals(party.name, ignoreCase = true) }
    PartyLedgerDialog(
      party = party,
      partyBookings = partyBookings,
      profile = profile,
      onDismiss = { viewModel.closePartyDetail() },
      onCall = { viewModel.callPhone(context, party.phone) },
      onWhatsApp = { viewModel.sharePartyStatementWhatsApp(context, party, partyBookings) },
      onRecordPayment = {
        viewModel.closePartyDetail()
        viewModel.openRecordPaymentDialog()
      },
      onShareStatement = { viewModel.sharePartyStatementWhatsApp(context, party, partyBookings) },
      onBookingClick = { b ->
        viewModel.openInvoicePreview(b)
      }
    )
  }

  if (showItemDetailDialog && selectedItemForDetail != null) {
    val item = selectedItemForDetail!!
    val linked = bookings.filter { b -> b.itemsJson.contains(item.name) }
    ItemDetailDialog(
      item = item,
      linkedBookings = linked,
      onDismiss = { viewModel.closeItemDetail() },
      onUpdateStock = { newStock -> viewModel.updateStock(item.id, newStock) },
      onSaveItem = { updatedItem -> viewModel.updateInventoryItemFull(updatedItem) }
    )
  }

  if (showPurchaseDetailDialog && selectedPurchaseForDetail != null) {
    val pur = selectedPurchaseForDetail!!
    PurchaseDetailDialog(
      purchase = pur,
      onDismiss = { viewModel.closePurchaseDetail() },
      onMarkPaid = { viewModel.markPurchaseAsPaid(pur.id) },
      onShareWhatsApp = { viewModel.sharePurchaseBillWhatsApp(context, pur) }
    )
  }

  if (showExpenseDetailDialog && selectedExpenseForDetail != null) {
    val exp = selectedExpenseForDetail!!
    ExpenseDetailDialog(
      expense = exp,
      onDismiss = { viewModel.closeExpenseDetail() },
      onDelete = { viewModel.removeExpense(exp.id) }
    )
  }

  if (showPaymentReceiptDialog && selectedPaymentForDetail != null) {
    val pay = selectedPaymentForDetail!!
    PaymentReceiptDialog(
      payment = pay,
      profile = profile,
      onDismiss = { viewModel.closePaymentReceipt() },
      onShareWhatsApp = { viewModel.sharePaymentReceiptWhatsApp(context, pay) }
    )
  }

  if (showOrderDetailDialog && selectedOrderForDetail != null) {
    val ord = selectedOrderForDetail!!
    OrderDetailDialog(
      order = ord,
      onDismiss = { viewModel.closeOrderDetail() },
      onStatusChange = { newStatus -> viewModel.changeOrderStatus(ord.id, newStatus) },
      onShareWhatsApp = { viewModel.shareOrderDetailWhatsApp(context, ord) }
    )
  }

  // ERP Modals
  if (showFinancialFigureModal && selectedFinancialFigureType != null) {
    FinancialFigureSourceModal(
      figureType = selectedFinancialFigureType!!,
      bookings = bookings,
      purchases = purchases,
      expenses = expenses,
      items = inventoryItems,
      payments = payments,
      onDismiss = { viewModel.closeFinancialSourceModal() },
      onBookingClick = { viewModel.openInvoicePreview(it) },
      onPurchaseClick = { viewModel.openPurchaseDetail(it) },
      onExpenseClick = { viewModel.openExpenseDetail(it) },
      onItemClick = { viewModel.openItemDetail(it) }
    )
  }

  if (showAddEmployeeDialog) {
    AddEmployeeDialog(
      onDismiss = { viewModel.closeAddEmployeeDialog() },
      onSave = { name, mobile, addr, jDate, cat, wage ->
        viewModel.createEmployee(name, mobile, addr, jDate, cat, wage)
      }
    )
  }

  if (showRecordAttendanceDialog) {
    RecordAttendanceDialog(
      employees = employees,
      bookings = bookings,
      onDismiss = { viewModel.closeRecordAttendanceDialog() },
      onSave = { empId, empName, dt, fDt, st, rate, evRef, nts ->
        viewModel.markAttendance(empId, empName, dt, fDt, st, rate, evRef, nts)
      }
    )
  }

  if (showRecordEmployeePaymentDialog) {
    RecordEmployeePaymentDialog(
      employees = employees,
      bookings = bookings,
      onDismiss = { viewModel.closeRecordEmployeePaymentDialog() },
      onSave = { empId, empName, dt, fDt, amt, mode, ev, ref, pType, nts ->
        viewModel.recordEmployeeSalaryPayment(empId, empName, dt, fDt, amt, mode, ev, ref, pType, nts)
      }
    )
  }

  if (showEmployeeDetailDialog && selectedEmployeeForDetail != null) {
    val emp = selectedEmployeeForDetail!!
    EmployeeDetailDialog(
      employee = emp,
      attendanceList = attendance,
      paymentList = employeePayments,
      onDismiss = { viewModel.closeEmployeeDetail() },
      onRecordPaymentClick = {
        viewModel.closeEmployeeDetail()
        viewModel.openRecordEmployeePaymentDialog()
      },
      onCall = { viewModel.callPhone(context, emp.mobile) },
      onDeleteEmployee = {
        viewModel.deleteEmployee(emp.id)
        viewModel.closeEmployeeDetail()
      }
    )
  }

  if (showPriceHistoryModal && selectedItemForPriceHistory != null) {
    val itm = selectedItemForPriceHistory!!
    ItemPriceComparisonModal(
      item = itm,
      priceHistoryList = priceHistory,
      onDismiss = { viewModel.closePriceHistoryModal() }
    )
  }
}
