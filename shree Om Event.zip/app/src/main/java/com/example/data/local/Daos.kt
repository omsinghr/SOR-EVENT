package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BookingEntity
import com.example.data.model.BusinessProfileEntity
import com.example.data.model.CustomerPaymentEntity
import com.example.data.model.EmployeeAttendanceEntity
import com.example.data.model.EmployeeEntity
import com.example.data.model.EmployeePaymentEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.InventoryItemEntity
import com.example.data.model.ItemPriceHistoryEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.OrderEntity
import com.example.data.model.PurchaseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BookingDao {
  @Query("SELECT * FROM bookings ORDER BY id DESC")
  fun getAllBookings(): Flow<List<BookingEntity>>

  @Query("SELECT * FROM bookings WHERE id = :id LIMIT 1")
  fun getBookingById(id: Long): Flow<BookingEntity?>

  @Query("SELECT * FROM bookings WHERE eventDate = :date AND status != 'CANCELLED'")
  fun getBookingsByDate(date: String): Flow<List<BookingEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBooking(booking: BookingEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(bookings: List<BookingEntity>)

  @Update
  suspend fun updateBooking(booking: BookingEntity)

  @Query("UPDATE bookings SET isStockDeducted = :isDeducted WHERE id = :id")
  suspend fun updateStockDeducted(id: Long, isDeducted: Boolean)

  @Query("DELETE FROM bookings WHERE id = :id")
  suspend fun deleteBooking(id: Long)

  @Query("DELETE FROM bookings")
  suspend fun deleteAll()
}

@Dao
interface InventoryDao {
  @Query("SELECT * FROM inventory_items ORDER BY name ASC")
  fun getAllItems(): Flow<List<InventoryItemEntity>>

  @Query("SELECT * FROM inventory_items WHERE id = :id LIMIT 1")
  suspend fun getItemById(id: String): InventoryItemEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertItem(item: InventoryItemEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(items: List<InventoryItemEntity>)

  @Query("UPDATE inventory_items SET stock = :newStock WHERE id = :id")
  suspend fun updateStock(id: String, newStock: Double)

  @Update
  suspend fun updateItem(item: InventoryItemEntity)

  @Query("DELETE FROM inventory_items WHERE id = :id")
  suspend fun deleteItem(id: String)

  @Query("DELETE FROM inventory_items")
  suspend fun deleteAll()
}

@Dao
interface ItemPriceHistoryDao {
  @Query("SELECT * FROM item_price_history ORDER BY id DESC")
  fun getAllPriceHistory(): Flow<List<ItemPriceHistoryEntity>>

  @Query("SELECT * FROM item_price_history WHERE itemId = :itemId ORDER BY id DESC")
  fun getPriceHistoryForItem(itemId: String): Flow<List<ItemPriceHistoryEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPriceHistory(hist: ItemPriceHistoryEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(historyList: List<ItemPriceHistoryEntity>)
}

@Dao
interface PurchaseDao {
  @Query("SELECT * FROM purchases ORDER BY id DESC")
  fun getAllPurchases(): Flow<List<PurchaseEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPurchase(purchase: PurchaseEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(purchases: List<PurchaseEntity>)

  @Query("UPDATE purchases SET paidAmount = totalAmount, dueAmount = 0.0 WHERE id = :id")
  suspend fun markAsPaid(id: Long)

  @Query("DELETE FROM purchases WHERE id = :id")
  suspend fun deletePurchase(id: Long)
}

@Dao
interface ExpenseDao {
  @Query("SELECT * FROM expenses ORDER BY id DESC")
  fun getAllExpenses(): Flow<List<ExpenseEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertExpense(expense: ExpenseEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(expenses: List<ExpenseEntity>)

  @Query("DELETE FROM expenses WHERE id = :id")
  suspend fun deleteExpense(id: Long)
}

@Dao
interface CustomerPaymentDao {
  @Query("SELECT * FROM customer_payments ORDER BY id DESC")
  fun getAllPayments(): Flow<List<CustomerPaymentEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPayment(payment: CustomerPaymentEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(payments: List<CustomerPaymentEntity>)
}

@Dao
interface OrderDao {
  @Query("SELECT * FROM orders ORDER BY id DESC")
  fun getAllOrders(): Flow<List<OrderEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrder(order: OrderEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(orders: List<OrderEntity>)

  @Query("UPDATE orders SET status = :status WHERE id = :id")
  suspend fun updateOrderStatus(id: Long, status: String)
}

@Dao
interface EmployeeDao {
  @Query("SELECT * FROM employees ORDER BY id ASC")
  fun getAllEmployees(): Flow<List<EmployeeEntity>>

  @Query("SELECT * FROM employees WHERE id = :id LIMIT 1")
  suspend fun getEmployeeById(id: Long): EmployeeEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertEmployee(employee: EmployeeEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(employees: List<EmployeeEntity>)

  @Update
  suspend fun updateEmployee(employee: EmployeeEntity)

  @Query("DELETE FROM employees WHERE id = :id")
  suspend fun deleteEmployee(id: Long)
}

@Dao
interface EmployeeAttendanceDao {
  @Query("SELECT * FROM employee_attendance ORDER BY date DESC, id DESC")
  fun getAllAttendance(): Flow<List<EmployeeAttendanceEntity>>

  @Query("SELECT * FROM employee_attendance WHERE employeeId = :empId ORDER BY date DESC")
  fun getAttendanceForEmployee(empId: String): Flow<List<EmployeeAttendanceEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAttendance(attendance: EmployeeAttendanceEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(attendanceList: List<EmployeeAttendanceEntity>)

  @Query("DELETE FROM employee_attendance WHERE id = :id")
  suspend fun deleteAttendance(id: Long)
}

@Dao
interface EmployeePaymentDao {
  @Query("SELECT * FROM employee_payments ORDER BY paymentDate DESC, id DESC")
  fun getAllPayments(): Flow<List<EmployeePaymentEntity>>

  @Query("SELECT * FROM employee_payments WHERE employeeId = :empId ORDER BY paymentDate DESC")
  fun getPaymentsForEmployee(empId: String): Flow<List<EmployeePaymentEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPayment(payment: EmployeePaymentEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(paymentList: List<EmployeePaymentEntity>)

  @Query("DELETE FROM employee_payments WHERE id = :id")
  suspend fun deletePayment(id: Long)
}

@Dao
interface BusinessProfileDao {
  @Query("SELECT * FROM business_profile WHERE id = 1 LIMIT 1")
  fun getProfile(): Flow<BusinessProfileEntity?>

  @Query("SELECT * FROM business_profile WHERE id = 1 LIMIT 1")
  suspend fun getProfileSync(): BusinessProfileEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdate(profile: BusinessProfileEntity)
}

@Dao
interface NotificationDao {
  @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
  fun getAllNotifications(): Flow<List<NotificationEntity>>

  @Query("SELECT COUNT(*) FROM notifications WHERE isRead = 0")
  fun getUnreadCount(): Flow<Int>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNotification(notification: NotificationEntity): Long

  @Query("UPDATE notifications SET isRead = 1 WHERE isRead = 0")
  suspend fun markAllAsRead()

  @Query("DELETE FROM notifications")
  suspend fun clearAll()
}
