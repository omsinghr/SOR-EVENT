package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.BookingEntity
import com.example.data.model.BookingItem
import com.example.data.model.BusinessProfileEntity
import com.example.data.model.InventoryItemEntity
import com.example.data.model.JsonHelper
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import com.example.data.model.CustomerPaymentEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.OrderEntity
import com.example.data.model.PurchaseEntity
import com.example.ui.PartySummary
import com.example.ui.theme.SoePrimary
import com.example.ui.theme.SoePrimaryDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VyaparAmber
import com.example.ui.theme.VyaparBlue
import com.example.ui.theme.VyaparGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewBookingDialog(
  availableInventory: List<InventoryItemEntity>,
  dailyBookingLimit: Int,
  existingBookingsOnDate: Int,
  onDismiss: () -> Unit,
  onSubmit: (
    salutation: String,
    name: String,
    phone: String,
    altPhone: String,
    custAddress: String,
    venueAddress: String,
    eventDate: String,
    eventType: String,
    items: List<BookingItem>,
    totalAmount: Double,
    advancePaid: Double,
    payMode: String,
    autoWhatsApp: Boolean
  ) -> Unit
) {
  var eventDate by remember { mutableStateOf("2026-07-17") }
  var salutation by remember { mutableStateOf("Mr.") }
  var custName by remember { mutableStateOf("") }
  var custPhone by remember { mutableStateOf("") }
  var custAltPhone by remember { mutableStateOf("") }
  var custAddress by remember { mutableStateOf("") }
  var eventVenue by remember { mutableStateOf("") }

  val eventTypes = listOf(
    "शादी (Wedding & Reception)",
    "हल्दी / संगीत (Haldi/Sangeet)",
    "बर्थडे पार्टी (Birthday)",
    "वरमाला एंट्री (Bride/Groom Entry)",
    "स्टेज व पंडाल डेकोर",
    "अन्य (Corporate/Private)"
  )
  var eventType by remember { mutableStateOf(eventTypes[0]) }
  var eventTypeExpanded by remember { mutableStateOf(false) }

  // Items picking
  val selectedItems = remember { mutableStateListOf<BookingItem>() }
  var selectedInventoryItem by remember { mutableStateOf(availableInventory.firstOrNull()) }
  var itemPickerExpanded by remember { mutableStateOf(false) }
  var itemQty by remember { mutableStateOf("1") }
  var itemRate by remember { mutableStateOf(selectedInventoryItem?.rate?.toString() ?: "600") }

  // Payments
  var advancePaidStr by remember { mutableStateOf("0") }
  var payMode by remember { mutableStateOf("UPI") }
  var autoSendWhatsApp by remember { mutableStateOf(true) }

  val calculatedTotal = selectedItems.sumOf { it.total }
  val advancePaid = advancePaidStr.toDoubleOrNull() ?: 0.0
  val balanceDue = (calculatedTotal - advancePaid).coerceAtLeast(0.0)

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight(0.92f)
        .padding(horizontal = 8.dp, vertical = 12.dp)
        .clip(RoundedCornerShape(24.dp)),
      color = Color.White
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        // Modal Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF8FAFC))
            .padding(horizontal = 14.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
              Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Close")
            }
            Text(
              text = "नई बुकिंग दर्ज करें (New Sale)",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          }
          Box(
            modifier = Modifier
              .background(Color(0xFFFFE4E6), RoundedCornerShape(12.dp))
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = "NEW INVOICE",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = SoePrimary
            )
          }
        }

        // Form Scrollable Area
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .padding(horizontal = 14.dp, vertical = 10.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // STEP 1: Date & Capacity
          item {
            Surface(
              shape = RoundedCornerShape(16.dp),
              color = Color(0xFFF0F9FF),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBAE6FD)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.CalendarToday,
                      contentDescription = null,
                      tint = VyaparBlue,
                      modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "इवेंट की तारीख (Event Date) *",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary
                    )
                  }

                  val isCapacityFull = existingBookingsOnDate >= dailyBookingLimit
                  Box(
                    modifier = Modifier
                      .background(
                        if (isCapacityFull) Color(0xFFFFE4E6) else Color(0xFFDCFCE7),
                        RoundedCornerShape(12.dp)
                      )
                      .padding(horizontal = 8.dp, vertical = 2.dp)
                  ) {
                    Text(
                      text = if (isCapacityFull) "हाउसफुल (लिमिट पूरी)" else "स्लॉट उपलब्ध",
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (isCapacityFull) SoePrimary else VyaparGreen
                    )
                  }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                  value = eventDate,
                  onValueChange = { eventDate = it },
                  placeholder = { Text("YYYY-MM-DD") },
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("booking_event_date_input"),
                  singleLine = true,
                  colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                  )
                )

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = "इस तारीख पर पहले से $existingBookingsOnDate बुकिंग है (अधिकतम लिमिट: $dailyBookingLimit).",
                  fontSize = 11.sp,
                  color = TextSecondary
                )
              }
            }
          }

          // STEP 2: Customer Details
          item {
            Surface(
              shape = RoundedCornerShape(16.dp),
              color = Color.White,
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(
                  text = "ग्राहक विवरण (CUSTOMER DETAILS)",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = VyaparBlue
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Salutation Radio
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                  listOf("Mr.", "Mrs.", "Shri", "Smt.").forEach { sal ->
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      modifier = Modifier.clickable { salutation = sal }
                    ) {
                      RadioButton(
                        selected = salutation == sal,
                        onClick = { salutation = sal }
                      )
                      Text(text = sal, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                  }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Customer Name
                OutlinedTextField(
                  value = custName,
                  onValueChange = { custName = it },
                  label = { Text("ग्राहक का पूरा नाम *") },
                  placeholder = { Text("उदा. Ramesh Kumar") },
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("booking_cust_name_input"),
                  singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Phones
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  OutlinedTextField(
                    value = custPhone,
                    onValueChange = { custPhone = it },
                    label = { Text("WhatsApp नं. *") },
                    placeholder = { Text("98XXXXXXXX") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                      .weight(1f)
                      .testTag("booking_cust_phone_input"),
                    singleLine = true
                  )
                  OutlinedTextField(
                    value = custAltPhone,
                    onValueChange = { custAltPhone = it },
                    label = { Text("2nd मोबाइल") },
                    placeholder = { Text("वैकल्पिक") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                  )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Customer Address
                OutlinedTextField(
                  value = custAddress,
                  onValueChange = { custAddress = it },
                  label = { Text("ग्राहक का पता (Billing Address)") },
                  placeholder = { Text("वार्ड नं. 4, स्टेशन रोड, उमरिया") },
                  modifier = Modifier.fillMaxWidth(),
                  singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Event Venue Address
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = "इवेंट वेन्यू का पता (Event Location) *",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                  )
                  Text(
                    text = "ग्राहक का पता ही वेन्यू है",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = VyaparBlue,
                    modifier = Modifier.clickable { eventVenue = custAddress }
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                  value = eventVenue,
                  onValueChange = { eventVenue = it },
                  placeholder = { Text("रॉयल पैलेस गार्डन, मुख्य मार्ग, उमरिया") },
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("booking_venue_input"),
                  singleLine = true
                )
              }
            }
          }

          // STEP 3: Event Type & Items Selection
          item {
            Surface(
              shape = RoundedCornerShape(16.dp),
              color = Color.White,
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(
                  text = "इवेंट आइटम्स जोड़ें (STOCK SYNC)",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF4338CA)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Event Type Dropdown
                ExposedDropdownMenuBox(
                  expanded = eventTypeExpanded,
                  onExpandedChange = { eventTypeExpanded = it }
                ) {
                  OutlinedTextField(
                    value = eventType,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("इवेंट का प्रकार") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = eventTypeExpanded) },
                    modifier = Modifier
                      .menuAnchor()
                      .fillMaxWidth()
                  )
                  ExposedDropdownMenu(
                    expanded = eventTypeExpanded,
                    onDismissRequest = { eventTypeExpanded = false }
                  ) {
                    eventTypes.forEach { type ->
                      DropdownMenuItem(
                        text = { Text(type) },
                        onClick = {
                          eventType = type
                          eventTypeExpanded = false
                        }
                      )
                    }
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Item Picker Row
                Surface(
                  shape = RoundedCornerShape(12.dp),
                  color = Color(0xFFF8FAFC),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(modifier = Modifier.padding(10.dp)) {
                    // Item Dropdown
                    ExposedDropdownMenuBox(
                      expanded = itemPickerExpanded,
                      onExpandedChange = { itemPickerExpanded = it }
                    ) {
                      OutlinedTextField(
                        value = selectedInventoryItem?.name ?: "आइटम चुनें",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("आइटम चुनें") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = itemPickerExpanded) },
                        modifier = Modifier
                          .menuAnchor()
                          .fillMaxWidth()
                      )
                      ExposedDropdownMenu(
                        expanded = itemPickerExpanded,
                        onDismissRequest = { itemPickerExpanded = false }
                      ) {
                        availableInventory.forEach { item ->
                          DropdownMenuItem(
                            text = { Text("${item.name} (${item.unit} - स्टॉक: ${item.stock})") },
                            onClick = {
                              selectedInventoryItem = item
                              itemRate = item.rate.toString()
                              itemPickerExpanded = false
                            }
                          )
                        }
                      }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                      OutlinedTextField(
                        value = itemQty,
                        onValueChange = { itemQty = it },
                        label = { Text("मात्रा") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                      )

                      OutlinedTextField(
                        value = itemRate,
                        onValueChange = { itemRate = it },
                        label = { Text("रेट (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                      )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(
                        text = "उपलब्ध स्टॉक: ${selectedInventoryItem?.stock ?: 0.0} ${selectedInventoryItem?.unit ?: ""}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF4338CA)
                      )

                      Button(
                        onClick = {
                          val item = selectedInventoryItem ?: return@Button
                          val qty = itemQty.toDoubleOrNull() ?: 1.0
                          val rate = itemRate.toDoubleOrNull() ?: item.rate
                          selectedItems.add(
                            BookingItem(
                              id = item.id,
                              name = item.name,
                              qty = qty,
                              unit = item.unit,
                              rate = rate,
                              total = qty * rate
                            )
                          )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4338CA)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("add_item_to_list_button")
                      ) {
                        Text("+ लिस्ट में जोड़ें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      }
                    }
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Table of Selected Items
                if (selectedItems.isEmpty()) {
                  Text(
                    text = "कोई आइटम नहीं चुना गया (पैकेज बुकिंग)",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(vertical = 6.dp)
                  )
                } else {
                  Column(
                    modifier = Modifier
                      .fillMaxWidth()
                      .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                  ) {
                    selectedItems.forEachIndexed { idx, itm ->
                      Row(
                        modifier = Modifier
                          .fillMaxWidth()
                          .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Column(modifier = Modifier.weight(1f)) {
                          Text(text = itm.name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                          Text(
                            text = "${itm.qty} ${itm.unit} × ₹${itm.rate}",
                            fontSize = 10.sp,
                            color = TextSecondary
                          )
                        }
                        Text(
                          text = "₹${itm.total}",
                          fontSize = 11.sp,
                          fontWeight = FontWeight.Bold,
                          color = TextPrimary
                        )
                        IconButton(
                          onClick = { selectedItems.removeAt(idx) },
                          modifier = Modifier.size(24.dp)
                        ) {
                          Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Remove",
                            tint = SoePrimary,
                            modifier = Modifier.size(16.dp)
                          )
                        }
                      }
                    }
                  }
                }
              }
            }
          }

          // STEP 4: Payment Details
          item {
            Surface(
              shape = RoundedCornerShape(16.dp),
              color = Color.White,
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(
                  text = "बिल व भुगतान (PAYMENT DETAILS)",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = SoePrimary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(text = "कुल राशि (Total)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                      modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 12.dp)
                    ) {
                      Text(
                        text = "₹ ${String.format("%,.2f", calculatedTotal)}",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                      )
                    }
                  }

                  Column(modifier = Modifier.weight(1f)) {
                    Text(text = "जमा एडवांस", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                      value = advancePaidStr,
                      onValueChange = { advancePaidStr = it },
                      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                      modifier = Modifier
                        .fillMaxWidth()
                        .testTag("booking_advance_paid_input"),
                      singleLine = true
                    )
                  }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Balance Due Banner
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFFFFE4E6),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECDD3)),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = "शेष बकाया (Balance Due):",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = SoePrimaryDark
                    )
                    Text(
                      text = "₹ ${String.format("%,.2f", balanceDue)}",
                      fontSize = 14.sp,
                      fontWeight = FontWeight.Black,
                      color = SoePrimary
                    )
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Payment Mode Radio
                Text(text = "भुगतान का माध्यम (Payment Mode)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  listOf("CASH", "UPI", "BANK").forEach { mode ->
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      modifier = Modifier.clickable { payMode = mode }
                    ) {
                      RadioButton(selected = payMode == mode, onClick = { payMode = mode })
                      Text(text = mode, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Auto WhatsApp Checkbox
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFFF0FDF4),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier
                      .padding(8.dp)
                      .clickable { autoSendWhatsApp = !autoSendWhatsApp },
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Checkbox(
                      checked = autoSendWhatsApp,
                      onCheckedChange = { autoSendWhatsApp = it }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "बुकिंग कन्फर्म होते ही WhatsApp बिल भेजें",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFF14532D)
                    )
                  }
                }
              }
            }
          }
        }

        // Submit Button
        Button(
          onClick = {
            if (custName.isBlank() || custPhone.isBlank() || eventVenue.isBlank()) {
              return@Button
            }
            onSubmit(
              salutation,
              custName.trim(),
              custPhone.trim(),
              custAltPhone.trim(),
              custAddress.trim(),
              eventVenue.trim(),
              eventDate.trim(),
              eventType,
              selectedItems.toList(),
              calculatedTotal,
              advancePaid,
              payMode,
              autoSendWhatsApp
            )
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE50938)),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp)
            .testTag("submit_booking_button")
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(vertical = 4.dp)
          ) {
            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White)
            Text(
              text = "✓ बुकिंग कन्फर्म करें और सेव करें",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
          }
        }
      }
    }
  }
}

@Composable
fun NewItemDialog(
  onDismiss: () -> Unit,
  onSave: (
    name: String,
    stock: Double,
    unit: String,
    rate: Double,
    category: String,
    purchaseCost: Double,
    minAlertStock: Double,
    batchNumber: String,
    serialNumber: String,
    defaultDiscountPercent: Double,
    sku: String,
    currentMarketPrice: Double,
    supplierName: String,
    supplierMobile: String,
    purchaseDate: String,
    description: String
  ) -> Unit
) {
  var name by remember { mutableStateOf("") }
  var stockStr by remember { mutableStateOf("10") }
  var unit by remember { mutableStateOf("Pieces") }
  var rateStr by remember { mutableStateOf("500") }
  var purchaseCostStr by remember { mutableStateOf("300") }
  var marketPriceStr by remember { mutableStateOf("550") }
  var minAlertStr by remember { mutableStateOf("3") }
  var sku by remember { mutableStateOf("") }
  var supplierName by remember { mutableStateOf("ग्वालियर आतिशबाजी सप्लायर्स") }
  var supplierMobile by remember { mutableStateOf("9425112233") }
  var purchaseDate by remember { mutableStateOf("2026-11-10") }
  var category by remember { mutableStateOf("Pyro & FX") }
  var batchNumber by remember { mutableStateOf("B-2026-01") }
  var serialNumber by remember { mutableStateOf("SN-SOE-001") }
  var description by remember { mutableStateOf("") }

  val categories = listOf("Pyro & FX", "Special Effects", "Consumables", "Stage & Truss", "Stage Hardware", "General")

  Dialog(
    onDismissRequest = onDismiss,
    properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .padding(10.dp),
      shadowElevation = 8.dp
    ) {
      Column(
        modifier = Modifier
          .padding(16.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "✨ नया ERP आइटम जोड़ें (Add Inventory Item)",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("आइटम का नाम *") },
          placeholder = { Text("उदा. Cold Pyro Gun, Dry Ice Machine") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("new_item_name_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = sku,
            onValueChange = { sku = it },
            label = { Text("SKU / बारकोड कोड") },
            placeholder = { Text("SKU-CPG-01") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("श्रेणी (Category)") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = stockStr,
            onValueChange = { stockStr = it },
            label = { Text("उपलब्ध स्टॉक मात्रा *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = unit,
            onValueChange = { unit = it },
            label = { Text("यूनिट") },
            placeholder = { Text("Pieces / Kg / Set") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = purchaseCostStr,
            onValueChange = { purchaseCostStr = it },
            label = { Text("खरीद लागत (₹) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = rateStr,
            onValueChange = { rateStr = it },
            label = { Text("बिक्री/किराया रेट (₹) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = marketPriceStr,
            onValueChange = { marketPriceStr = it },
            label = { Text("बाजार मूल्य (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = minAlertStr,
            onValueChange = { minAlertStr = it },
            label = { Text("कम स्टॉक अलर्ट सीमा") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = supplierName,
            onValueChange = { supplierName = it },
            label = { Text("सप्लायर / वेंडर नाम") },
            modifier = Modifier.weight(1.2f),
            singleLine = true
          )

          OutlinedTextField(
            value = supplierMobile,
            onValueChange = { supplierMobile = it },
            label = { Text("मोबाइल") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.weight(0.8f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("आइटम विवरण व विनिर्देश") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("रद्द करें")
          }

          Button(
            onClick = {
              if (name.isNotBlank()) {
                val stock = stockStr.toDoubleOrNull() ?: 0.0
                val rate = rateStr.toDoubleOrNull() ?: 500.0
                val pCost = purchaseCostStr.toDoubleOrNull() ?: 0.0
                val mPrice = marketPriceStr.toDoubleOrNull() ?: rate
                val minAlert = minAlertStr.toDoubleOrNull() ?: 3.0
                onSave(
                  name.trim(),
                  stock,
                  unit.trim(),
                  rate,
                  category.trim(),
                  pCost,
                  minAlert,
                  batchNumber,
                  serialNumber,
                  0.0,
                  sku.trim(),
                  mPrice,
                  supplierName.trim(),
                  supplierMobile.trim(),
                  purchaseDate,
                  description.trim()
                )
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4338CA)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("save_new_item_button")
          ) {
            Text("सुरक्षित करें", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun InvoicePreviewDialog(
  booking: BookingEntity,
  profile: BusinessProfileEntity,
  onDismiss: () -> Unit,
  onShareWhatsApp: () -> Unit,
  onDownloadPdf: () -> Unit = {},
  onSharePdf: () -> Unit = {}
) {
  val items = JsonHelper.deserializeBookingItems(booking.itemsJson)

  val plannerPhone = if (profile.phone1.isNotBlank()) profile.phone1 else "9584249750"
  val plannerEmail = if (profile.email.isNotBlank()) profile.email else "shriomeventumaria@gmail.com"
  val plannerAddress = if (profile.address.isNotBlank()) profile.address else "Near By Society Karkeli, Rampur, Umaria (M.P.)"

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .fillMaxHeight(0.92f)
        .padding(6.dp),
      shadowElevation = 12.dp
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Modal Header Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1E40AF))
            .padding(horizontal = 14.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(imageVector = Icons.Default.Receipt, contentDescription = null, tint = Color.White)
            Column {
              Text(
                text = "TAX INVOICE / BILL RECEIPT",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Text(
                text = "Bill #${booking.invoiceNumber}",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFFBFDBFE)
              )
            }
          }

          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
        }

        // Printable Bill Document Body
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // 1. Company Banner & Header
          item {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                .background(Color(0xFFF8FAFC))
                .padding(12.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              // Slim Banner Top Accent
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(4.dp)
                  .background(
                    Brush.horizontalGradient(listOf(Color(0xFF1E40AF), Color(0xFFF59E0B), Color(0xFFE11D48))),
                    RoundedCornerShape(2.dp)
                  )
              )
              Spacer(modifier = Modifier.height(8.dp))

              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .background(Color(0xFF1E40AF), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = "SOE",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp
                  )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Text(
                    text = "SHREE OM EVENT & DECORATION",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF0F172A),
                    letterSpacing = 0.2.sp
                  )
                  Text(
                    text = "Complete Event Management • Sound System • Stage Truss • Special FX",
                    fontSize = 10.sp,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Medium
                  )
                }
              }

              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "📍 $plannerAddress",
                fontSize = 10.sp,
                color = Color(0xFF475569)
              )
              Text(
                text = "📞 $plannerPhone | ✉️ $plannerEmail",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1E40AF)
              )
            }
          }

          // 2. Customer & Event Details Box
          item {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color.White,
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                // Left Column: Customer Info
                Column(modifier = Modifier.weight(1.1f)) {
                  Text(
                    text = "CUSTOMER DETAILS:",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                  )
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(
                    text = "${booking.salutation} ${booking.customerName}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF0F172A)
                  )
                  Text(
                    text = "📱 Mobile: ${booking.customerPhone}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF334155)
                  )
                  if (booking.customerAltPhone.isNotBlank()) {
                    Text(
                      text = "📞 Alt Phone: ${booking.customerAltPhone}",
                      fontSize = 10.sp,
                      color = Color(0xFF64748B)
                    )
                  }
                  Text(
                    text = "📍 Address: ${booking.customerAddress.ifBlank { booking.eventVenueAddress }}",
                    fontSize = 10.sp,
                    color = Color(0xFF475569)
                  )
                }

                // Right Column: Bill & Event Info
                Column(
                  modifier = Modifier.weight(0.9f),
                  horizontalAlignment = Alignment.End
                ) {
                  Text(
                    text = "BILL & EVENT DETAILS:",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                  )
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(
                    text = "Bill No: ${booking.invoiceNumber}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF1E40AF)
                  )
                  Text(
                    text = "Date: ${booking.formattedDate}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF334155)
                  )
                  Text(
                    text = "Event Date: ${booking.formattedDate}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFB45309)
                  )
                  Text(
                    text = "Event Package: ${booking.eventType}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF475569)
                  )
                }
              }
            }
          }

          // 3. Items Table
          item {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(10.dp))
                .clip(RoundedCornerShape(10.dp))
            ) {
              // Table Header Row
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(Color(0xFF1E293B))
                  .padding(horizontal = 8.dp, vertical = 7.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Item Description",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  modifier = Modifier.weight(1.8f)
                )
                Text(
                  text = "Qty / Unit",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  modifier = Modifier.weight(0.9f)
                )
                Text(
                  text = "Rate (₹)",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  modifier = Modifier.weight(0.8f)
                )
                Text(
                  text = "Disc",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  modifier = Modifier.weight(0.6f)
                )
                Text(
                  text = "Amount (₹)",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  modifier = Modifier.weight(0.9f)
                )
              }

              // Table Body Rows
              if (items.isEmpty()) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = "Complete Package: ${booking.eventType}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1.8f)
                  )
                  Text(text = "1 Package", fontSize = 10.sp, modifier = Modifier.weight(0.9f))
                  Text(text = "₹ ${String.format("%,.0f", booking.totalAmount)}", fontSize = 10.sp, modifier = Modifier.weight(0.8f))
                  Text(text = "0%", fontSize = 10.sp, color = Color(0xFF15803D), modifier = Modifier.weight(0.6f))
                  Text(
                    text = "₹ ${String.format("%,.0f", booking.totalAmount)}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(0.9f)
                  )
                }
              } else {
                items.forEachIndexed { idx, itm ->
                  val rowBg = if (idx % 2 == 0) Color.White else Color(0xFFF8FAFC)
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .background(rowBg)
                      .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = itm.name,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Medium,
                      color = Color(0xFF0F172A),
                      modifier = Modifier.weight(1.8f)
                    )
                    Text(
                      text = "${itm.qty} ${itm.unit}",
                      fontSize = 10.sp,
                      color = Color(0xFF475569),
                      modifier = Modifier.weight(0.9f)
                    )
                    Text(
                      text = "₹ ${String.format("%,.0f", itm.rate)}",
                      fontSize = 10.sp,
                      color = Color(0xFF334155),
                      modifier = Modifier.weight(0.8f)
                    )
                    Text(
                      text = "0%",
                      fontSize = 10.sp,
                      color = Color(0xFF15803D),
                      modifier = Modifier.weight(0.6f)
                    )
                    Text(
                      text = "₹ ${String.format("%,.0f", itm.total)}",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFF0F172A),
                      modifier = Modifier.weight(0.9f)
                    )
                  }
                  if (idx < items.size - 1) {
                    androidx.compose.material3.HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 0.5.dp)
                  }
                }
              }
            }
          }

          // 4. Totals and Financial Summary Card (NO PROFIT SHOWN!)
          item {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0xFFF8FAFC),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
              ) {
                // Gross Total
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "Total Booking Amount:",
                    fontSize = 11.sp,
                    color = Color(0xFF475569)
                  )
                  Text(
                    text = "₹ ${String.format("%,.2f", booking.totalAmount)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                  )
                }

                // Total Discount
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "Total Discount:",
                    fontSize = 11.sp,
                    color = Color(0xFF15803D)
                  )
                  Text(
                    text = "- ₹ 0.00",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF15803D)
                  )
                }

                // Net Payable Amount
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "Net Payable Amount:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                  )
                  Text(
                    text = "₹ ${String.format("%,.2f", booking.totalAmount)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF1E40AF)
                  )
                }

                androidx.compose.material3.HorizontalDivider(color = Color(0xFFCBD5E1), thickness = 1.dp)

                // Advance Amount Paid
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "Advance Payment Paid (${booking.paymentMode}):",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF166534)
                  )
                  Text(
                    text = "₹ ${String.format("%,.2f", booking.advancePaid)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF166534)
                  )
                }

                // Balance Due Amount
                val balColor = if (booking.balanceDue > 0) Color(0xFFDC2626) else Color(0xFF16A34A)
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "Balance Due Amount:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = balColor
                  )
                  Text(
                    text = "₹ ${String.format("%,.2f", booking.balanceDue)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = balColor
                  )
                }
              }
            }
          }

          // 5. Terms & Conditions Section
          item {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color(0xFFFFFBEB),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = "📜 TERMS & CONDITIONS:",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF92400E)
                )
                Spacer(modifier = Modifier.height(4.dp))
                val terms = listOf(
                  "1. 50% advance deposit is required to confirm booking dates and reserve equipment.",
                  "2. The client / organizer must provide uninterrupted 220V power supply and safe wiring at venue.",
                  "3. A minimum safety radius of 15 feet must be maintained around stage special effects and pyros.",
                  "4. The remaining balance amount must be settled immediately upon setup and delivery at event venue.",
                  "5. Cancellations within 48 hours prior to event start time will forfeit advance deposit."
                )
                terms.forEach { term ->
                  Text(
                    text = term,
                    fontSize = 9.sp,
                    lineHeight = 13.sp,
                    color = Color(0xFF78350F),
                    modifier = Modifier.padding(vertical = 1.dp)
                  )
                }
              }
            }
          }

          // 6. Signatures
          item {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp, bottom = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.Bottom
            ) {
              Column {
                Box(modifier = Modifier.width(130.dp).height(1.dp).background(Color(0xFFCBD5E1)))
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "Customer Acceptance / Signature",
                  fontSize = 9.sp,
                  color = Color(0xFF64748B)
                )
              }

              Column(horizontalAlignment = Alignment.End) {
                Text(
                  text = "Shree Om Event",
                  fontFamily = FontFamily.Cursive,
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF1E40AF)
                )
                Box(modifier = Modifier.width(160.dp).height(1.dp).background(Color(0xFFCBD5E1)))
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "For SHREE OM EVENT & DECORATION",
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF1E40AF)
                )
                Text(
                  text = "(Authorized Signatory)",
                  fontSize = 8.sp,
                  color = Color(0xFF64748B)
                )
              }
            }
          }
        }

        // Action Buttons Row (Download PDF, Share PDF, WhatsApp, Close)
        Surface(
          shadowElevation = 8.dp,
          color = Color.White,
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              // PDF Download Button
              Button(
                onClick = onDownloadPdf,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .weight(1f)
                  .testTag("invoice_download_pdf_button")
              ) {
                Text(text = "📄 Download PDF", fontWeight = FontWeight.Bold, fontSize = 11.sp)
              }

              // PDF Share Button
              Button(
                onClick = onSharePdf,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .weight(1f)
                  .testTag("invoice_share_pdf_button")
              ) {
                Text(text = "📤 Share PDF", fontWeight = FontWeight.Bold, fontSize = 11.sp)
              }

              // WhatsApp Text Share Button
              Button(
                onClick = onShareWhatsApp,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .weight(1f)
                  .testTag("invoice_share_whatsapp_button")
              ) {
                Text(text = "💬 WhatsApp", fontWeight = FontWeight.Bold, fontSize = 11.sp)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun DailyLimitDialog(
  currentLimit: Int,
  onDismiss: () -> Unit,
  onSave: (Int) -> Unit
) {
  var limitStr by remember { mutableStateOf(currentLimit.toString()) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "दैनिक बुकिंग लिमिट सेट करें",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Text(
          text = "तय सीमा से अधिक बुकिंग होने पर ऐप आपको अलर्ट देगा।",
          fontSize = 11.sp,
          color = TextSecondary,
          modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = limitStr,
          onValueChange = { limitStr = it },
          label = { Text("प्रति दिन अधिकतम बुकिंग्स") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("daily_limit_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("रद्द करें")
          }
          Button(
            onClick = {
              val lim = limitStr.toIntOrNull() ?: 3
              onSave(lim)
            },
            colors = ButtonDefaults.buttonColors(containerColor = SoePrimary),
            modifier = Modifier
              .weight(1f)
              .testTag("save_daily_limit_button")
          ) {
            Text("सेव करें", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun AdminPinDialog(
  onDismiss: () -> Unit,
  onVerify: (String) -> Unit
) {
  var pin by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .background(Color(0xFFFEF2F2), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = null,
            tint = SoePrimary,
            modifier = Modifier.size(24.dp)
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = "एडमिन सुरक्षा पिन",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Text(
          text = "वित्तीय रिपोर्ट व सिस्टम सेटिंग्स के लिए 4 अंकों का पिन दर्ज करें (Default: 1234)",
          fontSize = 11.sp,
          color = TextSecondary,
          lineHeight = 15.sp,
          modifier = Modifier.padding(vertical = 4.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = pin,
          onValueChange = { if (it.length <= 4) pin = it },
          placeholder = { Text("4-digit PIN") },
          visualTransformation = PasswordVisualTransformation(),
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_pin_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("रद्द करें")
          }
          Button(
            onClick = { onVerify(pin) },
            colors = ButtonDefaults.buttonColors(containerColor = SoePrimary),
            modifier = Modifier
              .weight(1f)
              .testTag("admin_pin_submit_button")
          ) {
            Text("अनलॉक करें", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun ThemePickerDialog(
  currentTheme: String,
  onDismiss: () -> Unit,
  onSelectTheme: (String) -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Select Visiting Card Style",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        val themes = listOf(
          Triple("classic-red", "Vyapar Crimson", Color(0xFFF5003B)),
          Triple("royal-blue", "Corporate Blue", Color(0xFF1D4ED8)),
          Triple("emerald-green", "Fresh Green", Color(0xFF15803D)),
          Triple("dark-gold", "Executive Gold", Color(0xFFF59E0B))
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          themes.forEach { (key, name, color) ->
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (currentTheme == key) color.copy(alpha = 0.1f) else Color(0xFFF8FAFC),
              border = androidx.compose.foundation.BorderStroke(
                if (currentTheme == key) 2.dp else 1.dp,
                if (currentTheme == key) color else Color(0xFFE2E8F0)
              ),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onSelectTheme(key) }
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Box(
                  modifier = Modifier
                    .size(24.dp)
                    .background(color, CircleShape)
                )
                Text(
                  text = name,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary,
                  modifier = Modifier.weight(1f)
                )
                if (currentTheme == key) {
                  Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = color,
                    modifier = Modifier.size(18.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseDialog(
  onDismiss: () -> Unit,
  onSave: (title: String, category: String, amount: Double, date: String, mode: String, remarks: String) -> Unit
) {
  var title by remember { mutableStateOf("") }
  val categories = listOf("जनरेटर / डीजल", "लेबर / कारीगर", "ट्रांसपोर्ट / वाहन", "नाश्ता / खाना", "साउंड व टेंट", "बिजली / वायरिंग", "अन्य विविध")
  var category by remember { mutableStateOf(categories[0]) }
  var categoryExpanded by remember { mutableStateOf(false) }
  var amountStr by remember { mutableStateOf("") }
  var dateStr by remember { mutableStateOf("2026-11-10") }
  var payMode by remember { mutableStateOf("CASH") }
  var remarks by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "नया खर्च जोड़ें (Add Expense)",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("खर्च का विवरण (Title) *") },
          placeholder = { Text("उदा. जनरेटर ऑपरेटर भुगतान, डीजल") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("expense_title_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Category dropdown
        ExposedDropdownMenuBox(
          expanded = categoryExpanded,
          onExpandedChange = { categoryExpanded = it }
        ) {
          OutlinedTextField(
            value = category,
            onValueChange = {},
            readOnly = true,
            label = { Text("खर्च की श्रेणी (Category)") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = categoryExpanded,
            onDismissRequest = { categoryExpanded = false }
          ) {
            categories.forEach { cat ->
              DropdownMenuItem(
                text = { Text(cat) },
                onClick = {
                  category = cat
                  categoryExpanded = false
                }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = amountStr,
            onValueChange = { amountStr = it },
            label = { Text("राशि (₹) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier
              .weight(1f)
              .testTag("expense_amount_input"),
            singleLine = true
          )

          OutlinedTextField(
            value = dateStr,
            onValueChange = { dateStr = it },
            label = { Text("तारीख") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(text = "भुगतान माध्यम (Payment Mode):", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("CASH", "UPI", "BANK").forEach { mode ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.clickable { payMode = mode }
            ) {
              RadioButton(selected = payMode == mode, onClick = { payMode = mode })
              Text(text = mode, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
          value = remarks,
          onValueChange = { remarks = it },
          label = { Text("रिमार्क / टिप्पणी (वैकल्पिक)") },
          placeholder = { Text("उदा. 20 लीटर डीजल रसीद सहित") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("रद्द करें")
          }

          Button(
            onClick = {
              val amt = amountStr.toDoubleOrNull() ?: 0.0
              if (title.isNotBlank() && amt > 0) {
                onSave(title.trim(), category, amt, dateStr.trim(), payMode, remarks.trim())
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = SoePrimary),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("save_expense_button")
          ) {
            Text("खर्च सुरक्षित करें", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun AddPurchaseDialog(
  onDismiss: () -> Unit,
  onSave: (vendor: String, item: String, qty: Double, unit: String, rate: Double, paid: Double, mode: String) -> Unit
) {
  var vendor by remember { mutableStateOf("") }
  var item by remember { mutableStateOf("") }
  var qtyStr by remember { mutableStateOf("1") }
  var unit by remember { mutableStateOf("Pieces") }
  var rateStr by remember { mutableStateOf("") }
  var paidStr by remember { mutableStateOf("") }
  var payMode by remember { mutableStateOf("UPI") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "नयी खरीदी दर्ज करें (Add Purchase)",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = vendor,
          onValueChange = { vendor = it },
          label = { Text("वेंडर / सप्लायर का नाम *") },
          placeholder = { Text("उदा. जबलपुर लाइट एंड डेकोर ट्रेडर्स") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("purchase_vendor_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = item,
          onValueChange = { item = it },
          label = { Text("सामान / उपकरण का नाम *") },
          placeholder = { Text("उदा. LED Par Lights, Fog Machine Liquid") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("purchase_item_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = qtyStr,
            onValueChange = { qtyStr = it },
            label = { Text("मात्रा (Qty) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = unit,
            onValueChange = { unit = it },
            label = { Text("यूनिट") },
            placeholder = { Text("Pieces/Kg/Set") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = rateStr,
            onValueChange = { rateStr = it },
            label = { Text("दर (₹ / Unit) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = paidStr,
            onValueChange = { paidStr = it },
            label = { Text("जमा भुगतान (Paid ₹)") },
            placeholder = { Text("0") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(text = "भुगतान माध्यम (Payment Mode):", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("UPI", "CASH", "BANK").forEach { mode ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.clickable { payMode = mode }
            ) {
              RadioButton(selected = payMode == mode, onClick = { payMode = mode })
              Text(text = mode, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("रद्द करें")
          }

          Button(
            onClick = {
              val qty = qtyStr.toDoubleOrNull() ?: 1.0
              val rate = rateStr.toDoubleOrNull() ?: 0.0
              val paid = paidStr.toDoubleOrNull() ?: (qty * rate)
              if (vendor.isNotBlank() && item.isNotBlank() && rate > 0) {
                onSave(vendor.trim(), item.trim(), qty, unit.trim(), rate, paid, payMode)
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("save_purchase_button")
          ) {
            Text("खरीदी सुरक्षित करें", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun RecordPaymentDialog(
  onDismiss: () -> Unit,
  onSave: (customer: String, phone: String, amount: Double, type: String, mode: String, note: String) -> Unit
) {
  var customer by remember { mutableStateOf("") }
  var phone by remember { mutableStateOf("") }
  var amountStr by remember { mutableStateOf("") }
  var paymentType by remember { mutableStateOf("PAYMENT_IN") } // PAYMENT_IN or PAYMENT_OUT
  var payMode by remember { mutableStateOf("UPI") }
  var note by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "भुगतान रिकॉर्ड करें (Payment Record)",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Type: Payment In vs Out
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (paymentType == "PAYMENT_IN") Color(0xFFDCFCE7) else Color(0xFFF1F5F9),
            border = androidx.compose.foundation.BorderStroke(
              if (paymentType == "PAYMENT_IN") 1.5.dp else 1.dp,
              if (paymentType == "PAYMENT_IN") VyaparGreen else Color(0xFFE2E8F0)
            ),
            modifier = Modifier
              .weight(1f)
              .clickable { paymentType = "PAYMENT_IN" }
          ) {
            Box(modifier = Modifier.padding(8.dp), contentAlignment = Alignment.Center) {
              Text(
                text = "✓ जमा (Payment-In)",
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = if (paymentType == "PAYMENT_IN") Color(0xFF14532D) else TextSecondary
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (paymentType == "PAYMENT_OUT") Color(0xFFFFE4E6) else Color(0xFFF1F5F9),
            border = androidx.compose.foundation.BorderStroke(
              if (paymentType == "PAYMENT_OUT") 1.5.dp else 1.dp,
              if (paymentType == "PAYMENT_OUT") SoePrimary else Color(0xFFE2E8F0)
            ),
            modifier = Modifier
              .weight(1f)
              .clickable { paymentType = "PAYMENT_OUT" }
          ) {
            Box(modifier = Modifier.padding(8.dp), contentAlignment = Alignment.Center) {
              Text(
                text = "↑ भुगतान वापसी (Payment-Out)",
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = if (paymentType == "PAYMENT_OUT") SoePrimary else TextSecondary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = customer,
          onValueChange = { customer = it },
          label = { Text("ग्राहक / पार्टी का नाम *") },
          placeholder = { Text("उदा. अनिल गुप्ता, उमरिया") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("payment_cust_name_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("मोबाइल नंबर") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = amountStr,
            onValueChange = { amountStr = it },
            label = { Text("राशि (₹) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier
              .weight(1f)
              .testTag("payment_amount_input"),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(text = "भुगतान का माध्यम (Mode):", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("UPI", "CASH", "BANK").forEach { mode ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.clickable { payMode = mode }
            ) {
              RadioButton(selected = payMode == mode, onClick = { payMode = mode })
              Text(text = mode, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
          value = note,
          onValueChange = { note = it },
          label = { Text("विवरण / इनवॉइस संदर्भ") },
          placeholder = { Text("उदा. हल्दी इवेंट का अंतिम भुगतान") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("रद्द करें")
          }

          Button(
            onClick = {
              val amt = amountStr.toDoubleOrNull() ?: 0.0
              if (customer.isNotBlank() && amt > 0) {
                onSave(customer.trim(), phone.trim(), amt, paymentType, payMode, note.trim())
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = VyaparGreen),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("save_payment_record_button")
          ) {
            Text("भुगतान दर्ज करें", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun AddOrderDialog(
  onDismiss: () -> Unit,
  onSave: (party: String, phone: String, type: String, total: Double, adv: Double) -> Unit
) {
  var party by remember { mutableStateOf("") }
  var phone by remember { mutableStateOf("") }
  var orderType by remember { mutableStateOf("SALE_ORDER") } // SALE_ORDER vs PURCHASE_ORDER
  var totalStr by remember { mutableStateOf("") }
  var advStr by remember { mutableStateOf("0") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "नया आर्डर बनाएं (Add Order)",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (orderType == "SALE_ORDER") Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
            border = androidx.compose.foundation.BorderStroke(
              if (orderType == "SALE_ORDER") 1.5.dp else 1.dp,
              if (orderType == "SALE_ORDER") VyaparBlue else Color(0xFFE2E8F0)
            ),
            modifier = Modifier
              .weight(1f)
              .clickable { orderType = "SALE_ORDER" }
          ) {
            Box(modifier = Modifier.padding(8.dp), contentAlignment = Alignment.Center) {
              Text(
                text = "सेल्स आर्डर (Sale Order)",
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = if (orderType == "SALE_ORDER") VyaparBlue else TextSecondary
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (orderType == "PURCHASE_ORDER") Color(0xFFFEF3C7) else Color(0xFFF1F5F9),
            border = androidx.compose.foundation.BorderStroke(
              if (orderType == "PURCHASE_ORDER") 1.5.dp else 1.dp,
              if (orderType == "PURCHASE_ORDER") VyaparAmber else Color(0xFFE2E8F0)
            ),
            modifier = Modifier
              .weight(1f)
              .clickable { orderType = "PURCHASE_ORDER" }
          ) {
            Box(modifier = Modifier.padding(8.dp), contentAlignment = Alignment.Center) {
              Text(
                text = "पर्चेज आर्डर (Purchase)",
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = if (orderType == "PURCHASE_ORDER") Color(0xFFB45309) else TextSecondary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = party,
          onValueChange = { party = it },
          label = { Text("पार्टी / ग्राहक का नाम *") },
          placeholder = { Text("उदा. श्री राजेश त्रिपाठी") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("order_party_name_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text("मोबाइल नंबर") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = totalStr,
            onValueChange = { totalStr = it },
            label = { Text("अनुमानित कुल राशि (₹) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = advStr,
            onValueChange = { advStr = it },
            label = { Text("प्राप्त एडवांस (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("रद्द करें")
          }

          Button(
            onClick = {
              val tot = totalStr.toDoubleOrNull() ?: 0.0
              val adv = advStr.toDoubleOrNull() ?: 0.0
              if (party.isNotBlank() && tot > 0) {
                onSave(party.trim(), phone.trim(), orderType, tot, adv)
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("save_order_button")
          ) {
            Text("आर्डर सुरक्षित करें", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun PartyLedgerDialog(
  party: PartySummary,
  partyBookings: List<BookingEntity>,
  profile: BusinessProfileEntity,
  onDismiss: () -> Unit,
  onCall: () -> Unit,
  onWhatsApp: () -> Unit,
  onRecordPayment: () -> Unit,
  onShareStatement: () -> Unit,
  onBookingClick: (BookingEntity) -> Unit
) {
  val totalBilled = party.totalBilled
  val totalDue = party.totalDue
  val totalPaid = (totalBilled - totalDue).coerceAtLeast(0.0)

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth(0.94f)
        .fillMaxHeight(0.90f)
        .padding(8.dp)
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        // Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0F172A))
            .padding(horizontal = 14.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .background(Color(0xFF1E293B), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
            Column {
              Text(
                text = "${party.salutation} ${party.name}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Text(
                text = "📱 ${party.phone}",
                fontSize = 11.sp,
                color = Color(0xFF94A3B8)
              )
            }
          }

          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
        }

        // Action Toolbar: Call, WhatsApp, Record Payment, Share Statement
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF1F5F9))
            .padding(horizontal = 10.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Button(
            onClick = onCall,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(imageVector = Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(text = "कॉल", fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = onWhatsApp,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1.2f)
          ) {
            Icon(imageVector = Icons.Default.Message, contentDescription = null, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(text = "WhatsApp", fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = onRecordPayment,
            colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1.3f)
          ) {
            Text(text = "+ पेमेंट लें", fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = onShareStatement,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF475569)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1.1f)
          ) {
            Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(text = "लेजर", fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }
        }

        // Scrollable ledger
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Financial Summary Card
          item {
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = Color(0xFFF8FAFC),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(
                  text = "खाता सारांश (Account Summary)",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Column {
                    Text(text = "कुल बिलिंग", fontSize = 10.sp, color = TextSecondary)
                    Text(text = "₹ ${String.format("%,.0f", totalBilled)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                  }
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "प्राप्त राशि", fontSize = 10.sp, color = TextSecondary)
                    Text(text = "₹ ${String.format("%,.0f", totalPaid)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
                  }
                  Column(horizontalAlignment = Alignment.End) {
                    Text(text = "कुल बकाया", fontSize = 10.sp, color = TextSecondary)
                    Text(
                      text = "₹ ${String.format("%,.0f", totalDue)}",
                      fontSize = 15.sp,
                      fontWeight = FontWeight.Black,
                      color = if (totalDue > 0) SoePrimary else VyaparGreen
                    )
                  }
                }

                if (party.address.isNotBlank()) {
                  Spacer(modifier = Modifier.height(8.dp))
                  Text(text = "📍 पता: ${party.address}", fontSize = 10.sp, color = TextSecondary)
                }
              }
            }
          }

          // Transaction list title
          item {
            Text(
              text = "सभी इनवॉइस व बुकिंग्स (${partyBookings.size}) - क्लिक करके बिल देखें:",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          }

          itemsIndexed(partyBookings) { _, b ->
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color.White,
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onBookingClick(b) }
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "${b.formattedDate} • ${b.eventType}",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary
                    )
                    Text(
                      text = "इनवॉइस: ${b.invoiceNumber} • वेन्यू: ${b.eventVenueAddress}",
                      fontSize = 10.sp,
                      color = TextSecondary
                    )
                  }
                  Column(horizontalAlignment = Alignment.End) {
                    Text(
                      text = "₹ ${String.format("%,.0f", b.totalAmount)}",
                      fontSize = 13.sp,
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary
                    )
                    Text(
                      text = if (b.balanceDue > 0) "बाकी: ₹${String.format("%,.0f", b.balanceDue)}" else "✓ पूर्ण जमा",
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (b.balanceDue > 0) SoePrimary else VyaparGreen
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ItemDetailDialog(
  item: InventoryItemEntity,
  linkedBookings: List<BookingEntity>,
  onDismiss: () -> Unit,
  onUpdateStock: (Double) -> Unit,
  onSaveItem: (InventoryItemEntity) -> Unit
) {
  var stockStr by remember { mutableStateOf(item.stock.toString()) }
  var rateStr by remember { mutableStateOf(item.rate.toString()) }
  var costStr by remember { mutableStateOf(item.purchaseCost.toString()) }
  var minAlertStr by remember { mutableStateOf(item.minAlertStock.toString()) }
  var discountStr by remember { mutableStateOf(item.defaultDiscountPercent.toString()) }

  val currentStock = stockStr.toDoubleOrNull() ?: item.stock
  val currentRate = rateStr.toDoubleOrNull() ?: item.rate
  val currentCost = costStr.toDoubleOrNull() ?: item.purchaseCost
  val profitMargin = (currentRate - currentCost).coerceAtLeast(0.0)
  val isLowStock = currentStock <= item.minAlertStock

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth(0.94f)
        .fillMaxHeight(0.90f)
        .padding(8.dp)
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        // Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF312E81))
            .padding(horizontal = 14.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = item.name,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
            Text(
              text = "कैटेगरी: ${item.category} • यूनिट: ${item.unit}",
              fontSize = 11.sp,
              color = Color(0xFFC7D2FE)
            )
          }

          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
        }

        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Status and Valuation Card
          item {
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = if (isLowStock) Color(0xFFFFF1F2) else Color(0xFFF0FDF4),
              border = androidx.compose.foundation.BorderStroke(1.dp, if (isLowStock) Color(0xFFFECDD3) else Color(0xFFBBF7D0)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(
                    text = if (isLowStock) "⚠️ कम स्टॉक चेतावनी (Low Stock)" else "✓ पर्याप्त स्टॉक उपलब्ध",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isLowStock) SoePrimary else VyaparGreen
                  )
                  Text(
                    text = "कुल स्टॉक मूल्यांकन: ₹ ${String.format("%,.0f", currentStock * currentCost)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary
                  )
                }

                Box(
                  modifier = Modifier
                    .background(if (isLowStock) SoePrimary else VyaparGreen, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                  Text(
                    text = "$currentStock ${item.unit}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                }
              }
            }
          }

          // Batch & Tracking details
          item {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0xFFF8FAFC),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column {
                  Text(text = "बैच नंबर (Batch #):", fontSize = 10.sp, color = TextSecondary)
                  Text(text = item.batchNumber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                  Text(text = "सीरियल नंबर (Serial #):", fontSize = 10.sp, color = TextSecondary)
                  Text(text = item.serialNumber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }

          // Editable Fields
          item {
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = Color.White,
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(
                  text = "स्टॉक एवं दर संपादन (Edit Stock & Pricing)",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = VyaparBlue
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  OutlinedTextField(
                    value = stockStr,
                    onValueChange = { stockStr = it },
                    label = { Text("उपलब्ध स्टॉक") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                  )

                  OutlinedTextField(
                    value = minAlertStr,
                    onValueChange = { minAlertStr = it },
                    label = { Text("अलर्ट लिमिट") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                  )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  OutlinedTextField(
                    value = rateStr,
                    onValueChange = { rateStr = it },
                    label = { Text("बिक्री दर (₹ Rate)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                  )

                  OutlinedTextField(
                    value = costStr,
                    onValueChange = { costStr = it },
                    label = { Text("लागत (₹ Cost)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                  )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  OutlinedTextField(
                    value = discountStr,
                    onValueChange = { discountStr = it },
                    label = { Text("छूट प्रतिशत (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                  )

                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFDCFCE7),
                    modifier = Modifier
                      .weight(1f)
                      .height(56.dp)
                  ) {
                    Column(
                      modifier = Modifier.padding(6.dp),
                      verticalArrangement = Arrangement.Center,
                      horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                      Text(text = "प्रति यूनिट लाभ:", fontSize = 9.sp, color = Color(0xFF14532D))
                      Text(text = "+ ₹ ${String.format("%,.0f", profitMargin)}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
                    }
                  }
                }
              }
            }
          }

          // Linked Bookings
          item {
            Text(
              text = "आगामी इवेंट्स जहां यह आइटम बुक है:",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          }

          if (linkedBookings.isEmpty()) {
            item {
              Text(
                text = "वर्तमान में किसी इवेंट में बुक नहीं है।",
                fontSize = 11.sp,
                color = TextSecondary,
                modifier = Modifier.padding(vertical = 4.dp)
              )
            }
          } else {
            itemsIndexed(linkedBookings.take(3)) { _, b ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                  .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(text = "${b.formattedDate} • ${b.customerName}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  Text(text = b.eventVenueAddress, fontSize = 9.sp, color = TextSecondary)
                }
                Text(text = b.eventType, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
              }
            }
          }
        }

        // Save & Dismiss Footer
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("रद्द करें")
          }

          Button(
            onClick = {
              val s = stockStr.toDoubleOrNull() ?: item.stock
              val r = rateStr.toDoubleOrNull() ?: item.rate
              val c = costStr.toDoubleOrNull() ?: item.purchaseCost
              val m = minAlertStr.toDoubleOrNull() ?: item.minAlertStock
              val d = discountStr.toDoubleOrNull() ?: item.defaultDiscountPercent

              onSaveItem(
                item.copy(
                  stock = s,
                  rate = r,
                  purchaseCost = c,
                  minAlertStock = m,
                  defaultDiscountPercent = d
                )
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF312E81)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1.5f)
          ) {
            Text("सुरक्षित करें (Save Changes)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
        }
      }
    }
  }
}

@Composable
fun PurchaseDetailDialog(
  purchase: PurchaseEntity,
  onDismiss: () -> Unit,
  onMarkPaid: () -> Unit,
  onShareWhatsApp: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(text = "खरीदी बिल विवरण", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = purchase.billNumber, fontSize = 11.sp, color = TextSecondary)
          }
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFFF8FAFC),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(text = "सप्लायर: ${purchase.vendorName}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(text = "सामान: ${purchase.itemName}", fontSize = 12.sp, color = TextPrimary)
            Text(text = "मात्रा: ${purchase.quantity} ${purchase.unit} @ ₹${purchase.rate}", fontSize = 11.sp, color = TextSecondary)
            Text(text = "तारीख: ${purchase.formattedDate} • माध्यम: ${purchase.paymentMode}", fontSize = 10.sp, color = TextSecondary)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "कुल बिल: ₹${String.format("%,.2f", purchase.totalAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              Text(text = "जमा: ₹${String.format("%,.2f", purchase.paidAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "बाकी देय राशि:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
              Text(text = "₹ ${String.format("%,.2f", purchase.dueAmount)}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = if (purchase.dueAmount > 0) SoePrimary else VyaparGreen)
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          if (purchase.dueAmount > 0) {
            Button(
              onClick = onMarkPaid,
              colors = ButtonDefaults.buttonColors(containerColor = VyaparGreen),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            ) {
              Text("पूर्ण चुकता मार्क करें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }

          Button(
            onClick = onShareWhatsApp,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("WhatsApp भेजें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun ExpenseDetailDialog(
  expense: ExpenseEntity,
  onDismiss: () -> Unit,
  onDelete: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(text = "खर्च वाउचर विवरण", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = expense.formattedDate, fontSize = 11.sp, color = TextSecondary)
          }
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFFFFE4E6),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(text = expense.expenseTitle, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = "श्रेणी: ${expense.category}", fontSize = 11.sp, color = TextSecondary)
            Text(text = "माध्यम: ${expense.paymentMode}", fontSize = 11.sp, color = TextSecondary)
            if (expense.remarks.isNotBlank()) {
              Text(text = "रिमार्क: ${expense.remarks}", fontSize = 11.sp, color = TextSecondary)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "राशि: ₹ ${String.format("%,.2f", expense.amount)}",
              fontSize = 16.sp,
              fontWeight = FontWeight.Black,
              color = SoePrimary
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("बंद करें")
          }

          Button(
            onClick = onDelete,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("खर्चा हटाएं", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun PaymentReceiptDialog(
  payment: CustomerPaymentEntity,
  profile: BusinessProfileEntity,
  onDismiss: () -> Unit,
  onShareWhatsApp: () -> Unit
) {
  val isIn = payment.paymentType == "PAYMENT_IN"

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = if (isIn) "भुगतान प्राप्ति रसीद (Payment-In)" else "भुगतान वापसी रसीद (Payment-Out)",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = if (isIn) VyaparGreen else SoePrimary
            )
            Text(text = payment.receiptNumber, fontSize = 10.sp, color = TextSecondary)
          }
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFFF8FAFC),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(text = "पार्टी / ग्राहक: ${payment.customerName}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            if (payment.customerPhone.isNotBlank()) {
              Text(text = "मोबाइल: ${payment.customerPhone}", fontSize = 11.sp, color = TextSecondary)
            }
            Text(text = "तारीख: ${payment.formattedDate} • माध्यम: ${payment.paymentMode}", fontSize = 11.sp, color = TextSecondary)
            if (payment.note.isNotBlank()) {
              Text(text = "विवरण: ${payment.note}", fontSize = 11.sp, color = TextSecondary)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(text = "जमा की गई कुल राशि:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              Text(
                text = "₹ ${String.format("%,.2f", payment.amount)}",
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = if (isIn) VyaparGreen else SoePrimary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = onShareWhatsApp,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("ग्राहक को WhatsApp रसीद भेजें", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun OrderDetailDialog(
  order: OrderEntity,
  onDismiss: () -> Unit,
  onStatusChange: (String) -> Unit,
  onShareWhatsApp: () -> Unit
) {
  val isSale = order.orderType == "SALE_ORDER"

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = if (isSale) "सेल्स आर्डर विवरण" else "पर्चेज आर्डर विवरण",
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Text(text = order.orderNumber, fontSize = 11.sp, color = TextSecondary)
          }
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFFF8FAFC),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(text = "पार्टी का नाम: ${order.partyName}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(text = "फोन: ${order.partyPhone}", fontSize = 11.sp, color = TextSecondary)
            Text(text = "ऑर्डर तारीख: ${order.orderDate} • डिलीवरी: ${order.deliveryDate}", fontSize = 11.sp, color = TextSecondary)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "कुल आर्डर मूल्य:", fontSize = 11.sp, color = TextSecondary)
              Text(text = "₹ ${String.format("%,.2f", order.totalAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "प्राप्त एडवांस:", fontSize = 11.sp, color = VyaparGreen)
              Text(text = "₹ ${String.format("%,.2f", order.advanceAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
            }
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "शेष बकाया राशि:", fontSize = 11.sp, color = SoePrimary)
              Text(text = "₹ ${String.format("%,.2f", order.totalAmount - order.advanceAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = SoePrimary)
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Status Changer
        Text(text = "ऑर्डर की स्थिति बदलें:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          listOf("OPEN" to "ओपन", "COMPLETED" to "पूर्ण", "CANCELLED" to "रद्द").forEach { (statusKey, statusLabel) ->
            val isSel = order.status == statusKey
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isSel) VyaparBlue else Color(0xFFF1F5F9),
              modifier = Modifier
                .weight(1f)
                .clickable { onStatusChange(statusKey) }
            ) {
              Box(modifier = Modifier.padding(8.dp), contentAlignment = Alignment.Center) {
                Text(
                  text = statusLabel,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isSel) Color.White else TextPrimary
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = onShareWhatsApp,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("WhatsApp पर ऑर्डर विवरण भेजें", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
