package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextFieldColors

private val DarkColorScheme = lightColorScheme(
  primary = SoePrimary,
  onPrimary = Color.White,
  primaryContainer = SoePrimaryLight,
  onPrimaryContainer = SoePrimaryDark,
  secondary = VyaparBlue,
  onSecondary = Color.White,
  secondaryContainer = VyaparLightBlue,
  onSecondaryContainer = VyaparDarkBlue,
  tertiary = VyaparGreen,
  onTertiary = Color.White,
  tertiaryContainer = VyaparLightGreen,
  onTertiaryContainer = VyaparDarkGreen,
  background = SurfaceLight,
  surface = Color.White,
  onBackground = TextPrimary,
  onSurface = TextPrimary,
  surfaceVariant = SurfaceSlate,
  onSurfaceVariant = TextSecondary,
  outline = BorderColor
)

private val LightColorScheme = lightColorScheme(
  primary = SoePrimary,
  onPrimary = Color.White,
  primaryContainer = SoePrimaryLight,
  onPrimaryContainer = SoePrimaryDark,
  secondary = VyaparBlue,
  onSecondary = Color.White,
  secondaryContainer = VyaparLightBlue,
  onSecondaryContainer = VyaparDarkBlue,
  tertiary = VyaparGreen,
  onTertiary = Color.White,
  tertiaryContainer = VyaparLightGreen,
  onTertiaryContainer = VyaparDarkGreen,
  background = SurfaceLight,
  surface = Color.White,
  onBackground = TextPrimary,
  onSurface = TextPrimary,
  surfaceVariant = SurfaceSlate,
  onSurfaceVariant = TextSecondary,
  outline = BorderColor
)

@Composable
fun appTextFieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
  focusedTextColor = Color(0xFF0F172A),
  unfocusedTextColor = Color(0xFF0F172A),
  focusedContainerColor = Color.White,
  unfocusedContainerColor = Color(0xFFF8FAFC),
  focusedBorderColor = VyaparBlue,
  unfocusedBorderColor = Color(0xFFCBD5E1),
  focusedLabelColor = VyaparBlue,
  unfocusedLabelColor = Color(0xFF475569),
  cursorColor = VyaparBlue,
  focusedPlaceholderColor = Color(0xFF94A3B8),
  unfocusedPlaceholderColor = Color(0xFF94A3B8)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = LightColorScheme,
    typography = Typography,
    content = content
  )
}
