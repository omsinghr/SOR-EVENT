package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Api
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BookingEntity
import com.example.data.model.BusinessProfileEntity
import com.example.data.model.CustomerPaymentEntity
import com.example.data.model.EmployeeAttendanceEntity
import com.example.data.model.EmployeeEntity
import com.example.data.model.EmployeePaymentEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.InventoryItemEntity
import com.example.data.model.ItemPriceHistoryEntity
import com.example.data.model.PurchaseEntity
import com.example.ui.AdminSection
import com.example.ui.MainViewModel
import com.example.ui.theme.SoePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VyaparAmber
import com.example.ui.theme.VyaparBlue
import com.example.ui.theme.VyaparDarkGreen
import com.example.ui.theme.VyaparGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminPanelScreen(
  viewModel: MainViewModel,
  profile: BusinessProfileEntity,
  isAdminUnlocked: Boolean,
  isSyncing: Boolean,
  bookings: List<BookingEntity>,
  inventoryItems: List<InventoryItemEntity>,
  purchases: List<PurchaseEntity>,
  expenses: List<ExpenseEntity>,
  payments: List<CustomerPaymentEntity>,
  employees: List<EmployeeEntity>,
  attendance: List<EmployeeAttendanceEntity>,
  employeePayments: List<EmployeePaymentEntity>,
  priceHistory: List<ItemPriceHistoryEntity>,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  if (!isAdminUnlocked) {
    // PIN GATE SCREEN
    Box(
      modifier = modifier
        .fillMaxSize()
        .padding(20.dp),
      contentAlignment = Alignment.Center
    ) {
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        shadowElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Box(
            modifier = Modifier
              .size(56.dp)
              .background(Color(0xFFFEF2F2), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Security,
              contentDescription = null,
              tint = SoePrimary,
              modifier = Modifier.size(32.dp)
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          Text(
            text = "Admin ERP Dashboard is Locked",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )

          Text(
            text = "Enter 4-digit Admin PIN to access booking management, advance reports, cost & profit analytics, employee payroll, and system security settings. (Default: 1234)",
            fontSize = 11.sp,
            color = TextSecondary,
            lineHeight = 16.sp,
            modifier = Modifier.padding(vertical = 8.dp)
          )

          Spacer(modifier = Modifier.height(10.dp))

          var pinInput by remember { mutableStateOf("") }
          OutlinedTextField(
            value = pinInput,
            onValueChange = { if (it.length <= 4) pinInput = it },
            placeholder = { Text("4-Digit PIN") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("admin_gate_pin_input"),
            singleLine = true
          )

          Spacer(modifier = Modifier.height(16.dp))

          Button(
            onClick = { viewModel.verifyAdminPin(pinInput) },
            colors = ButtonDefaults.buttonColors(containerColor = SoePrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("admin_gate_unlock_button")
          ) {
            Text(text = "🔓 Unlock Admin ERP", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          }
        }
      }
    }
    return
  }

  // UNLOCKED ADMIN ERP DASHBOARD
  val activeSection by viewModel.adminSubSection.collectAsState()
  val adminBookingFilter by viewModel.adminBookingFilter.collectAsState()
  val adminCollectionTab by viewModel.adminCollectionTab.collectAsState()

  val curLang by viewModel.appLanguage.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp, vertical = 6.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Pro Header with Active Status & Lock action
    item {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = VyaparBlue,
        modifier = Modifier.fillMaxWidth(),
        shadowElevation = 2.dp
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
              ) {
                Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
              }
              Column {
                Text(
                  text = "Admin ERP Dashboard",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
                Text(
                  text = "SHREE OM EVENT UMARIA",
                  fontSize = 11.sp,
                  color = Color(0xFFE2E8F0)
                )
              }
            }

            OutlinedButton(
              onClick = { viewModel.lockAdmin() },
              colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(13.dp), tint = Color.White)
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "Lock",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Section Selector Tabs
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            val sections = listOf(
              AdminSection.BOOKINGS to "📋 Bookings",
              AdminSection.ADVANCE to "💰 Advance",
              AdminSection.COMPLETED to "🏆 Completed",
              AdminSection.COLLECTION to "💳 Collection",
              AdminSection.PROFIT_ANALYSIS to "📈 Cost & Profit",
              AdminSection.EMPLOYEES to "👷 Employees",
              AdminSection.SETTINGS to "⚙️ Settings"
            )

            sections.forEach { (sec, label) ->
              val isSelected = activeSection == sec
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(12.dp))
                  .background(if (isSelected) Color.White else Color.White.copy(alpha = 0.18f))
                  .clickable { viewModel.setAdminSubSection(sec) }
                  .padding(horizontal = 12.dp, vertical = 6.dp)
              ) {
                Text(
                  text = label,
                  fontSize = 11.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                  color = if (isSelected) VyaparBlue else Color.White
                )
              }
            }
          }
        }
      }
    }

    // 2. Dynamic Section Content
    when (activeSection) {
      AdminSection.BOOKINGS -> {
        // A. BOOKING MANAGEMENT REPORT
        item {
          BookingManagementSection(
            bookings = bookings,
            currentFilter = adminBookingFilter,
            onFilterChange = { viewModel.setAdminBookingFilter(it) },
            onBookingClick = { viewModel.openInvoicePreview(it) }
          )
        }
      }

      AdminSection.ADVANCE -> {
        // B. ADVANCE PAYMENT REPORT
        item {
          AdvancePaymentReportSection(
            bookings = bookings,
            onBookingClick = { viewModel.openInvoicePreview(it) },
            onSourceClick = { viewModel.openFinancialSourceModal("ADVANCE_PAYMENTS") }
          )
        }
      }

      AdminSection.COMPLETED -> {
        // C. COMPLETED BOOKING HISTORY
        item {
          CompletedBookingHistorySection(
            bookings = bookings,
            onBookingClick = { viewModel.openInvoicePreview(it) }
          )
        }
      }

      AdminSection.COLLECTION -> {
        // D. PAYMENT COLLECTION REPORT
        item {
          PaymentCollectionSection(
            bookings = bookings,
            currentTab = adminCollectionTab,
            onTabChange = { viewModel.setAdminCollectionTab(it) },
            onBookingClick = { viewModel.openInvoicePreview(it) },
            onCall = { phone -> viewModel.callPhone(context, phone) },
            onWhatsApp = { b -> viewModel.shareInvoiceViaWhatsApp(context, b) }
          )
        }
      }

      AdminSection.PROFIT_ANALYSIS -> {
        // E. BOOKING COST & PROFIT ANALYSIS
        item {
          CostAndProfitAnalysisSection(
            bookings = bookings,
            purchases = purchases,
            expenses = expenses,
            onBookingClick = { viewModel.openInvoicePreview(it) },
            onOpenSource = { type -> viewModel.openFinancialSourceModal(type) }
          )
        }
      }

      AdminSection.EMPLOYEES -> {
        // F. EMPLOYEE MANAGEMENT & ATTENDANCE SYSTEM
        item {
          EmployeeManagementSection(
            employees = employees,
            attendance = attendance,
            payments = employeePayments,
            bookings = bookings,
            onAddEmployee = { viewModel.openAddEmployeeDialog() },
            onRecordAttendance = { viewModel.openRecordAttendanceDialog() },
            onRecordPayment = { viewModel.openRecordEmployeePaymentDialog() },
            onEmployeeClick = { viewModel.openEmployeeDetail(it) }
          )
        }
      }

      AdminSection.SETTINGS -> {
        // G. SETTINGS & SYNC
        item {
          AdminSettingsSection(
            viewModel = viewModel,
            profile = profile,
            isSyncing = isSyncing
          )
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(60.dp))
    }
  }
}

// =========================================================================
// SECTION A: BOOKING MANAGEMENT REPORT
// =========================================================================

@Composable
private fun BookingManagementSection(
  bookings: List<BookingEntity>,
  currentFilter: String,
  onFilterChange: (String) -> Unit,
  onBookingClick: (BookingEntity) -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }

  val filterOptions = listOf(
    "ALL" to "All (${bookings.size})",
    "CONFIRMED" to "Confirmed (${bookings.count { it.status == "CONFIRMED" }})",
    "COMPLETED" to "Completed (${bookings.count { it.status == "COMPLETED" || (it.status == "PAYMENT-IN" && it.balanceDue == 0.0) }})",
    "UPCOMING" to "Upcoming",
    "CANCELLED" to "Cancelled (${bookings.count { it.status == "CANCELLED" }})",
    "PENDING" to "Pending Due (${bookings.count { it.balanceDue > 0 && it.status != "CANCELLED" }})"
  )

  val filtered = remember(bookings, currentFilter, searchQuery) {
    bookings.filter { b ->
      val matchesFilter = when (currentFilter) {
        "CONFIRMED" -> b.status == "CONFIRMED"
        "COMPLETED" -> b.status == "COMPLETED" || (b.status == "PAYMENT-IN" && b.balanceDue == 0.0)
        "UPCOMING" -> b.status != "CANCELLED" && b.status != "COMPLETED"
        "CANCELLED" -> b.status == "CANCELLED"
        "PENDING" -> b.balanceDue > 0 && b.status != "CANCELLED"
        else -> true
      }
      val matchesSearch = b.customerName.contains(searchQuery, ignoreCase = true) ||
        b.invoiceNumber.contains(searchQuery, ignoreCase = true) ||
        b.id.toString().contains(searchQuery) ||
        b.eventDate.contains(searchQuery) ||
        b.eventType.contains(searchQuery, ignoreCase = true)
      matchesFilter && matchesSearch
    }
  }

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "📋 Booking Management Report",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Text(
          text = "${filtered.size} Records",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = VyaparBlue
        )
      }

      // Search Bar
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search customer, booking ID, date...", fontSize = 11.sp) },
        leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp)) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
      )

      // Filter Tabs
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        filterOptions.forEach { (code, label) ->
          val isSel = currentFilter == code
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSel) VyaparBlue else Color(0xFFF1F5F9))
              .clickable { onFilterChange(code) }
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text(
              text = label,
              fontSize = 11.sp,
              fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
              color = if (isSel) Color.White else TextPrimary
            )
          }
        }
      }

      // Summary metrics
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(color = Color(0xFFEFF6FF), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(8.dp)) {
            Text(text = "Total Billed", fontSize = 10.sp, color = VyaparBlue)
            Text(text = "₹${String.format("%,.0f", filtered.sumOf { it.totalAmount })}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
          }
        }
        Surface(color = Color(0xFFDCFCE7), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(8.dp)) {
            Text(text = "Advance Paid", fontSize = 10.sp, color = VyaparGreen)
            Text(text = "₹${String.format("%,.0f", filtered.sumOf { it.advancePaid })}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
          }
        }
        Surface(color = Color(0xFFFFE4E6), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(8.dp)) {
            Text(text = "Balance Due", fontSize = 10.sp, color = SoePrimary)
            Text(text = "₹${String.format("%,.0f", filtered.sumOf { it.balanceDue })}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
          }
        }
      }

      // Bookings List
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (filtered.isEmpty()) {
          Text(
            text = "No booking records found.",
            fontSize = 11.sp,
            color = TextSecondary,
            modifier = Modifier.padding(vertical = 12.dp)
          )
        } else {
          filtered.forEach { b ->
            val statusColor = when (b.status) {
              "CONFIRMED" -> VyaparBlue
              "COMPLETED" -> VyaparGreen
              "CANCELLED" -> SoePrimary
              else -> VyaparAmber
            }

            Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color(0xFFF8FAFC),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onBookingClick(b) }
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "${b.salutation} ${b.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Box(
                      modifier = Modifier
                        .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                      Text(text = b.status, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = statusColor)
                    }
                  }
                  Text(text = "#${b.id} • ${b.formattedDate} • Event: ${b.eventType}", fontSize = 10.sp, color = TextSecondary)
                  Text(text = "Adv: ₹${b.advancePaid} | Due: ₹${b.balanceDue} | Mode: ${b.paymentMode}", fontSize = 9.sp, color = Color(0xFF64748B))
                }
                Column(horizontalAlignment = Alignment.End) {
                  Text(text = "₹${String.format("%,.0f", b.totalAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VyaparBlue)
                  Text(text = "Details >", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
                }
              }
            }
          }
        }
      }
    }
  }
}

// =========================================================================
// SECTION B: ADVANCE PAYMENT REPORT
// =========================================================================

@Composable
private fun AdvancePaymentReportSection(
  bookings: List<BookingEntity>,
  onBookingClick: (BookingEntity) -> Unit,
  onSourceClick: () -> Unit
) {
  val advanceBookings = remember(bookings) { bookings.filter { it.advancePaid > 0 } }
  val totalAdvance = remember(advanceBookings) { advanceBookings.sumOf { it.advancePaid } }
  val totalSalesWithAdvance = remember(advanceBookings) { advanceBookings.sumOf { it.totalAmount } }
  val advanceCoverage = if (totalSalesWithAdvance > 0) ((totalAdvance / totalSalesWithAdvance) * 100).toInt() else 0

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "💰 Advance Payment Report", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = "Total advance payments received on bookings", fontSize = 10.sp, color = TextSecondary)
        }
        OutlinedButton(onClick = onSourceClick, shape = RoundedCornerShape(8.dp)) {
          Text(text = "🔍 View Source", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
      }

      // KPI Card for Advance
      Surface(
        color = Color(0xFFDCFCE7),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onSourceClick() }
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(text = "Total Advance Received", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF166534))
            Text(text = "₹ ${String.format("%,.2f", totalAdvance)}", fontSize = 18.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
            Text(text = "$advanceCoverage% of total billing received in advance", fontSize = 10.sp, color = Color(0xFF166534))
          }
          Box(
            modifier = Modifier
              .size(44.dp)
              .background(Color.White, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(imageVector = Icons.Default.Payments, contentDescription = null, tint = VyaparGreen, modifier = Modifier.size(24.dp))
          }
        }
      }

      Text(text = "Booking-Wise & Customer-Wise Advance Breakdown:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        advanceBookings.forEach { b ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF8FAFC),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onBookingClick(b) }
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(text = "${b.salutation} ${b.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = "#${b.id} • ${b.formattedDate} • ${b.eventType}", fontSize = 10.sp, color = TextSecondary)
                Text(text = "Mode: ${b.paymentMode} | Billed: ₹${b.totalAmount} | Due: ₹${b.balanceDue}", fontSize = 9.sp, color = Color(0xFF64748B))
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(text = "+₹${String.format("%,.0f", b.advancePaid)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
                Text(text = "Advance Paid", fontSize = 9.sp, color = VyaparDarkGreen)
              }
            }
          }
        }
      }
    }
  }
}

// =========================================================================
// SECTION C: COMPLETED BOOKING HISTORY
// =========================================================================

@Composable
private fun CompletedBookingHistorySection(
  bookings: List<BookingEntity>,
  onBookingClick: (BookingEntity) -> Unit
) {
  val completed = remember(bookings) {
    bookings.filter { it.status == "COMPLETED" || (it.status == "PAYMENT-IN" && it.balanceDue == 0.0) }
  }

  val totalCompletedRevenue = remember(completed) { completed.sumOf { it.totalAmount } }
  val totalCompletedCost = remember(completed) { completed.sumOf { it.estimatedCost } }
  val totalCompletedProfit = (totalCompletedRevenue - totalCompletedCost).coerceAtLeast(0.0)

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "🏆 Completed Events History", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = "Successfully executed events, revenue, cost & profit logs", fontSize = 10.sp, color = TextSecondary)
        }
        Text(text = "${completed.size} Done", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
      }

      // Summary Bar
      Surface(color = Color(0xFFF1F5F9), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
          Column {
            Text(text = "Completed Billed", fontSize = 10.sp, color = TextSecondary)
            Text(text = "₹${String.format("%,.0f", totalCompletedRevenue)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
          }
          Column {
            Text(text = "Total Cost", fontSize = 10.sp, color = TextSecondary)
            Text(text = "₹${String.format("%,.0f", totalCompletedCost)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
          }
          Column(horizontalAlignment = Alignment.End) {
            Text(text = "Total Net Profit", fontSize = 10.sp, color = TextSecondary)
            Text(text = "₹${String.format("%,.0f", totalCompletedProfit)}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
          }
        }
      }

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (completed.isEmpty()) {
          Text(text = "No completed events recorded.", fontSize = 11.sp, color = TextSecondary)
        } else {
          completed.forEach { b ->
            val profit = (b.totalAmount - b.estimatedCost).coerceAtLeast(0.0)
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color(0xFFF8FAFC),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onBookingClick(b) }
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = VyaparGreen, modifier = Modifier.size(14.dp))
                    Text(text = "${b.salutation} ${b.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                  }
                  Text(text = "Event: ${b.eventType} • Date: ${b.formattedDate}", fontSize = 10.sp, color = TextSecondary)
                  Text(text = "Cost: ₹${b.estimatedCost} • Payment: Paid in Full (${b.paymentMode})", fontSize = 9.sp, color = Color(0xFF64748B))
                }
                Column(horizontalAlignment = Alignment.End) {
                  Text(text = "₹${String.format("%,.0f", b.totalAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VyaparBlue)
                  Text(text = "Profit: +₹${String.format("%,.0f", profit)}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
                }
              }
            }
          }
        }
      }
    }
  }
}

// =========================================================================
// SECTION D: PAYMENT COLLECTION REPORT
// =========================================================================

@Composable
private fun PaymentCollectionSection(
  bookings: List<BookingEntity>,
  currentTab: String,
  onTabChange: (String) -> Unit,
  onBookingClick: (BookingEntity) -> Unit,
  onCall: (String) -> Unit,
  onWhatsApp: (BookingEntity) -> Unit
) {
  val paidBookings = remember(bookings) { bookings.filter { it.balanceDue == 0.0 && it.status != "CANCELLED" } }
  val pendingBookings = remember(bookings) { bookings.filter { it.balanceDue > 0.0 && it.status != "CANCELLED" } }

  val totalPaidAmount = remember(bookings) { bookings.filter { it.status != "CANCELLED" }.sumOf { it.advancePaid } }
  val totalPendingAmount = remember(pendingBookings) { pendingBookings.sumOf { it.balanceDue } }

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Text(text = "💳 Payment Collection Register", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

      // 2 Cards: Collected vs Pending
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(color = Color(0xFFDCFCE7), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(text = "Total Collected", fontSize = 10.sp, color = Color(0xFF166534))
            Text(text = "₹${String.format("%,.0f", totalPaidAmount)}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
            Text(text = "${paidBookings.size} Paid in Full", fontSize = 9.sp, color = Color(0xFF166534))
          }
        }

        Surface(color = Color(0xFFFFE4E6), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(text = "Total Pending Due", fontSize = 10.sp, color = SoePrimary)
            Text(text = "₹${String.format("%,.0f", totalPendingAmount)}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = SoePrimary)
            Text(text = "${pendingBookings.size} Pending Debtors", fontSize = 9.sp, color = SoePrimary)
          }
        }
      }

      // Tab selector: Paid vs Pending
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(if (currentTab == "PENDING") SoePrimary else Color(0xFFF1F5F9))
            .clickable { onTabChange("PENDING") }
            .padding(vertical = 8.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(text = "⚠️ Pending Due (${pendingBookings.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (currentTab == "PENDING") Color.White else TextPrimary)
        }

        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(if (currentTab == "PAID") VyaparGreen else Color(0xFFF1F5F9))
            .clickable { onTabChange("PAID") }
            .padding(vertical = 8.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(text = "✅ Paid in Full (${paidBookings.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (currentTab == "PAID") Color.White else TextPrimary)
        }
      }

      val displayList = if (currentTab == "PENDING") pendingBookings else paidBookings

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        displayList.forEach { b ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF8FAFC),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onBookingClick(b) }
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(text = "${b.salutation} ${b.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = "📱 ${b.customerPhone} • #${b.id} • ${b.formattedDate}", fontSize = 10.sp, color = TextSecondary)
                Text(text = "Total: ₹${b.totalAmount} | Paid: ₹${b.advancePaid}", fontSize = 9.sp, color = Color(0xFF64748B))
              }

              Column(horizontalAlignment = Alignment.End) {
                if (currentTab == "PENDING") {
                  Text(text = "Due: ₹${String.format("%,.0f", b.balanceDue)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = SoePrimary)
                  Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 4.dp)) {
                    IconButton(onClick = { onCall(b.customerPhone) }, modifier = Modifier.size(26.dp)) {
                      Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = VyaparGreen, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = { onWhatsApp(b) }, modifier = Modifier.size(26.dp)) {
                      Icon(imageVector = Icons.Default.Receipt, contentDescription = "Reminder", tint = VyaparBlue, modifier = Modifier.size(16.dp))
                    }
                  }
                } else {
                  Text(text = "₹${String.format("%,.0f", b.totalAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
                  Text(text = "Paid in Full", fontSize = 9.sp, color = VyaparDarkGreen)
                }
              }
            }
          }
        }
      }
    }
  }
}

// =========================================================================
// SECTION E: BOOKING COST & PROFIT ANALYSIS
// =========================================================================

@Composable
private fun CostAndProfitAnalysisSection(
  bookings: List<BookingEntity>,
  purchases: List<PurchaseEntity>,
  expenses: List<ExpenseEntity>,
  onBookingClick: (BookingEntity) -> Unit,
  onOpenSource: (String) -> Unit
) {
  val validBookings = remember(bookings) { bookings.filter { it.status != "CANCELLED" } }

  // Financial Calculations according to user brief
  val totalBookingAmount = remember(validBookings) { validBookings.sumOf { it.totalAmount } }
  val totalItemPurchaseCost = remember(validBookings) { validBookings.sumOf { it.estimatedCost * 0.7 } } // approximate item hardware cost
  val otherOperationalExpenses = remember(validBookings) { validBookings.sumOf { it.estimatedCost * 0.3 } } // labor, transport, generator
  val totalBookingCost = remember(validBookings) { validBookings.sumOf { it.estimatedCost } }
  val totalEstimatedProfit = (totalBookingAmount - totalBookingCost).coerceAtLeast(0.0)
  val avgProfitPerBooking = if (validBookings.isNotEmpty()) totalEstimatedProfit / validBookings.size else 0.0
  val overallMargin = if (totalBookingAmount > 0) ((totalEstimatedProfit / totalBookingAmount) * 100).toInt() else 0

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "📈 Booking Cost & Net Profit Analysis", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = "Item hardware cost + operating expenses vs gross revenue", fontSize = 10.sp, color = TextSecondary)
        }
        OutlinedButton(onClick = { onOpenSource("NET_PROFIT") }, shape = RoundedCornerShape(8.dp)) {
          Text(text = "🔍 View Source", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
      }

      // Main Cost & Profit Summary Cards
      Surface(
        color = Color(0xFFECFDF5),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onOpenSource("NET_PROFIT") }
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Total Booking Revenue:", fontSize = 11.sp, color = TextSecondary)
            Text(text = "₹ ${String.format("%,.2f", totalBookingAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
          }
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "(-) Total Event Cost (Items + Expenses):", fontSize = 11.sp, color = TextSecondary)
            Text(text = "₹ ${String.format("%,.2f", totalBookingCost)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
          }
          androidx.compose.material3.Divider(color = Color(0xFFD1FAE5))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
              Text(text = "Estimated Net Profit:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF166534))
              Text(text = "Avg Profit per Booking: ₹${String.format("%,.0f", avgProfitPerBooking)}", fontSize = 10.sp, color = Color(0xFF166534))
            }
            Column(horizontalAlignment = Alignment.End) {
              Text(text = "₹ ${String.format("%,.2f", totalEstimatedProfit)}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = VyaparDarkGreen)
              Text(text = "$overallMargin% Net Margin", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
            }
          }
        }
      }

      // Breakdown of costs
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(color = Color(0xFFFEF3C7), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(text = "Item Hardware Cost", fontSize = 10.sp, color = Color(0xFFB45309))
            Text(text = "₹${String.format("%,.0f", totalItemPurchaseCost)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
            Text(text = "Pyro, fog, truss, consumables", fontSize = 8.sp, color = TextSecondary)
          }
        }
        Surface(color = Color(0xFFFFE4E6), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(text = "Operational Expenses", fontSize = 10.sp, color = SoePrimary)
            Text(text = "₹${String.format("%,.0f", otherOperationalExpenses)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
            Text(text = "Labor, transport, generator fuel", fontSize = 8.sp, color = TextSecondary)
          }
        }
      }

      Text(text = "Booking-Wise Cost & Profit Breakdown:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        validBookings.forEach { b ->
          val cost = b.estimatedCost
          val profit = (b.totalAmount - cost).coerceAtLeast(0.0)
          val margin = if (b.totalAmount > 0) ((profit / b.totalAmount) * 100).toInt() else 0

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF8FAFC),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onBookingClick(b) }
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(text = "${b.salutation} ${b.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = "#${b.id} • ${b.formattedDate} • ${b.eventType}", fontSize = 10.sp, color = TextSecondary)
                Text(text = "Bill: ₹${b.totalAmount} | Cost: ₹${b.estimatedCost}", fontSize = 9.sp, color = Color(0xFF64748B))
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(text = "+₹${String.format("%,.0f", profit)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
                Text(text = "$margin% Margin", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparDarkGreen)
              }
            }
          }
        }
      }
    }
  }
}

// =========================================================================
// SECTION F: EMPLOYEE MANAGEMENT & ATTENDANCE SYSTEM
// =========================================================================

@Composable
private fun EmployeeManagementSection(
  employees: List<EmployeeEntity>,
  attendance: List<EmployeeAttendanceEntity>,
  payments: List<EmployeePaymentEntity>,
  bookings: List<BookingEntity>,
  onAddEmployee: () -> Unit,
  onRecordAttendance: () -> Unit,
  onRecordPayment: () -> Unit,
  onEmployeeClick: (EmployeeEntity) -> Unit
) {
  val totalEarnedAll = remember(attendance) {
    attendance.sumOf {
      when (it.status) {
        "PRESENT" -> it.dailyRate
        "HALF_DAY" -> it.dailyRate * 0.5
        else -> 0.0
      }
    }
  }
  val totalPaidAll = remember(payments) { payments.sumOf { it.amount } }
  val totalPendingAll = (totalEarnedAll - totalPaidAll).coerceAtLeast(0.0)

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "👷 Employee Management & Attendance Register", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = "Daily wage tracking, attendance logs & salary disbursement", fontSize = 10.sp, color = TextSecondary)
        }
        Button(
          onClick = onAddEmployee,
          colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(text = "+ Employee", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
      }

      // Quick Actions Row
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
          onClick = onRecordAttendance,
          colors = ButtonDefaults.buttonColors(containerColor = VyaparGreen),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f)
        ) {
          Text(text = "📅 Mark Attendance", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Button(
          onClick = onRecordPayment,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f)
        ) {
          Text(text = "💰 Pay Wage / Salary", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }

      // Metrics Summary
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(color = Color(0xFFEFF6FF), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(8.dp)) {
            Text(text = "Total Staff", fontSize = 10.sp, color = VyaparBlue)
            Text(text = "${employees.size} Active", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
          }
        }
        Surface(color = Color(0xFFDCFCE7), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(8.dp)) {
            Text(text = "Total Paid", fontSize = 10.sp, color = VyaparGreen)
            Text(text = "₹${String.format("%,.0f", totalPaidAll)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
          }
        }
        Surface(color = Color(0xFFFFE4E6), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
          Column(modifier = Modifier.padding(8.dp)) {
            Text(text = "Unpaid Balance", fontSize = 10.sp, color = SoePrimary)
            Text(text = "₹${String.format("%,.0f", totalPendingAll)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
          }
        }
      }

      Text(text = "Employee Directory (Tap to view ledger & work history):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        employees.forEach { emp ->
          val empAtt = attendance.filter { it.employeeId == emp.employeeId }
          val empPay = payments.filter { it.employeeId == emp.employeeId }
          val pCount = empAtt.count { it.status == "PRESENT" }
          val hdCount = empAtt.count { it.status == "HALF_DAY" }
          val earned = (pCount * emp.dailyWage) + (hdCount * emp.dailyWage * 0.5)
          val paid = empPay.sumOf { it.amount }
          val balance = (earned - paid).coerceAtLeast(0.0)

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF8FAFC),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onEmployeeClick(emp) }
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(text = "${emp.name} (${emp.employeeId})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = "${emp.category} • ₹${emp.dailyWage}/day • 📱 ${emp.mobile}", fontSize = 10.sp, color = TextSecondary)
                Text(text = "Attendance: $pCount Present, $hdCount Half-day | Earned: ₹$earned | Paid: ₹$paid", fontSize = 9.sp, color = Color(0xFF64748B))
              }
              Column(horizontalAlignment = Alignment.End) {
                if (balance > 0) {
                  Text(text = "Due: ₹${String.format("%,.0f", balance)}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = SoePrimary)
                } else {
                  Text(text = "Settled", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
                }
                Text(text = "Details >", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
              }
            }
          }
        }
      }
    }
  }
}

// =========================================================================
// SECTION G: SETTINGS & BACKUP
// =========================================================================

@Composable
private fun AdminSettingsSection(
  viewModel: MainViewModel,
  profile: BusinessProfileEntity,
  isSyncing: Boolean
) {
  val context = LocalContext.current
  var apiUrl by remember(profile) { mutableStateOf(profile.apiSyncUrl) }
  var webhookUrl by remember(profile) { mutableStateOf(profile.apiWebhookUrl) }
  var realtimeSyncEnabled by remember(profile) { mutableStateOf(profile.isRealtimeSyncEnabled) }
  var adminPinInput by remember(profile) { mutableStateOf(profile.adminPin) }
  var dailyLimitInput by remember(profile) { mutableStateOf(profile.dailyBookingLimit.toString()) }

  val formattedSyncTime = remember(profile.lastSyncedTimestamp) {
    val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    sdf.format(Date(profile.lastSyncedTimestamp))
  }

  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    // 1. Cloud Sync
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color.White,
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .background(Color(0xFFDCFCE7), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
          ) {
            Icon(imageVector = Icons.Default.CloudDone, contentDescription = null, tint = VyaparGreen, modifier = Modifier.size(20.dp))
          }
          Column {
            Text(text = "Real-Time Sync & Offline Mode", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = "Last synced: $formattedSyncTime", fontSize = 10.sp, color = TextSecondary)
          }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Column {
            Text(text = "Auto Background Sync", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Text(text = "Instantly sync when online", fontSize = 10.sp, color = TextSecondary)
          }
          Switch(
            checked = realtimeSyncEnabled,
            onCheckedChange = { realtimeSyncEnabled = it },
            colors = SwitchDefaults.colors(checkedThumbColor = VyaparGreen)
          )
        }

        Button(
          onClick = { viewModel.syncNow() },
          colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = if (isSyncing) "Syncing in progress..." else "🔄 Sync Now", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
      }
    }

    // 2. API Endpoints
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color.White,
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .background(Color(0xFFE0F2FE), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
          ) {
            Icon(imageVector = Icons.Default.Api, contentDescription = null, tint = VyaparBlue, modifier = Modifier.size(20.dp))
          }
          Column {
            Text(text = "API Integrations & Webhooks", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = "Secure cloud API and webhook event endpoints", fontSize = 10.sp, color = TextSecondary)
          }
        }

        OutlinedTextField(
          value = apiUrl,
          onValueChange = { apiUrl = it },
          label = { Text("REST API Sync Endpoint") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = webhookUrl,
          onValueChange = { webhookUrl = it },
          label = { Text("Sales Webhook URL (POST Event)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(
            onClick = { viewModel.showToast("API Endpoint test successful: HTTP 200 OK (Latency 42ms)") },
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            Text("⚡ Test Connection", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = {
              viewModel.saveBusinessProfile(
                profile.copy(
                  apiSyncUrl = apiUrl,
                  apiWebhookUrl = webhookUrl,
                  isRealtimeSyncEnabled = realtimeSyncEnabled
                )
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            Text("Save Endpoints", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // 2.5 App Language Selection Card
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color.White,
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
      modifier = Modifier.fillMaxWidth()
    ) {
      val curLang by viewModel.appLanguage.collectAsState()
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .background(Color(0xFFEFF6FF), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
          ) {
            Text("🌐", fontSize = 18.sp)
          }
          Column {
            Text(
              text = "App Language",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Text(
              text = "English is the default system language. Select your preference.",
              fontSize = 10.sp,
              color = TextSecondary
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // English Option
          val isEn = curLang == com.example.ui.util.AppLanguage.ENGLISH
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (isEn) Color(0xFFEFF6FF) else Color(0xFFF8FAFC))
              .border(if (isEn) 2.dp else 1.dp, if (isEn) VyaparBlue else Color(0xFFCBD5E1), RoundedCornerShape(10.dp))
              .clickable { viewModel.setAppLanguage(com.example.ui.util.AppLanguage.ENGLISH) }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "English (Default)",
              fontWeight = if (isEn) FontWeight.Bold else FontWeight.Medium,
              fontSize = 12.sp,
              color = if (isEn) VyaparBlue else Color(0xFF475569)
            )
          }

          // Hindi Option
          val isHi = curLang == com.example.ui.util.AppLanguage.HINDI
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (isHi) Color(0xFFFEF3C7) else Color(0xFFF8FAFC))
              .border(if (isHi) 2.dp else 1.dp, if (isHi) Color(0xFFF59E0B) else Color(0xFFCBD5E1), RoundedCornerShape(10.dp))
              .clickable { viewModel.setAppLanguage(com.example.ui.util.AppLanguage.HINDI) }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Hindi (Regional)",
              fontWeight = if (isHi) FontWeight.Bold else FontWeight.Medium,
              fontSize = 12.sp,
              color = if (isHi) Color(0xFFB45309) else Color(0xFF475569)
            )
          }
        }
      }
    }

    // 3. Backup & Export
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color.White,
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .background(Color(0xFFFEF3C7), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
          ) {
            Icon(imageVector = Icons.Default.Backup, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
          }
          Column {
            Text(text = "Data Backup & Export (JSON & CSV)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = "Secure local and cloud data export files", fontSize = 10.sp, color = TextSecondary)
          }
        }

        Button(
          onClick = { viewModel.exportDatabaseJson(context) },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(imageVector = Icons.Default.FileDownload, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "Download Full JSON Database Backup", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        Button(
          onClick = { viewModel.exportCsv(context) },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(imageVector = Icons.Default.FileDownload, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "Export Sales CSV / Excel Report", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // 4. Daily Limit & Admin PIN
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color.White,
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(text = "Daily Booking Limit & Security PIN", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = dailyLimitInput,
            onValueChange = { dailyLimitInput = it },
            label = { Text("Daily Booking Limit") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = adminPinInput,
            onValueChange = { if (it.length <= 4) adminPinInput = it },
            label = { Text("Admin PIN") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Button(
          onClick = {
            val lim = dailyLimitInput.toIntOrNull() ?: 3
            val pin = if (adminPinInput.length == 4) adminPinInput else "1234"
            viewModel.saveBusinessProfile(
              profile.copy(
                dailyBookingLimit = lim,
                adminPin = pin
              )
            )
            viewModel.showToast("Settings saved successfully!")
          },
          colors = ButtonDefaults.buttonColors(containerColor = SoePrimary),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(text = "Update Settings", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
