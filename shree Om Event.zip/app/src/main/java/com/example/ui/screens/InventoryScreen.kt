package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InventoryItemEntity
import com.example.data.model.ItemPriceHistoryEntity
import com.example.data.model.PurchaseEntity
import com.example.ui.MainViewModel
import com.example.ui.theme.SoePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VyaparAmber
import com.example.ui.theme.VyaparBlue
import com.example.ui.theme.VyaparDarkGreen
import com.example.ui.theme.VyaparGreen

enum class InventoryTab {
  STOCK_LIST,
  PURCHASE_HISTORY,
  PRICE_COMPARISON,
  VALUATION
}

@Composable
fun InventoryScreen(
  viewModel: MainViewModel,
  items: List<InventoryItemEntity>,
  purchases: List<PurchaseEntity> = emptyList(),
  priceHistory: List<ItemPriceHistoryEntity> = emptyList(),
  modifier: Modifier = Modifier
) {
  var activeInventoryTab by remember { mutableStateOf(InventoryTab.STOCK_LIST) }
  var stockStatusFilter by remember { mutableStateOf("ALL") } // ALL, AVAILABLE, LOW_STOCK, OUT_OF_STOCK
  var searchQuery by remember { mutableStateOf("") }

  // Filtered items
  val filteredItems = remember(items, stockStatusFilter, searchQuery) {
    items.filter { item ->
      val matchesStatus = when (stockStatusFilter) {
        "AVAILABLE" -> item.stock > item.minAlertStock
        "LOW_STOCK" -> item.stock in 1.0..item.minAlertStock
        "OUT_OF_STOCK" -> item.stock <= 0.0
        else -> true
      }
      val matchesSearch = item.name.contains(searchQuery, ignoreCase = true) ||
        item.sku.contains(searchQuery, ignoreCase = true) ||
        item.category.contains(searchQuery, ignoreCase = true) ||
        item.supplierName.contains(searchQuery, ignoreCase = true)
      matchesStatus && matchesSearch
    }
  }

  // Stock status counts
  val totalItemsCount = items.size
  val availableCount = items.count { it.stock > it.minAlertStock }
  val lowStockCount = items.count { it.stock in 1.0..it.minAlertStock }
  val outOfStockCount = items.count { it.stock <= 0.0 }

  // Valuation totals
  val totalStockQty = items.sumOf { it.stock }
  val totalPurchaseValuation = items.sumOf { it.stock * it.purchaseCost }
  val totalMarketValuation = items.sumOf { it.stock * it.currentMarketPrice }
  val lowStockValuation = items.filter { it.stock <= it.minAlertStock }.sumOf { it.stock * it.purchaseCost }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp, vertical = 8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // 1. Header Card with Add New Item Action
    item {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "Inventory & Stock Management",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Text(
                text = "Live Stock, Purchase Bills, Price Comparison & Valuation",
                fontSize = 11.sp,
                color = TextSecondary
              )
            }

            Button(
              onClick = { viewModel.openNewItemModal() },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4338CA)),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.testTag("add_item_top_button")
            ) {
              Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(text = "Add Item", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Sub-Tab Switcher
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            val tabs = listOf(
              InventoryTab.STOCK_LIST to "📦 Stock List (${items.size})",
              InventoryTab.PURCHASE_HISTORY to "🛒 Purchase Bills (${purchases.size})",
              InventoryTab.PRICE_COMPARISON to "📊 Price Comparison",
              InventoryTab.VALUATION to "💰 Stock Valuation"
            )

            tabs.forEach { (tab, label) ->
              val isSel = activeInventoryTab == tab
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSel) Color(0xFF4338CA).copy(alpha = 0.12f) else Color(0xFFF8FAFC))
                  .border(
                    width = if (isSel) 1.5.dp else 1.dp,
                    color = if (isSel) Color(0xFF4338CA) else Color(0xFFE2E8F0),
                    shape = RoundedCornerShape(10.dp)
                  )
                  .clickable { activeInventoryTab = tab }
                  .padding(horizontal = 12.dp, vertical = 7.dp)
              ) {
                Text(
                  text = label,
                  fontSize = 11.sp,
                  fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSel) Color(0xFF4338CA) else TextSecondary
                )
              }
            }
          }
        }
      }
    }

    // 2. Dynamic Content per Sub-Tab
    when (activeInventoryTab) {
      InventoryTab.STOCK_LIST -> {
        // Stock Status Tabs
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            val statusTabs = listOf(
              "ALL" to "All ($totalItemsCount)",
              "AVAILABLE" to "Available ($availableCount)",
              "LOW_STOCK" to "Low Stock ($lowStockCount)",
              "OUT_OF_STOCK" to "Out of Stock ($outOfStockCount)"
            )

            statusTabs.forEach { (code, label) ->
              val isSel = stockStatusFilter == code
              val bg = when (code) {
                "AVAILABLE" -> if (isSel) VyaparGreen else Color(0xFFDCFCE7)
                "LOW_STOCK" -> if (isSel) VyaparAmber else Color(0xFFFEF3C7)
                "OUT_OF_STOCK" -> if (isSel) SoePrimary else Color(0xFFFFE4E6)
                else -> if (isSel) Color(0xFF4338CA) else Color(0xFFEEF2FF)
              }

              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(bg)
                  .clickable { stockStatusFilter = code }
                  .padding(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Text(
                  text = label,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isSel) Color.White else TextPrimary
                )
              }
            }
          }
        }

        // Search Bar
        item {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search item name, SKU or supplier...", fontSize = 11.sp) },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }

        // Items list
        items(filteredItems, key = { it.id }) { item ->
          val isLowStock = item.stock in 1.0..item.minAlertStock
          val isOutOfStock = item.stock <= 0.0

          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { viewModel.openItemDetail(item) }
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
              ) {
                Box(
                  modifier = Modifier
                    .size(40.dp)
                    .background(
                      when {
                        isOutOfStock -> Color(0xFFFFE4E6)
                        isLowStock -> Color(0xFFFEF3C7)
                        else -> Color(0xFFEEF2FF)
                      },
                      RoundedCornerShape(10.dp)
                    ),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.Inventory2,
                    contentDescription = null,
                    tint = when {
                      isOutOfStock -> SoePrimary
                      isLowStock -> VyaparAmber
                      else -> Color(0xFF4338CA)
                    },
                    modifier = Modifier.size(20.dp)
                  )
                }

                Column {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = item.name,
                      fontSize = 13.sp,
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                      modifier = Modifier
                        .background(Color(0xFFEEF2FF), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                      Text(text = "SKU: ${item.sku}", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4338CA))
                    }
                  }
                  Text(
                    text = "Rate: ₹${item.rate} | Cost: ₹${item.purchaseCost} | Market: ₹${item.currentMarketPrice}",
                    fontSize = 10.sp,
                    color = TextSecondary
                  )
                  if (item.supplierName.isNotBlank()) {
                    Text(
                      text = "Supplier: ${item.supplierName}",
                      fontSize = 9.sp,
                      color = Color(0xFF64748B)
                    )
                  }
                  if (isOutOfStock) {
                    Text(text = "❌ Out of Stock!", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
                  } else if (isLowStock) {
                    Text(text = "⚠️ Low Stock Alert! (Min: ${item.minAlertStock})", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparAmber)
                  }
                }
              }

              // Stock Counter and Quick Adjust
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                IconButton(
                  onClick = {
                    val next = (item.stock - 1).coerceAtLeast(0.0)
                    viewModel.updateStock(item.id, next)
                  },
                  modifier = Modifier
                    .size(28.dp)
                    .background(Color(0xFFF1F5F9), CircleShape)
                ) {
                  Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrement", modifier = Modifier.size(14.dp))
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Text(
                    text = "${item.stock}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = when {
                      isOutOfStock -> SoePrimary
                      isLowStock -> VyaparAmber
                      else -> Color(0xFF4338CA)
                    }
                  )
                  Text(
                    text = item.unit,
                    fontSize = 10.sp,
                    color = TextSecondary
                  )
                }

                IconButton(
                  onClick = {
                    viewModel.updateStock(item.id, item.stock + 1)
                  },
                  modifier = Modifier
                    .size(28.dp)
                    .background(Color(0xFFF1F5F9), CircleShape)
                ) {
                  Icon(imageVector = Icons.Default.Add, contentDescription = "Increment", modifier = Modifier.size(14.dp))
                }
              }
            }
          }
        }
      }

      InventoryTab.PURCHASE_HISTORY -> {
        // Purchase History List
        item {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFFFEF3C7),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = "Total Purchase Bills", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                Text(text = "${purchases.size} Bills Recorded", fontSize = 10.sp, color = Color(0xFFB45309))
              }
              Text(
                text = "₹ ${String.format("%,.2f", purchases.sumOf { it.totalAmount })}",
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFFB45309)
              )
            }
          }
        }

        if (purchases.isEmpty()) {
          item {
            Text(text = "No purchase bills recorded.", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.padding(vertical = 12.dp))
          }
        } else {
          items(purchases) { pur ->
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color.White,
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.openPurchaseDetail(pur) }
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = pur.vendorName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                  Text(text = "${pur.itemName} • ${pur.quantity} ${pur.unit} @ ₹${pur.rate}", fontSize = 10.sp, color = TextSecondary)
                  Text(text = "Bill #${pur.billNumber} • ${pur.formattedDate}", fontSize = 9.sp, color = Color(0xFF64748B))
                }
                Column(horizontalAlignment = Alignment.End) {
                  Text(text = "₹${String.format("%,.0f", pur.totalAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFFB45309))
                  Text(text = if (pur.dueAmount > 0) "Due: ₹${pur.dueAmount}" else "Paid in Full", fontSize = 9.sp, color = if (pur.dueAmount > 0) SoePrimary else VyaparGreen)
                }
              }
            }
          }
        }
      }

      InventoryTab.PRICE_COMPARISON -> {
        // Price History & Comparison Tab
        item {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFFEEF2FF),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = "📊 Item Purchase Rate Comparison & History",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF4338CA)
              )
              Text(
                text = "Comparative analytics between previous and latest purchase costs. Tap any item to view complete price change history.",
                fontSize = 10.sp,
                color = TextSecondary,
                lineHeight = 14.sp,
                modifier = Modifier.padding(top = 2.dp)
              )
            }
          }
        }

        items(items) { item ->
          val prevPrice = if (item.previousPurchasePrice > 0) item.previousPurchasePrice else item.purchaseCost
          val currPrice = item.purchaseCost
          val diff = currPrice - prevPrice
          val percentDiff = if (prevPrice > 0) ((diff / prevPrice) * 100).toInt() else 0

          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { viewModel.openPriceHistoryModal(item) }
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(text = item.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = "Supplier: ${item.supplierName.ifBlank { "Standard Vendor" }} • SKU: ${item.sku}", fontSize = 10.sp, color = TextSecondary)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 2.dp)) {
                  Text(text = "Prev Cost: ₹$prevPrice", fontSize = 10.sp, color = Color(0xFF64748B))
                  Text(text = "➔", fontSize = 10.sp, color = Color(0xFF94A3B8))
                  Text(text = "Latest Cost: ₹$currPrice", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
              }

              Column(horizontalAlignment = Alignment.End) {
                if (diff > 0) {
                  Box(
                    modifier = Modifier
                      .background(Color(0xFFFFE4E6), RoundedCornerShape(6.dp))
                      .padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Text(text = "+₹$diff (+$percentDiff%) ▲", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
                  }
                } else if (diff < 0) {
                  Box(
                    modifier = Modifier
                      .background(Color(0xFFDCFCE7), RoundedCornerShape(6.dp))
                      .padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Text(text = "₹$diff ($percentDiff%) ▼", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
                  }
                } else {
                  Box(
                    modifier = Modifier
                      .background(Color(0xFFF1F5F9), RoundedCornerShape(6.dp))
                      .padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Text(text = "Rate Constant (=)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                  }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "Compare >", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4338CA))
              }
            }
          }
        }
      }

      InventoryTab.VALUATION -> {
        // Inventory Valuation Summary
        item {
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text(
                text = "💰 Inventory Valuation",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )

              // Metrics 2x2
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(color = Color(0xFFEFF6FF), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
                  Column(modifier = Modifier.padding(10.dp)) {
                    Text(text = "Total Stock Qty", fontSize = 10.sp, color = VyaparBlue)
                    Text(text = "$totalStockQty Units", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
                    Text(text = "${items.size} Total Items", fontSize = 8.sp, color = TextSecondary)
                  }
                }

                Surface(color = Color(0xFFEEF2FF), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
                  Column(modifier = Modifier.padding(10.dp)) {
                    Text(text = "Purchase Cost Valuation", fontSize = 10.sp, color = Color(0xFF4338CA))
                    Text(text = "₹ ${String.format("%,.0f", totalPurchaseValuation)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4338CA))
                    Text(text = "Qty × Purchase Cost", fontSize = 8.sp, color = TextSecondary)
                  }
                }
              }

              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(color = Color(0xFFDCFCE7), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
                  Column(modifier = Modifier.padding(10.dp)) {
                    Text(text = "Market Rate Valuation", fontSize = 10.sp, color = Color(0xFF166534))
                    Text(text = "₹ ${String.format("%,.0f", totalMarketValuation)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
                    Text(text = "Qty × Market Rate", fontSize = 8.sp, color = TextSecondary)
                  }
                }

                Surface(color = Color(0xFFFFE4E6), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
                  Column(modifier = Modifier.padding(10.dp)) {
                    Text(text = "Low Stock Tied Value", fontSize = 10.sp, color = SoePrimary)
                    Text(text = "₹ ${String.format("%,.0f", lowStockValuation)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
                    Text(text = "$lowStockCount Items Low Stock", fontSize = 8.sp, color = TextSecondary)
                  }
                }
              }

              Text(text = "Item-Wise Valuation Breakdown:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

              Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items.forEach { itm ->
                  val purchaseVal = itm.stock * itm.purchaseCost
                  val marketVal = itm.stock * itm.currentMarketPrice

                  Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF8FAFC),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Row(
                      modifier = Modifier.padding(10.dp),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Column(modifier = Modifier.weight(1f)) {
                        Text(text = itm.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(text = "${itm.stock} ${itm.unit} Available • Cost: ₹${itm.purchaseCost} | Market: ₹${itm.currentMarketPrice}", fontSize = 10.sp, color = TextSecondary)
                      }
                      Column(horizontalAlignment = Alignment.End) {
                        Text(text = "₹ ${String.format("%,.0f", purchaseVal)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4338CA))
                        Text(text = "Market: ₹${String.format("%,.0f", marketVal)}", fontSize = 9.sp, color = VyaparGreen)
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(60.dp))
    }
  }
}
