package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BookingEntity
import com.example.data.model.NotificationEntity
import com.example.ui.MainViewModel
import com.example.ui.PartySummary
import com.example.ui.theme.SoePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VyaparAmber
import com.example.ui.theme.VyaparBlue
import com.example.ui.theme.VyaparGreen

@Composable
fun AlertsScreen(
  viewModel: MainViewModel,
  bookings: List<BookingEntity>,
  notifications: List<NotificationEntity>,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  // Top Debtors list ordered by highest balance due
  val debtors = remember(bookings) {
    bookings.filter { it.balanceDue > 0 }.sortedByDescending { it.balanceDue }
  }

  // Booking calendar state
  val datesWithBookings = remember(bookings) {
    bookings.map { it.eventDate }.distinct()
  }
  var selectedDate by remember { mutableStateOf<String>(datesWithBookings.firstOrNull() ?: "2026-07-17") }
  val bookingsOnSelectedDate = remember(bookings, selectedDate) {
    bookings.filter { it.eventDate == selectedDate && it.status != "CANCELLED" }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp, vertical = 8.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 0. BOOKING CALENDAR SECTION
    item {
      Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(
                imageVector = Icons.Default.EventBusy,
                contentDescription = null,
                tint = VyaparBlue,
                modifier = Modifier.size(20.dp)
              )
              Text(
                text = "Event Booking Calendar",
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
              )
            }
            Text(
              text = "Change Limit",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = VyaparBlue,
              modifier = Modifier
                .clickable { viewModel.openDailyLimitDialog() }
                .padding(4.dp)
            )
          }

          Text(
            text = "Select a date to view event bookings and slot capacity status.",
            fontSize = 11.sp,
            color = TextSecondary,
            modifier = Modifier.padding(top = 2.dp)
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Date Chips Row
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            val sampleDates = listOf("2026-07-17", "2026-11-10", "2026-11-20", "2026-11-25", "2026-12-05")
            val allDisplayDates = (datesWithBookings + sampleDates).distinct()

            allDisplayDates.forEach { d ->
              val isSelected = selectedDate == d
              val countOnDate = bookings.count { it.eventDate == d && it.status != "CANCELLED" }
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSelected) VyaparBlue else Color(0xFFF1F5F9))
                  .clickable { selectedDate = d }
                  .padding(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Text(
                    text = d,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else TextPrimary
                  )
                  Text(
                    text = if (countOnDate > 0) "$countOnDate Bookings" else "Available",
                    fontSize = 9.sp,
                    color = if (isSelected) Color(0xFFE0F2FE) else TextSecondary
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Calendar slot status on selected date
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (bookingsOnSelectedDate.size >= 3) Color(0xFFFFF1F2) else Color(0xFFF0FDF4),
            border = androidx.compose.foundation.BorderStroke(
              1.dp,
              if (bookingsOnSelectedDate.size >= 3) Color(0xFFFECDD3) else Color(0xFFBBF7D0)
            ),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "Date: $selectedDate",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
                Text(
                  text = "Booked: ${bookingsOnSelectedDate.size} Events (Daily Limit: 3)",
                  fontSize = 10.sp,
                  color = TextSecondary
                )
              }
              Box(
                modifier = Modifier
                  .background(
                    if (bookingsOnSelectedDate.size >= 3) SoePrimary else VyaparGreen,
                    RoundedCornerShape(6.dp)
                  )
                  .padding(horizontal = 8.dp, vertical = 3.dp)
              ) {
                Text(
                  text = if (bookingsOnSelectedDate.size >= 3) "HOUSEFULL (FULL)" else "SLOTS AVAILABLE",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              }
            }
          }

          if (bookingsOnSelectedDate.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              bookingsOnSelectedDate.forEach { b ->
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = Color(0xFFF8FAFC),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.openInvoicePreview(b) }
                ) {
                  Row(
                    modifier = Modifier.padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        text = "${b.salutation} ${b.customerName}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                      )
                      Text(
                        text = "📍 ${b.eventVenueAddress}",
                        fontSize = 10.sp,
                        color = TextSecondary
                      )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text(
                        text = "₹${String.format("%,.0f", b.totalAmount)}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VyaparGreen
                      )
                      Spacer(modifier = Modifier.width(6.dp))
                      Text(
                        text = "Details >",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = VyaparBlue
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // 1. Top Debtors Section
    item {
      Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Warning,
              contentDescription = null,
              tint = SoePrimary,
              modifier = Modifier.size(18.dp)
            )
            Text(
              text = "Top Pending Receivables (Debtors)",
              fontSize = 14.sp,
              fontWeight = FontWeight.ExtraBold,
              color = TextPrimary
            )
          }

          Text(
            text = "Send instant WhatsApp balance reminder with 1-click.",
            fontSize = 11.sp,
            color = TextSecondary,
            modifier = Modifier.padding(top = 2.dp)
          )

          Spacer(modifier = Modifier.height(10.dp))

          if (debtors.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFDCFCE7), RoundedCornerShape(10.dp))
                .padding(12.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "All balances cleared! No pending debtors.",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = VyaparGreen
              )
            }
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              debtors.forEachIndexed { idx, debtor ->
                Surface(
                  shape = RoundedCornerShape(12.dp),
                  color = Color(0xFFFFF1F2),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECDD3)),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      val summary = PartySummary(
                        name = debtor.customerName,
                        salutation = debtor.salutation,
                        phone = debtor.customerPhone,
                        address = debtor.eventVenueAddress,
                        totalBookings = bookings.count { it.customerPhone == debtor.customerPhone },
                        totalDue = bookings.filter { it.customerPhone == debtor.customerPhone }.sumOf { it.balanceDue },
                        totalBilled = bookings.filter { it.customerPhone == debtor.customerPhone }.sumOf { it.totalAmount }
                      )
                      viewModel.openPartyDetail(summary)
                    }
                ) {
                  Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                          modifier = Modifier
                            .size(18.dp)
                            .background(SoePrimary, CircleShape),
                          contentAlignment = Alignment.Center
                        ) {
                          Text(
                            text = "${idx + 1}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                          )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          text = "${debtor.salutation} ${debtor.customerName}",
                          fontSize = 13.sp,
                          fontWeight = FontWeight.ExtraBold,
                          color = TextPrimary
                        )
                      }
                      Text(
                        text = "Event Date: ${debtor.formattedDate} • Billed: ₹${debtor.totalAmount} • View Ledger >",
                        fontSize = 10.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(start = 24.dp, top = 2.dp)
                      )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                      Text(
                        text = "₹ ${String.format("%,.2f", debtor.balanceDue)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = SoePrimary
                      )

                      Spacer(modifier = Modifier.height(4.dp))

                      Button(
                        onClick = { viewModel.sendReminderWhatsApp(context, debtor) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("send_whatsapp_reminder_btn_${debtor.id}")
                      ) {
                        Icon(
                          imageVector = Icons.Default.Message,
                          contentDescription = null,
                          tint = Color.White,
                          modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Reminder", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // 2. Notification Center
    item {
      Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(
                imageVector = Icons.Default.NotificationsActive,
                contentDescription = null,
                tint = VyaparBlue,
                modifier = Modifier.size(18.dp)
              )
              Text(
                text = "System Notifications & Alerts",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(
                text = "Mark All Read",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = VyaparBlue,
                modifier = Modifier
                  .clickable { viewModel.markNotificationsAsRead() }
                  .padding(4.dp)
              )
              Text(
                text = "Clear All",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = SoePrimary,
                modifier = Modifier
                  .clickable { viewModel.clearAllNotifications() }
                  .padding(4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          if (notifications.isEmpty()) {
            Text(
              text = "No new notifications.",
              fontSize = 11.sp,
              color = TextSecondary,
              modifier = Modifier.padding(vertical = 10.dp)
            )
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              notifications.forEach { notif ->
                val notifColor = when (notif.type) {
                  "LOW_STOCK" -> SoePrimary
                  "CAPACITY_WARNING" -> VyaparAmber
                  "SYNC" -> VyaparGreen
                  else -> VyaparBlue
                }

                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = if (notif.isRead) Color(0xFFF8FAFC) else notifColor.copy(alpha = 0.08f),
                  border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (notif.isRead) Color(0xFFE2E8F0) else notifColor.copy(alpha = 0.3f)
                  ),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.Top
                  ) {
                    Box(
                      modifier = Modifier
                        .size(24.dp)
                        .background(notifColor.copy(alpha = 0.15f), CircleShape),
                      contentAlignment = Alignment.Center
                    ) {
                      Icon(
                        imageVector = when (notif.type) {
                          "SYNC" -> Icons.Default.CloudDone
                          "CAPACITY_WARNING" -> Icons.Default.EventBusy
                          else -> Icons.Default.Warning
                        },
                        contentDescription = null,
                        tint = notifColor,
                        modifier = Modifier.size(14.dp)
                      )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        text = notif.title,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                      )
                      Text(
                        text = notif.message,
                        fontSize = 10.sp,
                        color = TextSecondary,
                        lineHeight = 14.sp
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(60.dp))
    }
  }
}
