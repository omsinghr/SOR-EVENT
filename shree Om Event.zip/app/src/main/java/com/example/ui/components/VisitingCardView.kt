package com.example.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BusinessProfileEntity
import com.example.ui.theme.SoePrimary
import com.example.ui.theme.SoePrimaryDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VyaparAmber
import com.example.ui.theme.VyaparBlue
import com.example.ui.theme.VyaparGreen

@Composable
fun VisitingCardView(
  profile: BusinessProfileEntity,
  onShareClick: () -> Unit,
  onThemeSelectClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  // Theme colors
  val cardBg: Color
  val cardBorder: Color
  val primaryAccent: Color
  val textCol: Color
  val isDark = profile.cardTheme == "dark-gold"

  when (profile.cardTheme) {
    "royal-blue" -> {
      cardBg = Color(0xFFF0F7FF)
      cardBorder = Color(0xFFBFDBFE)
      primaryAccent = Color(0xFF1D4ED8)
      textCol = Color(0xFF1E293B)
    }
    "emerald-green" -> {
      cardBg = Color(0xFFF0FDF4)
      cardBorder = Color(0xFFBBF7D0)
      primaryAccent = Color(0xFF15803D)
      textCol = Color(0xFF1E293B)
    }
    "dark-gold" -> {
      cardBg = Color(0xFF0F172A)
      cardBorder = Color(0xFFD97706).copy(alpha = 0.5f)
      primaryAccent = Color(0xFFF59E0B)
      textCol = Color(0xFFF8FAFC)
    }
    else -> { // classic-red
      cardBg = Color.White
      cardBorder = Color(0xFFE2E8F0)
      primaryAccent = SoePrimary
      textCol = Color(0xFF1E293B)
    }
  }

  // Profile completion calculation
  val fields = listOf(
    profile.businessName.isNotBlank(),
    profile.phone1.isNotBlank(),
    profile.email.isNotBlank(),
    profile.address.isNotBlank(),
    profile.pincode.isNotBlank(),
    profile.gstin.isNotBlank(),
    profile.state.isNotBlank(),
    profile.category.isNotBlank()
  )
  val completion = (fields.count { it }.toFloat() / fields.size) * 100

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(
        brush = Brush.verticalGradient(listOf(Color(0xFFE0F2FE).copy(alpha = 0.4f), Color.White))
      )
      .padding(horizontal = 14.dp, vertical = 10.dp)
  ) {
    // Top Bar with Theme Selector button
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(16.dp)
            .background(SoePrimary, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Star,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(10.dp)
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Live Visiting Card Preview",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = TextSecondary
        )
      }

      Surface(
        onClick = onThemeSelectClick,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
        color = Color.White,
        modifier = Modifier.testTag("theme_selector_button")
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = "🎨 Themes",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Card Body Container with Floating Share Button
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 18.dp)
    ) {
      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .animateContentSize(),
        shape = RoundedCornerShape(20.dp),
        color = cardBg,
        border = androidx.compose.foundation.BorderStroke(1.5.dp, cardBorder),
        shadowElevation = 6.dp
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          // Card Top Row: Business Name & Crown Logo
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = profile.businessName.ifBlank { "SHREE OM EVENT UMARIA" },
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = primaryAccent,
                letterSpacing = (-0.3).sp,
                lineHeight = 20.sp
              )
              if (profile.showBusinessType) {
                Text(
                  text = "${profile.businessType} • ${profile.category}",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = if (isDark) Color(0xFF94A3B8) else TextSecondary,
                  modifier = Modifier.padding(top = 2.dp)
                )
              }
              if (profile.showGstin && profile.gstin.isNotBlank()) {
                Box(
                  modifier = Modifier
                    .padding(top = 4.dp)
                    .background(
                      if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9),
                      RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = "GSTIN: ${profile.gstin}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color(0xFFE2E8F0) else TextPrimary
                  )
                }
              }
            }

            Box(
              modifier = Modifier
                .size(38.dp)
                .background(primaryAccent.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                .border(1.dp, primaryAccent.copy(alpha = 0.3f), RoundedCornerShape(10.dp)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                tint = primaryAccent,
                modifier = Modifier.size(20.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Card Details with Accent Line
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .border(
                width = 0.dp,
                color = Color.Transparent
              )
          ) {
            Box(
              modifier = Modifier
                .width(3.dp)
                .height(72.dp)
                .background(primaryAccent, RoundedCornerShape(2.dp))
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(
              verticalArrangement = Arrangement.spacedBy(4.dp),
              modifier = Modifier.weight(1f)
            ) {
              if (profile.showPhone1 && profile.phone1.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.Phone,
                    contentDescription = null,
                    tint = primaryAccent,
                    modifier = Modifier.size(13.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "${profile.phone1} ${if (profile.phone2.isNotBlank()) "/ " + profile.phone2 else ""}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = textCol
                  )
                }
              }

              if (profile.email.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.Email,
                    contentDescription = null,
                    tint = primaryAccent,
                    modifier = Modifier.size(13.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = profile.email,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    color = textCol
                  )
                }
              }

              if (profile.address.isNotBlank()) {
                Row(verticalAlignment = Alignment.Top) {
                  Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = primaryAccent,
                    modifier = Modifier.size(13.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "${profile.address} (PIN: ${profile.pincode})",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Normal,
                    color = if (isDark) Color(0xFFCBD5E1) else TextSecondary,
                    lineHeight = 13.sp
                  )
                }
              }
            }
          }

          // Signature watermark row
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = "Shree Om Event",
                fontFamily = FontFamily.Cursive,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = primaryAccent
              )
              Text(
                text = "Authorized Signatory",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = if (isDark) Color(0xFF94A3B8) else Color(0xFF94A3B8)
              )
            }
          }
        }
      }

      // Floating "Share Card" Button (matches reference HTML)
      Button(
        onClick = onShareClick,
        colors = ButtonDefaults.buttonColors(containerColor = primaryAccent),
        shape = RoundedCornerShape(24.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .offset(y = 16.dp)
          .testTag("share_visiting_card_button")
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = "Share",
            tint = Color.White,
            modifier = Modifier.size(14.dp)
          )
          Text(
            text = "Share Card",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Tip Box
    Surface(
      shape = RoundedCornerShape(12.dp),
      color = Color(0xFFFFFBEB),
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .size(24.dp)
            .background(Color(0xFFFEF3C7), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Lightbulb,
            contentDescription = null,
            tint = Color(0xFFD97706),
            modifier = Modifier.size(14.dp)
          )
        }
        Text(
          text = "67% of event planners get more bookings after sharing their digital business card.",
          fontSize = 11.sp,
          color = Color(0xFF92400E),
          lineHeight = 15.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Profile Completion Tracker
    Column(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "Profile ${completion.toInt()}% complete",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Text(
          text = "${completion.toInt()}%",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = SoePrimary
        )
      }
      Spacer(modifier = Modifier.height(4.dp))
      LinearProgressIndicator(
        progress = { completion / 100f },
        modifier = Modifier
          .fillMaxWidth()
          .height(7.dp)
          .clip(RoundedCornerShape(4.dp)),
        color = VyaparBlue,
        trackColor = Color(0xFFE2E8F0)
      )
    }
  }
}
