package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.BookingEntity
import com.example.data.model.BookingItem
import com.example.data.model.BusinessProfileEntity
import com.example.data.model.CustomerPaymentEntity
import com.example.data.model.EmployeeAttendanceEntity
import com.example.data.model.EmployeeEntity
import com.example.data.model.EmployeePaymentEntity
import com.example.data.model.ItemPriceHistoryEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.InventoryItemEntity
import com.example.data.model.JsonHelper
import com.example.data.model.NotificationEntity
import com.example.data.model.OrderEntity
import com.example.data.model.PurchaseEntity
import com.example.data.repository.EventRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.net.URLEncoder

enum class AppTab {
  HOME,
  DASHBOARD,
  ITEMS,
  ALERTS,
  PROFILE,
  ADMIN
}

enum class HomeSubTab {
  TRANSACTIONS,
  PARTY
}

enum class DatePreset {
  TODAY,
  YESTERDAY,
  THIS_WEEK,
  THIS_MONTH,
  LAST_MONTH,
  THIS_YEAR,
  FY,
  CUSTOM
}

enum class AdminSection {
  BOOKINGS,
  ADVANCE,
  COMPLETED,
  COLLECTION,
  PROFIT_ANALYSIS,
  EMPLOYEES,
  SETTINGS
}

enum class ReportCategoryTab {
  OVERVIEW,
  DAY_BOOK,
  ALL_TXN,
  BILL_PROFIT,
  PNL,
  CASHFLOW,
  BALANCE_SHEET,
  TRIAL_BALANCE,
  PARTY_REPORTS,
  STOCK_REPORTS,
  EXPENSE_REPORTS,
  PURCHASE_REPORTS,
  PAYMENT_HISTORY,
  ORDERS_REPORT
}

data class PartySummary(
  val name: String,
  val salutation: String,
  val phone: String,
  val address: String,
  val totalBookings: Int,
  val totalDue: Double,
  val totalBilled: Double
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val database = AppDatabase.getDatabase(application)
  private val repository = EventRepository(
    bookingDao = database.bookingDao(),
    inventoryDao = database.inventoryDao(),
    profileDao = database.businessProfileDao(),
    notificationDao = database.notificationDao(),
    purchaseDao = database.purchaseDao(),
    expenseDao = database.expenseDao(),
    paymentDao = database.customerPaymentDao(),
    orderDao = database.orderDao(),
    itemPriceHistoryDao = database.itemPriceHistoryDao(),
    employeeDao = database.employeeDao(),
    employeeAttendanceDao = database.employeeAttendanceDao(),
    employeePaymentDao = database.employeePaymentDao()
  )

  // Data streams
  val allBookings: StateFlow<List<BookingEntity>> = repository.allBookings
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allItems: StateFlow<List<InventoryItemEntity>> = repository.allInventoryItems
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val businessProfile: StateFlow<BusinessProfileEntity> = repository.businessProfile
    .combine(MutableStateFlow(BusinessProfileEntity())) { p, defaultVal -> p ?: defaultVal }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BusinessProfileEntity())

  val notifications: StateFlow<List<NotificationEntity>> = repository.notifications
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val unreadNotificationsCount: StateFlow<Int> = repository.unreadNotificationCount
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

  val allPurchases: StateFlow<List<PurchaseEntity>> = repository.allPurchases
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allExpenses: StateFlow<List<ExpenseEntity>> = repository.allExpenses
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allPayments: StateFlow<List<CustomerPaymentEntity>> = repository.allPayments
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allOrders: StateFlow<List<OrderEntity>> = repository.allOrders
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allPriceHistory: StateFlow<List<ItemPriceHistoryEntity>> = repository.allPriceHistory
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allEmployees: StateFlow<List<EmployeeEntity>> = repository.allEmployees
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allAttendance: StateFlow<List<EmployeeAttendanceEntity>> = repository.allAttendance
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allEmployeePayments: StateFlow<List<EmployeePaymentEntity>> = repository.allEmployeePayments
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // UI state
  private val _activeTab = MutableStateFlow(AppTab.HOME)
  val activeTab: StateFlow<AppTab> = _activeTab.asStateFlow()

  private val _homeSubTab = MutableStateFlow(HomeSubTab.TRANSACTIONS)
  val homeSubTab: StateFlow<HomeSubTab> = _homeSubTab.asStateFlow()

  private val _statusFilter = MutableStateFlow("ALL") // "ALL", "DUE", "PAID"
  val statusFilter: StateFlow<String> = _statusFilter.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _selectedCalendarDate = MutableStateFlow("2026-07-17")
  val selectedCalendarDate: StateFlow<String> = _selectedCalendarDate.asStateFlow()

  private val _datePreset = MutableStateFlow(DatePreset.THIS_MONTH)
  val datePreset: StateFlow<DatePreset> = _datePreset.asStateFlow()

  private val _reportCategoryTab = MutableStateFlow(ReportCategoryTab.OVERVIEW)
  val reportCategoryTab: StateFlow<ReportCategoryTab> = _reportCategoryTab.asStateFlow()

  private val _reportsPaymentFilter = MutableStateFlow("ALL")
  val reportsPaymentFilter: StateFlow<String> = _reportsPaymentFilter.asStateFlow()

  private val _reportsSearchQuery = MutableStateFlow("")
  val reportsSearchQuery: StateFlow<String> = _reportsSearchQuery.asStateFlow()

  // Modal dialog states
  private val _showNewBookingModal = MutableStateFlow(false)
  val showNewBookingModal: StateFlow<Boolean> = _showNewBookingModal.asStateFlow()

  private val _showNewItemModal = MutableStateFlow(false)
  val showNewItemModal: StateFlow<Boolean> = _showNewItemModal.asStateFlow()

  private val _showInvoicePreviewModal = MutableStateFlow(false)
  val showInvoicePreviewModal: StateFlow<Boolean> = _showInvoicePreviewModal.asStateFlow()

  private val _selectedBookingForInvoice = MutableStateFlow<BookingEntity?>(null)
  val selectedBookingForInvoice: StateFlow<BookingEntity?> = _selectedBookingForInvoice.asStateFlow()

  private val _showDailyLimitDialog = MutableStateFlow(false)
  val showDailyLimitDialog: StateFlow<Boolean> = _showDailyLimitDialog.asStateFlow()

  private val _showAdminPinDialog = MutableStateFlow(false)
  val showAdminPinDialog: StateFlow<Boolean> = _showAdminPinDialog.asStateFlow()

  private val _isAdminUnlocked = MutableStateFlow(false)
  val isAdminUnlocked: StateFlow<Boolean> = _isAdminUnlocked.asStateFlow()

  private val _isSyncing = MutableStateFlow(false)
  val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

  private val _showAddExpenseDialog = MutableStateFlow(false)
  val showAddExpenseDialog: StateFlow<Boolean> = _showAddExpenseDialog.asStateFlow()

  private val _showAddPurchaseDialog = MutableStateFlow(false)
  val showAddPurchaseDialog: StateFlow<Boolean> = _showAddPurchaseDialog.asStateFlow()

  private val _showRecordPaymentDialog = MutableStateFlow(false)
  val showRecordPaymentDialog: StateFlow<Boolean> = _showRecordPaymentDialog.asStateFlow()

  private val _showAddOrderDialog = MutableStateFlow(false)
  val showAddOrderDialog: StateFlow<Boolean> = _showAddOrderDialog.asStateFlow()

  // Full item and transaction detail dialogs
  private val _selectedPartyForDetail = MutableStateFlow<PartySummary?>(null)
  val selectedPartyForDetail: StateFlow<PartySummary?> = _selectedPartyForDetail.asStateFlow()
  private val _showPartyDetailDialog = MutableStateFlow(false)
  val showPartyDetailDialog: StateFlow<Boolean> = _showPartyDetailDialog.asStateFlow()

  private val _selectedItemForDetail = MutableStateFlow<InventoryItemEntity?>(null)
  val selectedItemForDetail: StateFlow<InventoryItemEntity?> = _selectedItemForDetail.asStateFlow()
  private val _showItemDetailDialog = MutableStateFlow(false)
  val showItemDetailDialog: StateFlow<Boolean> = _showItemDetailDialog.asStateFlow()

  private val _selectedPurchaseForDetail = MutableStateFlow<PurchaseEntity?>(null)
  val selectedPurchaseForDetail: StateFlow<PurchaseEntity?> = _selectedPurchaseForDetail.asStateFlow()
  private val _showPurchaseDetailDialog = MutableStateFlow(false)
  val showPurchaseDetailDialog: StateFlow<Boolean> = _showPurchaseDetailDialog.asStateFlow()

  private val _selectedExpenseForDetail = MutableStateFlow<ExpenseEntity?>(null)
  val selectedExpenseForDetail: StateFlow<ExpenseEntity?> = _selectedExpenseForDetail.asStateFlow()
  private val _showExpenseDetailDialog = MutableStateFlow(false)
  val showExpenseDetailDialog: StateFlow<Boolean> = _showExpenseDetailDialog.asStateFlow()

  private val _selectedPaymentForDetail = MutableStateFlow<CustomerPaymentEntity?>(null)
  val selectedPaymentForDetail: StateFlow<CustomerPaymentEntity?> = _selectedPaymentForDetail.asStateFlow()
  private val _showPaymentReceiptDialog = MutableStateFlow(false)
  val showPaymentReceiptDialog: StateFlow<Boolean> = _showPaymentReceiptDialog.asStateFlow()

  private val _selectedOrderForDetail = MutableStateFlow<OrderEntity?>(null)
  val selectedOrderForDetail: StateFlow<OrderEntity?> = _selectedOrderForDetail.asStateFlow()
  private val _showOrderDetailDialog = MutableStateFlow(false)
  val showOrderDetailDialog: StateFlow<Boolean> = _showOrderDetailDialog.asStateFlow()

  private val _toastMessage = MutableStateFlow<String?>(null)
  val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

  // App Language: Default ENGLISH, can be switched to HINDI
  private val _appLanguage = MutableStateFlow(com.example.ui.util.AppLanguage.ENGLISH)
  val appLanguage: StateFlow<com.example.ui.util.AppLanguage> = _appLanguage.asStateFlow()

  fun setAppLanguage(language: com.example.ui.util.AppLanguage) {
    _appLanguage.value = language
    val msg = if (language == com.example.ui.util.AppLanguage.HINDI) "Language switched to Hindi" else "Language switched to English"
    showToast(msg)
  }

  fun toggleAppLanguage() {
    val next = if (_appLanguage.value == com.example.ui.util.AppLanguage.ENGLISH) com.example.ui.util.AppLanguage.HINDI else com.example.ui.util.AppLanguage.ENGLISH
    setAppLanguage(next)
  }

  fun shareInvoicePdf(context: Context, booking: BookingEntity) {
    com.example.util.PdfInvoiceGenerator.shareInvoicePdf(context, booking, businessProfile.value)
  }

  fun openOrDownloadInvoicePdf(context: Context, booking: BookingEntity) {
    com.example.util.PdfInvoiceGenerator.openOrDownloadInvoicePdf(context, booking, businessProfile.value)
  }

  // Dashboard Advanced Filter State
  private val _dashboardDatePreset = MutableStateFlow(DatePreset.THIS_MONTH)
  val dashboardDatePreset: StateFlow<DatePreset> = _dashboardDatePreset.asStateFlow()

  private val _dashboardFromDate = MutableStateFlow("")
  val dashboardFromDate: StateFlow<String> = _dashboardFromDate.asStateFlow()

  private val _dashboardToDate = MutableStateFlow("")
  val dashboardToDate: StateFlow<String> = _dashboardToDate.asStateFlow()

  private val _dashboardBookingStatus = MutableStateFlow("ALL")
  val dashboardBookingStatus: StateFlow<String> = _dashboardBookingStatus.asStateFlow()

  private val _dashboardPaymentStatus = MutableStateFlow("ALL")
  val dashboardPaymentStatus: StateFlow<String> = _dashboardPaymentStatus.asStateFlow()

  private val _dashboardCustomerQuery = MutableStateFlow("")
  val dashboardCustomerQuery: StateFlow<String> = _dashboardCustomerQuery.asStateFlow()

  private val _dashboardBookingIdQuery = MutableStateFlow("")
  val dashboardBookingIdQuery: StateFlow<String> = _dashboardBookingIdQuery.asStateFlow()

  private val _dashboardEventDateQuery = MutableStateFlow("")
  val dashboardEventDateQuery: StateFlow<String> = _dashboardEventDateQuery.asStateFlow()

  private val _dashboardPaymentTypeFilter = MutableStateFlow("ALL")
  val dashboardPaymentTypeFilter: StateFlow<String> = _dashboardPaymentTypeFilter.asStateFlow()

  private val _isDashboardFilterExpanded = MutableStateFlow(false)
  val isDashboardFilterExpanded: StateFlow<Boolean> = _isDashboardFilterExpanded.asStateFlow()

  fun setDashboardDatePreset(preset: DatePreset) {
    _dashboardDatePreset.value = preset
    _datePreset.value = preset
  }

  fun setDashboardFilterParams(
    preset: DatePreset,
    fromDate: String,
    toDate: String,
    bStatus: String,
    pStatus: String,
    custQuery: String,
    bIdQuery: String,
    eventDate: String,
    payType: String
  ) {
    _dashboardDatePreset.value = preset
    _datePreset.value = preset
    _dashboardFromDate.value = fromDate
    _dashboardToDate.value = toDate
    _dashboardBookingStatus.value = bStatus
    _dashboardPaymentStatus.value = pStatus
    _dashboardCustomerQuery.value = custQuery
    _dashboardBookingIdQuery.value = bIdQuery
    _dashboardEventDateQuery.value = eventDate
    _dashboardPaymentTypeFilter.value = payType
    _reportsPaymentFilter.value = payType
  }

  fun resetDashboardFilters() {
    _dashboardDatePreset.value = DatePreset.THIS_MONTH
    _datePreset.value = DatePreset.THIS_MONTH
    _dashboardFromDate.value = ""
    _dashboardToDate.value = ""
    _dashboardBookingStatus.value = "ALL"
    _dashboardPaymentStatus.value = "ALL"
    _dashboardCustomerQuery.value = ""
    _dashboardBookingIdQuery.value = ""
    _dashboardEventDateQuery.value = ""
    _dashboardPaymentTypeFilter.value = "ALL"
    _reportsPaymentFilter.value = "ALL"
    _reportsSearchQuery.value = ""
  }

  fun toggleDashboardFilterExpanded() {
    _isDashboardFilterExpanded.value = !_isDashboardFilterExpanded.value
  }

  // Financial Figure Source Modal
  private val _selectedFinancialFigureType = MutableStateFlow<String?>(null)
  val selectedFinancialFigureType: StateFlow<String?> = _selectedFinancialFigureType.asStateFlow()

  private val _showFinancialFigureModal = MutableStateFlow(false)
  val showFinancialFigureModal: StateFlow<Boolean> = _showFinancialFigureModal.asStateFlow()

  fun openFinancialSourceModal(type: String) {
    _selectedFinancialFigureType.value = type
    _showFinancialFigureModal.value = true
  }

  fun closeFinancialSourceModal() {
    _showFinancialFigureModal.value = false
    _selectedFinancialFigureType.value = null
  }

  // Admin ERP Sections
  private val _adminSubSection = MutableStateFlow(AdminSection.BOOKINGS)
  val adminSubSection: StateFlow<AdminSection> = _adminSubSection.asStateFlow()

  fun setAdminSubSection(section: AdminSection) {
    _adminSubSection.value = section
  }

  private val _adminBookingFilter = MutableStateFlow("CONFIRMED")
  val adminBookingFilter: StateFlow<String> = _adminBookingFilter.asStateFlow()

  fun setAdminBookingFilter(filter: String) {
    _adminBookingFilter.value = filter
  }

  private val _adminCollectionTab = MutableStateFlow("PAID")
  val adminCollectionTab: StateFlow<String> = _adminCollectionTab.asStateFlow()

  fun setAdminCollectionTab(tab: String) {
    _adminCollectionTab.value = tab
  }

  // Employee Management States
  private val _showAddEmployeeDialog = MutableStateFlow(false)
  val showAddEmployeeDialog: StateFlow<Boolean> = _showAddEmployeeDialog.asStateFlow()

  fun openAddEmployeeDialog() {
    _showAddEmployeeDialog.value = true
  }

  fun closeAddEmployeeDialog() {
    _showAddEmployeeDialog.value = false
  }

  private val _showRecordAttendanceDialog = MutableStateFlow(false)
  val showRecordAttendanceDialog: StateFlow<Boolean> = _showRecordAttendanceDialog.asStateFlow()

  fun openRecordAttendanceDialog() {
    _showRecordAttendanceDialog.value = true
  }

  fun closeRecordAttendanceDialog() {
    _showRecordAttendanceDialog.value = false
  }

  private val _showRecordEmployeePaymentDialog = MutableStateFlow(false)
  val showRecordEmployeePaymentDialog: StateFlow<Boolean> = _showRecordEmployeePaymentDialog.asStateFlow()

  fun openRecordEmployeePaymentDialog() {
    _showRecordEmployeePaymentDialog.value = true
  }

  fun closeRecordEmployeePaymentDialog() {
    _showRecordEmployeePaymentDialog.value = false
  }

  private val _selectedEmployeeForDetail = MutableStateFlow<EmployeeEntity?>(null)
  val selectedEmployeeForDetail: StateFlow<EmployeeEntity?> = _selectedEmployeeForDetail.asStateFlow()

  private val _showEmployeeDetailDialog = MutableStateFlow(false)
  val showEmployeeDetailDialog: StateFlow<Boolean> = _showEmployeeDetailDialog.asStateFlow()

  fun openEmployeeDetail(emp: EmployeeEntity) {
    _selectedEmployeeForDetail.value = emp
    _showEmployeeDetailDialog.value = true
  }

  fun closeEmployeeDetail() {
    _showEmployeeDetailDialog.value = false
    _selectedEmployeeForDetail.value = null
  }

  fun createEmployee(
    name: String,
    mobile: String,
    address: String,
    joiningDate: String,
    category: String,
    dailyWage: Double
  ) {
    viewModelScope.launch {
      val empId = "EMP-${String.format("%03d", (allEmployees.value.size + 1))}"
      repository.addEmployee(
        EmployeeEntity(
          employeeId = empId,
          name = name,
          mobile = mobile,
          address = address,
          joiningDate = joiningDate,
          category = category,
          dailyWage = dailyWage
        )
      )
      closeAddEmployeeDialog()
      showToast("Employee $name added successfully!")
    }
  }

  fun markAttendance(
    employeeId: String,
    employeeName: String,
    date: String,
    formattedDate: String,
    status: String,
    dailyRate: Double,
    eventReference: String,
    notes: String
  ) {
    viewModelScope.launch {
      repository.recordAttendance(
        EmployeeAttendanceEntity(
          employeeId = employeeId,
          employeeName = employeeName,
          date = date,
          formattedDate = formattedDate,
          status = status,
          dailyRate = dailyRate,
          eventReference = eventReference,
          notes = notes
        )
      )
      closeRecordAttendanceDialog()
      showToast("Attendance recorded: $employeeName ($status)")
    }
  }

  fun recordEmployeeSalaryPayment(
    employeeId: String,
    employeeName: String,
    date: String,
    formattedDate: String,
    amount: Double,
    mode: String,
    relatedEvent: String,
    ref: String,
    paymentType: String,
    notes: String
  ) {
    viewModelScope.launch {
      repository.recordEmployeePayment(
        EmployeePaymentEntity(
          employeeId = employeeId,
          employeeName = employeeName,
          paymentDate = date,
          formattedDate = formattedDate,
          amount = amount,
          paymentMode = mode,
          relatedEvent = relatedEvent,
          paymentReference = ref,
          paymentType = paymentType,
          notes = notes
        )
      )
      closeRecordEmployeePaymentDialog()
      showToast("Payment recorded: ₹$amount ($employeeName)")
    }
  }

  fun deleteEmployee(id: Long) {
    viewModelScope.launch {
      repository.deleteEmployee(id)
      showToast("Employee record deleted")
    }
  }

  // Price History Modal
  private val _selectedItemForPriceHistory = MutableStateFlow<InventoryItemEntity?>(null)
  val selectedItemForPriceHistory: StateFlow<InventoryItemEntity?> = _selectedItemForPriceHistory.asStateFlow()

  private val _showPriceHistoryModal = MutableStateFlow(false)
  val showPriceHistoryModal: StateFlow<Boolean> = _showPriceHistoryModal.asStateFlow()

  fun openPriceHistoryModal(item: InventoryItemEntity) {
    _selectedItemForPriceHistory.value = item
    _showPriceHistoryModal.value = true
  }

  fun closePriceHistoryModal() {
    _showPriceHistoryModal.value = false
    _selectedItemForPriceHistory.value = null
  }

  fun setActiveTab(tab: AppTab) {
    _activeTab.value = tab
  }

  fun setHomeSubTab(subTab: HomeSubTab) {
    _homeSubTab.value = subTab
  }

  fun setStatusFilter(filter: String) {
    _statusFilter.value = filter
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun setSelectedCalendarDate(date: String) {
    _selectedCalendarDate.value = date
  }

  fun setDatePreset(preset: DatePreset) {
    _datePreset.value = preset
  }

  fun setReportCategoryTab(tab: ReportCategoryTab) {
    _reportCategoryTab.value = tab
  }

  fun setReportsPaymentFilter(filter: String) {
    _reportsPaymentFilter.value = filter
  }

  fun setReportsSearchQuery(query: String) {
    _reportsSearchQuery.value = query
  }

  fun openNewBookingModal() {
    _showNewBookingModal.value = true
  }

  fun closeNewBookingModal() {
    _showNewBookingModal.value = false
  }

  fun openNewItemModal() {
    _showNewItemModal.value = true
  }

  fun closeNewItemModal() {
    _showNewItemModal.value = false
  }

  fun openInvoicePreview(booking: BookingEntity) {
    _selectedBookingForInvoice.value = booking
    _showInvoicePreviewModal.value = true
  }

  fun closeInvoicePreview() {
    _showInvoicePreviewModal.value = false
    _selectedBookingForInvoice.value = null
  }

  fun openDailyLimitDialog() {
    _showDailyLimitDialog.value = true
  }

  fun closeDailyLimitDialog() {
    _showDailyLimitDialog.value = false
  }

  fun openAdminPinDialog() {
    _showAdminPinDialog.value = true
  }

  fun closeAdminPinDialog() {
    _showAdminPinDialog.value = false
  }

  fun openAddExpenseDialog() {
    _showAddExpenseDialog.value = true
  }

  fun closeAddExpenseDialog() {
    _showAddExpenseDialog.value = false
  }

  fun openAddPurchaseDialog() {
    _showAddPurchaseDialog.value = true
  }

  fun closeAddPurchaseDialog() {
    _showAddPurchaseDialog.value = false
  }

  fun openRecordPaymentDialog() {
    _showRecordPaymentDialog.value = true
  }

  fun closeRecordPaymentDialog() {
    _showRecordPaymentDialog.value = false
  }

  fun openAddOrderDialog() {
    _showAddOrderDialog.value = true
  }

  fun closeAddOrderDialog() {
    _showAddOrderDialog.value = false
  }

  fun openPartyDetail(party: PartySummary) {
    _selectedPartyForDetail.value = party
    _showPartyDetailDialog.value = true
  }

  fun closePartyDetail() {
    _showPartyDetailDialog.value = false
    _selectedPartyForDetail.value = null
  }

  fun openItemDetail(item: InventoryItemEntity) {
    _selectedItemForDetail.value = item
    _showItemDetailDialog.value = true
  }

  fun closeItemDetail() {
    _showItemDetailDialog.value = false
    _selectedItemForDetail.value = null
  }

  fun openPurchaseDetail(purchase: PurchaseEntity) {
    _selectedPurchaseForDetail.value = purchase
    _showPurchaseDetailDialog.value = true
  }

  fun closePurchaseDetail() {
    _showPurchaseDetailDialog.value = false
    _selectedPurchaseForDetail.value = null
  }

  fun openExpenseDetail(expense: ExpenseEntity) {
    _selectedExpenseForDetail.value = expense
    _showExpenseDetailDialog.value = true
  }

  fun closeExpenseDetail() {
    _showExpenseDetailDialog.value = false
    _selectedExpenseForDetail.value = null
  }

  fun openPaymentReceipt(payment: CustomerPaymentEntity) {
    _selectedPaymentForDetail.value = payment
    _showPaymentReceiptDialog.value = true
  }

  fun closePaymentReceipt() {
    _showPaymentReceiptDialog.value = false
    _selectedPaymentForDetail.value = null
  }

  fun openOrderDetail(order: OrderEntity) {
    _selectedOrderForDetail.value = order
    _showOrderDetailDialog.value = true
  }

  fun closeOrderDetail() {
    _showOrderDetailDialog.value = false
    _selectedOrderForDetail.value = null
  }

  fun verifyAdminPin(enteredPin: String): Boolean {
    val currentPin = businessProfile.value.adminPin
    return if (enteredPin == currentPin) {
      _isAdminUnlocked.value = true
      _showAdminPinDialog.value = false
      showToast("Admin mode unlocked!")
      true
    } else {
      showToast("Incorrect PIN! Please try again.")
      false
    }
  }

  fun lockAdmin() {
    _isAdminUnlocked.value = false
  }

  fun showToast(message: String) {
    _toastMessage.value = message
  }

  fun clearToast() {
    _toastMessage.value = null
  }

  // Business operations
  fun createBooking(
    salutation: String,
    name: String,
    phone: String,
    altPhone: String,
    custAddress: String,
    venueAddress: String,
    eventDate: String,
    eventType: String,
    items: List<BookingItem>,
    totalAmount: Double,
    advancePaid: Double,
    payMode: String,
    autoWhatsApp: Boolean,
    context: Context? = null
  ) {
    viewModelScope.launch {
      val count = allBookings.value.size
      val nextId = if (count > 0) allBookings.value.maxOf { it.id } + 1 else 38L
      val formattedDate = formatDisplayDate(eventDate)
      val balanceDue = (totalAmount - advancePaid).coerceAtLeast(0.0)
      val status = if (balanceDue == 0.0) "PAYMENT-IN" else "CONFIRMED"
      val estimatedCost = totalAmount * 0.6 // 60% estimated cost

      val booking = BookingEntity(
        id = nextId,
        invoiceNumber = "INV-2026-0$nextId",
        salutation = salutation,
        customerName = name,
        customerPhone = phone,
        customerAltPhone = altPhone,
        customerAddress = custAddress,
        eventVenueAddress = venueAddress,
        eventDate = eventDate,
        formattedDate = formattedDate,
        eventType = eventType,
        itemsJson = JsonHelper.serializeBookingItems(items),
        totalAmount = totalAmount,
        advancePaid = advancePaid,
        balanceDue = balanceDue,
        estimatedCost = estimatedCost,
        paymentMode = payMode,
        status = status
      )

      repository.createBooking(booking, items)
      closeNewBookingModal()
      showToast("Booking #$nextId recorded successfully!")

      if (autoWhatsApp && context != null) {
        shareInvoiceViaWhatsApp(context, booking)
      }
    }
  }

  fun cancelBooking(bookingId: Long) {
    viewModelScope.launch {
      repository.cancelBooking(bookingId)
      showToast("Booking #$bookingId cancelled and stock restored to inventory.")
    }
  }

  fun addNewInventoryItem(
    name: String,
    stock: Double,
    unit: String,
    rate: Double,
    category: String = "General",
    purchaseCost: Double = 0.0,
    minAlertStock: Double = 5.0,
    batchNumber: String = "B-2026-01",
    serialNumber: String = "SN-SOE-001",
    defaultDiscountPercent: Double = 0.0,
    sku: String = "",
    currentMarketPrice: Double = rate,
    supplierName: String = "",
    supplierMobile: String = "",
    purchaseDate: String = "2026-11-10",
    description: String = ""
  ) {
    viewModelScope.launch {
      val newId = "itm_${System.currentTimeMillis()}"
      val item = InventoryItemEntity(
        id = newId,
        name = name,
        stock = stock,
        unit = unit,
        rate = rate,
        purchaseCost = purchaseCost,
        minAlertStock = minAlertStock,
        category = category,
        batchNumber = batchNumber,
        serialNumber = serialNumber,
        defaultDiscountPercent = defaultDiscountPercent,
        sku = if (sku.isNotBlank()) sku else newId,
        currentMarketPrice = if (currentMarketPrice > 0) currentMarketPrice else rate,
        supplierName = supplierName,
        supplierMobile = supplierMobile,
        purchaseDate = purchaseDate,
        description = description,
        previousPurchasePrice = purchaseCost,
        priceChangeDate = purchaseDate
      )
      repository.addInventoryItem(item)
      closeNewItemModal()
      showToast("$name added to inventory master successfully!")
    }
  }

  fun createExpense(
    title: String,
    category: String,
    amount: Double,
    date: String,
    mode: String,
    remarks: String
  ) {
    viewModelScope.launch {
      val exp = ExpenseEntity(
        expenseTitle = title,
        category = category,
        amount = amount,
        expenseDate = date,
        formattedDate = formatDisplayDate(date),
        paymentMode = mode,
        remarks = remarks
      )
      repository.addExpense(exp)
      closeAddExpenseDialog()
      showToast("Expense ₹$amount recorded successfully!")
    }
  }

  fun createPurchase(
    vendor: String,
    item: String,
    qty: Double,
    unit: String,
    rate: Double,
    paid: Double,
    mode: String
  ) {
    viewModelScope.launch {
      val total = qty * rate
      val due = (total - paid).coerceAtLeast(0.0)
      val pur = PurchaseEntity(
        billNumber = "PUR-${System.currentTimeMillis().toString().takeLast(6)}",
        vendorName = vendor,
        purchaseDate = "2026-11-10",
        formattedDate = "10 Nov, 26",
        itemName = item,
        quantity = qty,
        unit = unit,
        rate = rate,
        totalAmount = total,
        paidAmount = paid,
        dueAmount = due,
        paymentMode = mode
      )
      repository.addPurchase(pur)
      closeAddPurchaseDialog()
      showToast("Purchase bill ₹$total recorded successfully!")
    }
  }

  fun recordPayment(
    customer: String,
    phone: String,
    amount: Double,
    type: String,
    mode: String,
    note: String
  ) {
    viewModelScope.launch {
      val payment = CustomerPaymentEntity(
        customerName = customer,
        customerPhone = phone,
        paymentDate = "2026-11-10",
        formattedDate = "10 Nov, 26",
        amount = amount,
        paymentType = type,
        paymentMode = mode,
        receiptNumber = "REC-${System.currentTimeMillis().toString().takeLast(5)}",
        note = note
      )
      repository.recordCustomerPayment(payment)
      closeRecordPaymentDialog()
      showToast("Payment record ₹$amount saved successfully!")
    }
  }

  fun createOrder(
    party: String,
    phone: String,
    type: String,
    total: Double,
    adv: Double
  ) {
    viewModelScope.launch {
      val order = OrderEntity(
        orderNumber = if (type == "SALE_ORDER") "SO-${System.currentTimeMillis().toString().takeLast(4)}" else "PO-${System.currentTimeMillis().toString().takeLast(4)}",
        orderType = type,
        partyName = party,
        partyPhone = phone,
        orderDate = "2026-11-10",
        deliveryDate = "2026-11-25",
        itemsJson = "[]",
        totalAmount = total,
        advanceAmount = adv
      )
      repository.addOrder(order)
      closeAddOrderDialog()
      showToast("Order ${order.orderNumber} saved successfully!")
    }
  }

  fun updateStock(id: String, newStock: Double) {
    viewModelScope.launch {
      repository.updateInventoryStock(id, newStock)
      showToast("Stock updated successfully!")
    }
  }

  fun saveBusinessProfile(updatedProfile: BusinessProfileEntity) {
    viewModelScope.launch {
      repository.updateProfile(updatedProfile)
      showToast("Business profile saved successfully!")
    }
  }

  fun saveDailyLimit(newLimit: Int) {
    viewModelScope.launch {
      val current = businessProfile.value
      repository.updateProfile(current.copy(dailyBookingLimit = newLimit))
      closeDailyLimitDialog()
      showToast("Daily booking limit set to $newLimit!")
    }
  }

  fun syncNow() {
    viewModelScope.launch {
      _isSyncing.value = true
      repository.syncWithServer()
      _isSyncing.value = false
      showToast("Real-time sync complete! Cloud database is up to date.")
    }
  }

  fun markNotificationsAsRead() {
    viewModelScope.launch {
      repository.markAllNotificationsAsRead()
    }
  }

  fun clearAllNotifications() {
    viewModelScope.launch {
      repository.clearAllNotifications()
      showToast("All alerts cleared successfully!")
    }
  }

  fun exportDatabaseJson(context: Context) {
    viewModelScope.launch {
      val json = repository.exportDataAsJson()
      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "application/json"
        putExtra(Intent.EXTRA_SUBJECT, "Shree_Om_Event_Backup.json")
        putExtra(Intent.EXTRA_TEXT, json)
      }
      context.startActivity(Intent.createChooser(shareIntent, "Share JSON Database Backup"))
    }
  }

  fun exportCsv(context: Context) {
    viewModelScope.launch {
      val csv = repository.generateSalesCsv()
      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(Intent.EXTRA_SUBJECT, "Shree_Om_Event_Sales_Report.csv")
        putExtra(Intent.EXTRA_TEXT, csv)
      }
      context.startActivity(Intent.createChooser(shareIntent, "Share Sales CSV Report"))
    }
  }

  fun shareInvoiceViaWhatsApp(context: Context, booking: BookingEntity) {
    val items = JsonHelper.deserializeBookingItems(booking.itemsJson)
    val itemsSummary = if (items.isNotEmpty()) {
      items.joinToString("\n") { "• ${it.name} (${it.qty} ${it.unit})" }
    } else {
      "• ${booking.eventType}"
    }

    val text = """
*SHREE OM EVENT & DECORATION*
*Booking Confirmation & Invoice #${booking.id}*

Dear *${booking.salutation} ${booking.customerName}*,
Your event booking has been confirmed successfully.

📅 *Event Date:* ${booking.formattedDate}
📍 *Venue:* ${booking.eventVenueAddress}
🎉 *Package / Service:* ${booking.eventType}
$itemsSummary

💰 *Total Amount:* ₹${String.format("%,.2f", booking.totalAmount)}
✅ *Advance Paid:* ₹${String.format("%,.2f", booking.advancePaid)} (${booking.paymentMode})
🔴 *Balance Due:* ₹${String.format("%,.2f", booking.balanceDue)}

_Thank you for choosing Shree Om Event! We look forward to creating memorable moments for you._
📞 Contact: ${businessProfile.value.phone1}
    """.trimIndent()

    openWhatsApp(context, booking.customerPhone, text)
  }

  fun sendReminderWhatsApp(context: Context, booking: BookingEntity) {
    val text = """
*PAYMENT REMINDER: SHREE OM EVENT & DECORATION*

Dear *${booking.salutation} ${booking.customerName}*,
We hope your event preparations are going smoothly!
This is a gentle reminder that a balance due of *₹${String.format("%,.2f", booking.balanceDue)}* is pending for your booking on *${booking.formattedDate}*.

Kindly complete the payment at your earliest convenience.
UPI ID: *shreeomevent@upi*

Thank you!
📞 ${businessProfile.value.phone1}
    """.trimIndent()

    openWhatsApp(context, booking.customerPhone, text)
  }

  fun shareVisitingCard(context: Context, profile: BusinessProfileEntity) {
    val text = """
*${profile.businessName}*
_${profile.description}_

📍 Address: ${profile.address}
📞 Phone: ${profile.phone1} ${if (profile.phone2.isNotEmpty()) "/ " + profile.phone2 else ""}
✉️ Email: ${profile.email}
🏛️ GSTIN: ${if (profile.gstin.isNotEmpty()) profile.gstin else "Registered"}
Category: ${profile.category} (${profile.businessType})

Thank you for viewing our digital business profile!
    """.trimIndent()

    val intent = Intent(Intent.ACTION_SEND).apply {
      type = "text/plain"
      putExtra(Intent.EXTRA_SUBJECT, "${profile.businessName} - Visiting Card")
      putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, "Share Business Card"))
  }

  fun updateInventoryItemFull(item: InventoryItemEntity) {
    viewModelScope.launch {
      repository.updateInventoryItem(item)
      _selectedItemForDetail.value = item
      showToast("${item.name} details updated successfully!")
    }
  }

  fun markPurchaseAsPaid(purchaseId: Long) {
    viewModelScope.launch {
      repository.markPurchaseAsPaid(purchaseId)
      closePurchaseDetail()
      showToast("Purchase bill marked as paid in full!")
    }
  }

  fun removeExpense(expenseId: Long) {
    viewModelScope.launch {
      repository.deleteExpense(expenseId)
      closeExpenseDetail()
      showToast("Expense entry deleted successfully!")
    }
  }

  fun changeOrderStatus(orderId: Long, newStatus: String) {
    viewModelScope.launch {
      repository.updateOrderStatus(orderId, newStatus)
      closeOrderDetail()
      showToast("Order status updated to '$newStatus'!")
    }
  }

  fun callPhone(context: Context, phone: String) {
    try {
      val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
      context.startActivity(intent)
    } catch (_: Exception) {
      showToast("Unable to place call: $phone")
    }
  }

  fun sharePartyStatementWhatsApp(context: Context, party: PartySummary, partyBookings: List<BookingEntity>) {
    val bDetails = partyBookings.joinToString("\n") { b ->
      "• ${b.formattedDate} (${b.eventType}): Total ₹${b.totalAmount}, Adv ₹${b.advancePaid}, Due ₹${b.balanceDue}"
    }
    val text = """
*PARTY STATEMENT: SHREE OM EVENT & DECORATION*
Customer: *${party.salutation} ${party.name}*
📱 Phone: ${party.phone}

*Transactions Ledger:*
$bDetails

------------------------
💰 *Total Billed:* ₹${String.format("%,.2f", party.totalBilled)}
🔴 *Total Balance Due:* ₹${String.format("%,.2f", party.totalDue)}

_For any queries or assistance, please contact:_
📞 ${businessProfile.value.phone1}
    """.trimIndent()
    openWhatsApp(context, party.phone, text)
  }

  fun sharePaymentReceiptWhatsApp(context: Context, payment: CustomerPaymentEntity) {
    val text = """
*DIGITAL PAYMENT RECEIPT - SHREE OM EVENT*
Receipt No: *${payment.receiptNumber}*
Customer: *${payment.customerName}*
Date: *${payment.formattedDate}*

Amount: *₹${String.format("%,.2f", payment.amount)}*
Mode: *${payment.paymentMode}*
Type: *${if (payment.paymentType == "PAYMENT_IN") "Deposit (Payment In)" else "Refund / Expense"}*
Note: *${payment.note}*

_Thank you! Shree Om Event & Decoration, Umaria_
📞 ${businessProfile.value.phone1}
    """.trimIndent()
    openWhatsApp(context, payment.customerPhone, text)
  }

  fun sharePurchaseBillWhatsApp(context: Context, purchase: PurchaseEntity) {
    val text = """
*PURCHASE BILL - SHREE OM EVENT UMARIA*
Bill No: *${purchase.billNumber}*
Supplier: *${purchase.vendorName}*
Date: *${purchase.formattedDate}*

Item: *${purchase.itemName}* (${purchase.quantity} ${purchase.unit} @ ₹${purchase.rate})
Total: *₹${String.format("%,.2f", purchase.totalAmount)}*
Paid: *₹${String.format("%,.2f", purchase.paidAmount)}* (${purchase.paymentMode})
Balance Due: *₹${String.format("%,.2f", purchase.dueAmount)}*

Thank you!
📞 ${businessProfile.value.phone1}
    """.trimIndent()
    openWhatsApp(context, purchase.vendorPhone.ifBlank { "9584249750" }, text)
  }

  fun shareOrderDetailWhatsApp(context: Context, order: OrderEntity) {
    val text = """
*ORDER CONFIRMATION - SHREE OM EVENT*
Order No: *${order.orderNumber}*
Party: *${order.partyName}*
Type: *${if (order.orderType == "SALE_ORDER") "Sale Order" else "Purchase Order"}*
Delivery Date: *${order.deliveryDate}*

Estimated Total: *₹${String.format("%,.2f", order.totalAmount)}*
Advance Paid: *₹${String.format("%,.2f", order.advanceAmount)}*
Status: *${order.status}*

Thank you!
📞 ${businessProfile.value.phone1}
    """.trimIndent()
    openWhatsApp(context, order.partyPhone, text)
  }

  private fun openWhatsApp(context: Context, phone: String, message: String) {
    try {
      val cleanPhone = phone.replace(Regex("[^0-9]"), "")
      val formattedPhone = if (cleanPhone.length == 10) "91$cleanPhone" else cleanPhone
      val encodedMsg = URLEncoder.encode(message, "UTF-8")
      val uri = Uri.parse("https://api.whatsapp.com/send?phone=$formattedPhone&text=$encodedMsg")
      val intent = Intent(Intent.ACTION_VIEW, uri)
      context.startActivity(intent)
    } catch (_: Exception) {
      val sendIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, message)
      }
      context.startActivity(Intent.createChooser(sendIntent, "Share"))
    }
  }

  private fun formatDisplayDate(dateStr: String): String {
    return try {
      val parts = dateStr.split("-")
      if (parts.size == 3) {
        val yr = parts[0].takeLast(2)
        val mIdx = parts[1].toIntOrNull() ?: 1
        val day = parts[2]
        val months = listOf("", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        "$day ${months.getOrElse(mIdx) { "Jul" }}, $yr"
      } else {
        dateStr
      }
    } catch (_: Exception) {
      dateStr
    }
  }
}
