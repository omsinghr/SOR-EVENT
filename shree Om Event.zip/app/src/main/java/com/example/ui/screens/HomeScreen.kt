package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.FolderCopy
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BookingEntity
import com.example.ui.AppTab
import com.example.ui.HomeSubTab
import com.example.ui.MainViewModel
import com.example.ui.PartySummary
import com.example.ui.theme.SoePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VyaparBlue
import com.example.ui.theme.VyaparGreen

@Composable
fun HomeScreen(
  viewModel: MainViewModel,
  bookings: List<BookingEntity>,
  subTab: HomeSubTab,
  statusFilter: String,
  searchQuery: String,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  // Filter bookings
  val filteredBookings = remember(bookings, searchQuery, statusFilter) {
    bookings.filter { b ->
      val matchesQuery = b.customerName.contains(searchQuery, ignoreCase = true) ||
        b.customerPhone.contains(searchQuery) ||
        b.invoiceNumber.contains(searchQuery, ignoreCase = true) ||
        b.eventVenueAddress.contains(searchQuery, ignoreCase = true)

      val matchesStatus = when (statusFilter) {
        "DUE" -> b.balanceDue > 0
        "PAID" -> b.balanceDue == 0.0
        else -> true
      }
      matchesQuery && matchesStatus
    }
  }

  // Aggregate Party list
  val partyList = remember(bookings) {
    bookings.groupBy { it.customerPhone }.map { (phone, partyBookings) ->
      val first = partyBookings.first()
      PartySummary(
        name = first.customerName,
        salutation = first.salutation,
        phone = phone,
        address = first.customerAddress.ifBlank { first.eventVenueAddress },
        totalBookings = partyBookings.size,
        totalDue = partyBookings.sumOf { it.balanceDue },
        totalBilled = partyBookings.sumOf { it.totalAmount }
      )
    }
  }

  val totalDueSum = remember(bookings) { bookings.sumOf { it.balanceDue } }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp, vertical = 8.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    if (subTab == HomeSubTab.TRANSACTIONS) {
      // 1. Quick Links Grid (4 icons matching prototype)
      item {
        QuickLinksGrid(
          onAddTxn = { viewModel.openNewBookingModal() },
          onSaleReport = { viewModel.setActiveTab(AppTab.DASHBOARD) },
          onCalendar = { viewModel.openDailyLimitDialog() },
          onStockItems = { viewModel.setActiveTab(AppTab.ITEMS) }
        )
      }

      // 2. Search & Filter Bar
      item {
        SearchAndFilterRow(
          searchQuery = searchQuery,
          onSearchChange = { viewModel.setSearchQuery(it) },
          onToggleFilter = {
            val next = if (statusFilter == "ALL") "DUE" else "ALL"
            viewModel.setStatusFilter(next)
          }
        )
      }

      // 3. Filter Chips (All, Pending Due, Paid)
      item {
        FilterChipsRow(
          activeFilter = statusFilter,
          onSelectFilter = { viewModel.setStatusFilter(it) }
        )
      }

      // 4. Summary Floating Ticker (Navy Gradient)
      item {
        SummaryTickerCard(
          totalDue = totalDueSum,
          totalBookingsCount = bookings.size
        )
      }

      // 5. Transaction Cards List
      if (filteredBookings.isEmpty()) {
        item {
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 20.dp)
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(
                imageVector = Icons.Default.ReceiptLong,
                contentDescription = null,
                tint = Color(0xFFCBD5E1),
                modifier = Modifier.size(36.dp)
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "No transactions found",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary
              )
            }
          }
        }
      } else {
        items(filteredBookings, key = { it.id }) { booking ->
          TransactionCardItem(
            booking = booking,
            onPrint = { viewModel.openInvoicePreview(booking) },
            onShare = { viewModel.shareInvoiceViaWhatsApp(context, booking) },
            onCancel = { viewModel.cancelBooking(booking.id) }
          )
        }
      }
    } else {
      // SUB-TAB: PARTY DETAILS VIEW
      item {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = Color.White,
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text(
              text = "Party / Customer Directory",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Text(
              text = "All registered customer accounts and their pending balance ledgers.",
              fontSize = 11.sp,
              color = TextSecondary,
              modifier = Modifier.padding(top = 2.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (partyList.isEmpty()) {
              Text(
                text = "No customers registered yet.",
                fontSize = 12.sp,
                color = TextSecondary
              )
            } else {
              Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                partyList.forEach { party ->
                  Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFF8FAFC),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier
                      .fillMaxWidth()
                      .clickable { viewModel.openPartyDetail(party) }
                  ) {
                    Row(
                      modifier = Modifier.padding(12.dp),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                          Text(
                            text = "${party.salutation} ${party.name}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                          )
                          Spacer(modifier = Modifier.width(6.dp))
                          Box(
                            modifier = Modifier
                              .background(Color(0xFFE0F2FE), RoundedCornerShape(4.dp))
                              .padding(horizontal = 4.dp, vertical = 1.dp)
                          ) {
                            Text(text = "View Ledger >", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
                          }
                        }
                        Text(
                          text = "📱 ${party.phone} • ${party.totalBookings} Bookings",
                          fontSize = 11.sp,
                          color = TextSecondary
                        )
                        Text(
                          text = "📍 ${party.address}",
                          fontSize = 10.sp,
                          color = Color(0xFF94A3B8),
                          maxLines = 1
                        )
                      }

                      Column(horizontalAlignment = Alignment.End) {
                        Text(
                          text = "Pending Due",
                          fontSize = 10.sp,
                          fontWeight = FontWeight.SemiBold,
                          color = TextSecondary
                        )
                        Text(
                          text = "₹ ${String.format("%,.2f", party.totalDue)}",
                          fontSize = 13.sp,
                          fontWeight = FontWeight.Black,
                          color = if (party.totalDue > 0) SoePrimary else VyaparGreen
                        )
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // Bottom buffer for floating button and nav
    item {
      Spacer(modifier = Modifier.height(56.dp))
    }
  }
}

@Composable
private fun QuickLinksGrid(
  onAddTxn: () -> Unit,
  onSaleReport: () -> Unit,
  onCalendar: () -> Unit,
  onStockItems: () -> Unit
) {
  Surface(
    shape = RoundedCornerShape(18.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Text(
        text = "Quick Links",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceAround
      ) {
        // Add Txn
        QuickLinkItem(
          icon = Icons.Default.FolderCopy,
          label = "Add Txn",
          bgColor = Color(0xFFFFE4E6),
          tint = SoePrimary,
          onClick = onAddTxn,
          testTag = "quick_link_add_txn"
        )

        // Sale Report
        QuickLinkItem(
          icon = Icons.Default.ReceiptLong,
          label = "Sale Report",
          bgColor = Color(0xFFE0F2FE),
          tint = VyaparBlue,
          onClick = onSaleReport,
          testTag = "quick_link_sale_report"
        )

        // Calendar
        QuickLinkItem(
          icon = Icons.Default.CalendarMonth,
          label = "Calendar",
          bgColor = Color(0xFFCCFBF1),
          tint = Color(0xFF0F766E),
          onClick = onCalendar,
          testTag = "quick_link_calendar"
        )

        // Stock Items
        QuickLinkItem(
          icon = Icons.Default.Inventory2,
          label = "Stock Items",
          bgColor = Color(0xFFE0E7FF),
          tint = Color(0xFF4338CA),
          onClick = onStockItems,
          testTag = "quick_link_stock_items"
        )
      }
    }
  }
}

@Composable
private fun QuickLinkItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  bgColor: Color,
  tint: Color,
  onClick: () -> Unit,
  testTag: String
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clickable(onClick = onClick)
      .testTag(testTag)
  ) {
    Box(
      modifier = Modifier
        .size(46.dp)
        .background(bgColor, RoundedCornerShape(14.dp)),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = tint,
        modifier = Modifier.size(22.dp)
      )
    }
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = label,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = TextPrimary
    )
  }
}

@Composable
private fun SearchAndFilterRow(
  searchQuery: String,
  onSearchChange: (String) -> Unit,
  onToggleFilter: () -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    OutlinedTextField(
      value = searchQuery,
      onValueChange = onSearchChange,
      placeholder = { Text("Search for a transaction / customer...", fontSize = 11.sp) },
      leadingIcon = {
        Icon(
          imageVector = Icons.Default.Search,
          contentDescription = "Search",
          tint = VyaparBlue,
          modifier = Modifier.size(18.dp)
        )
      },
      shape = RoundedCornerShape(12.dp),
      colors = TextFieldDefaults.colors(
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White,
        focusedIndicatorColor = VyaparBlue,
        unfocusedIndicatorColor = Color(0xFFE2E8F0)
      ),
      singleLine = true,
      modifier = Modifier
        .weight(1f)
        .testTag("home_search_input")
    )

    Surface(
      onClick = onToggleFilter,
      shape = RoundedCornerShape(12.dp),
      color = Color.White,
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
      modifier = Modifier
        .size(46.dp)
        .testTag("home_filter_button")
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = Icons.Default.FilterList,
          contentDescription = "Filter",
          tint = VyaparBlue,
          modifier = Modifier.size(20.dp)
        )
      }
    }
  }
}

@Composable
private fun FilterChipsRow(
  activeFilter: String,
  onSelectFilter: (String) -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    FilterChipItem(
      label = "All",
      isSelected = activeFilter == "ALL",
      onClick = { onSelectFilter("ALL") }
    )
    FilterChipItem(
      label = "Pending Due",
      isSelected = activeFilter == "DUE",
      textColor = SoePrimary,
      onClick = { onSelectFilter("DUE") }
    )
    FilterChipItem(
      label = "Paid in Full",
      isSelected = activeFilter == "PAID",
      textColor = VyaparGreen,
      onClick = { onSelectFilter("PAID") }
    )
  }
}

@Composable
private fun FilterChipItem(
  label: String,
  isSelected: Boolean,
  textColor: Color = TextPrimary,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(20.dp))
      .background(if (isSelected) Color(0xFF1E293B) else Color.White)
      .border(
        width = 1.dp,
        color = if (isSelected) Color(0xFF1E293B) else Color(0xFFCBD5E1),
        shape = RoundedCornerShape(20.dp)
      )
      .clickable(onClick = onClick)
      .padding(horizontal = 12.dp, vertical = 5.dp)
  ) {
    Text(
      text = label,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = if (isSelected) Color.White else textColor
    )
  }
}

@Composable
private fun SummaryTickerCard(
  totalDue: Double,
  totalBookingsCount: Int
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(18.dp))
      .background(
        brush = Brush.horizontalGradient(
          listOf(Color(0xFF0F172A), Color(0xFF1E1B4B))
        )
      )
      .padding(14.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "MARKET DUE (RECEIVABLES)",
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFFCBD5E1),
          letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "₹ ${String.format("%,.2f", totalDue)}",
          fontSize = 18.sp,
          fontWeight = FontWeight.Black,
          color = Color(0xFFF87171)
        )
      }

      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = "TOTAL BOOKINGS",
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFFCBD5E1),
          letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = totalBookingsCount.toString(),
          fontSize = 16.sp,
          fontWeight = FontWeight.Black,
          color = Color(0xFF7DD3FC)
        )
      }
    }
  }
}

@Composable
private fun TransactionCardItem(
  booking: BookingEntity,
  onPrint: () -> Unit,
  onShare: () -> Unit,
  onCancel: () -> Unit
) {
  Surface(
    shape = RoundedCornerShape(18.dp),
    color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    shadowElevation = 1.dp,
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onPrint() }
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      // Row 1: Name and ID / Date
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "${booking.salutation} ${booking.customerName}",
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            color = TextPrimary
          )

          // Status Badge
          val badgeBg: Color
          val badgeText: Color
          when {
            booking.balanceDue == 0.0 -> {
              badgeBg = Color(0xFFDCFCE7)
              badgeText = Color(0xFF15803D)
            }
            booking.advancePaid > 0 -> {
              badgeBg = Color(0xFFE0F2FE)
              badgeText = Color(0xFF0369A1)
            }
            else -> {
              badgeBg = Color(0xFFFFEDD5)
              badgeText = Color(0xFFC2410C)
            }
          }

          Box(
            modifier = Modifier
              .padding(top = 4.dp)
              .background(badgeBg, RoundedCornerShape(12.dp))
              .padding(horizontal = 8.dp, vertical = 2.dp)
          ) {
            Text(
              text = booking.status,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              color = badgeText
            )
          }
        }

        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "#${booking.id}",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF94A3B8)
          )
          Text(
            text = booking.formattedDate,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = TextSecondary
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Row 2: Financials (Total & Balance Due)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
          .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(text = "TOTAL", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
          Text(
            text = "₹ ${String.format("%,.2f", booking.totalAmount)}",
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            color = TextPrimary
          )
        }

        Column(horizontalAlignment = Alignment.End) {
          Text(text = "BALANCE DUE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
          Text(
            text = "₹ ${String.format("%,.2f", booking.balanceDue)}",
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            color = if (booking.balanceDue > 0) SoePrimary else VyaparGreen
          )
        }
      }

      // Location & Event Tag
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFFF1F5F9), RoundedCornerShape(6.dp))
          .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Icon(
            imageVector = Icons.Default.LocationOn,
            contentDescription = null,
            tint = TextSecondary,
            modifier = Modifier.size(11.dp)
          )
          Spacer(modifier = Modifier.width(3.dp))
          Text(
            text = booking.eventVenueAddress,
            fontSize = 10.sp,
            color = TextSecondary,
            maxLines = 1
          )
        }

        Text(
          text = booking.eventType.split(" ").firstOrNull() ?: "",
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          color = VyaparBlue
        )
      }

      // Row 3: Action Icons (Print, WhatsApp Share, Cancel/Delete)
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Print / View Invoice
        IconButton(onClick = onPrint, modifier = Modifier.size(32.dp)) {
          Icon(
            imageVector = Icons.Default.Print,
            contentDescription = "Print Invoice",
            tint = TextSecondary,
            modifier = Modifier.size(16.dp)
          )
        }

        // WhatsApp Share
        IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = "Share on WhatsApp",
            tint = VyaparGreen,
            modifier = Modifier.size(16.dp)
          )
        }

        // Cancel booking
        IconButton(onClick = onCancel, modifier = Modifier.size(32.dp)) {
          Icon(
            imageVector = Icons.Default.Delete,
            contentDescription = "Cancel Booking",
            tint = Color(0xFFEF4444),
            modifier = Modifier.size(16.dp)
          )
        }
      }
    }
  }
}
