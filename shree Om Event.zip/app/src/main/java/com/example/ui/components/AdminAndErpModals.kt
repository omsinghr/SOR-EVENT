package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.BookingEntity
import com.example.data.model.CustomerPaymentEntity
import com.example.data.model.EmployeeAttendanceEntity
import com.example.data.model.EmployeeEntity
import com.example.data.model.EmployeePaymentEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.InventoryItemEntity
import com.example.data.model.ItemPriceHistoryEntity
import com.example.data.model.PurchaseEntity
import com.example.ui.theme.SoePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VyaparAmber
import com.example.ui.theme.VyaparBlue
import com.example.ui.theme.VyaparDarkGreen
import com.example.ui.theme.VyaparGreen

// =========================================================================
// 1. FINANCIAL FIGURE SOURCE BREAKDOWN MODAL (Requirement 1 & 2)
// =========================================================================

@Composable
fun FinancialFigureSourceModal(
  figureType: String,
  bookings: List<BookingEntity>,
  purchases: List<PurchaseEntity>,
  expenses: List<ExpenseEntity>,
  items: List<InventoryItemEntity>,
  payments: List<CustomerPaymentEntity>,
  onDismiss: () -> Unit,
  onBookingClick: (BookingEntity) -> Unit,
  onPurchaseClick: (PurchaseEntity) -> Unit,
  onExpenseClick: (ExpenseEntity) -> Unit,
  onItemClick: (InventoryItemEntity) -> Unit
) {
  val (title, subtitle, headerColor) = when (figureType) {
    "TOTAL_SALES" -> Triple("कुल बिक्री स्रोत विवरण (Total Sales Source)", "यह आंकड़ा इन बुकिंग इनवॉइस से मिलकर बना है:", VyaparBlue)
    "NET_PROFIT" -> Triple("शुद्ध लाभ स्रोत विवरण (Net Profit Breakdown)", "बुकिंग राजस्व - अनुमानित लागत = वास्तविक लाभ:", VyaparDarkGreen)
    "PURCHASES" -> Triple("कुल खरीदी स्रोत विवरण (Total Purchases)", "वेंडर्स से खरीदी गई सामग्री एवं बिल सूची:", VyaparAmber)
    "EXPENSES" -> Triple("कुल खर्चे स्रोत विवरण (Total Expenses)", "संचालन, मजदूरी, जनरेटर व ट्रांसपोर्ट व्यय:", SoePrimary)
    "RECEIVABLES" -> Triple("बकाया प्राप्य राशि स्रोत (Pending Receivables)", "ग्राहकों की ओर से बाकी भुगतान विवरण:", SoePrimary)
    "STOCK_VALUATION" -> Triple("स्टॉक मूल्यांकन स्रोत (Stock Valuation)", "उपलब्ध इन्वेंट्री मात्रा × लागत मूल्य:", Color(0xFF4338CA))
    "ADVANCE_PAYMENTS" -> Triple("प्राप्त एडवांस राशि विवरण (Advance Collection)", "पुष्ट बुकिंग्स से प्राप्त प्रारंभिक एडवांस:", VyaparGreen)
    "TOTAL_BOOKING_COST" -> Triple("कुल इवेंट लागत विवरण (Total Booking Costs)", "सामान लागत + संचालन खर्च विवरण:", Color(0xFFB45309))
    else -> Triple("वित्तीय विवरण (Financial Source)", "विस्तृत रिकॉर्ड सूची:", VyaparBlue)
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .heightIn(max = 680.dp)
        .padding(vertical = 16.dp),
      shadowElevation = 8.dp
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        // Modal Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .background(headerColor.copy(alpha = 0.15f), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = headerColor, modifier = Modifier.size(20.dp))
            }
            Column {
              Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary)
              Text(text = subtitle, fontSize = 10.sp, color = TextSecondary)
            }
          }
          IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Content based on type
        LazyColumn(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          when (figureType) {
            "TOTAL_SALES" -> {
              val validBookings = bookings.filter { it.status != "CANCELLED" }
              item {
                Surface(color = Color(0xFFEFF6FF), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "कुल बुकिंग्स: ${validBookings.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
                    Text(text = "कुल बिक्री: ₹${String.format("%,.2f", validBookings.sumOf { it.totalAmount })}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = VyaparBlue)
                  }
                }
              }
              items(validBookings) { b ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFFF8FAFC),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      onDismiss()
                      onBookingClick(b)
                    }
                ) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(text = "${b.salutation} ${b.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                      Text(text = "${b.formattedDate} • ${b.invoiceNumber} • ${b.eventType}", fontSize = 10.sp, color = TextSecondary)
                      Text(text = "भुगतान: ${b.paymentMode} | एडवांस: ₹${b.advancePaid} | बाकी: ₹${b.balanceDue}", fontSize = 9.sp, color = Color(0xFF64748B))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                      Text(text = "₹${String.format("%,.0f", b.totalAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
                      Text(text = "इनवॉइस खोलें >", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VyaparBlue)
                    }
                  }
                }
              }
            }

            "NET_PROFIT" -> {
              val validBookings = bookings.filter { it.status != "CANCELLED" }
              val totalSales = validBookings.sumOf { it.totalAmount }
              val totalCost = validBookings.sumOf { it.estimatedCost }
              val netProfit = (totalSales - totalCost).coerceAtLeast(0.0)

              item {
                Surface(color = Color(0xFFDCFCE7), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                  Column(modifier = Modifier.padding(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                      Text(text = "राजस्व: ₹${String.format("%,.0f", totalSales)}", fontSize = 11.sp, color = Color(0xFF166534))
                      Text(text = "लागत: ₹${String.format("%,.0f", totalCost)}", fontSize = 11.sp, color = SoePrimary)
                    }
                    Text(text = "शुद्ध लाभ: ₹${String.format("%,.2f", netProfit)}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = VyaparDarkGreen)
                  }
                }
              }

              items(validBookings) { b ->
                val profit = (b.totalAmount - b.estimatedCost).coerceAtLeast(0.0)
                val margin = if (b.totalAmount > 0) ((profit / b.totalAmount) * 100).toInt() else 0
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFFF8FAFC),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      onDismiss()
                      onBookingClick(b)
                    }
                ) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(text = "${b.salutation} ${b.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                      Text(text = "${b.formattedDate} • ${b.invoiceNumber}", fontSize = 10.sp, color = TextSecondary)
                      Text(text = "बिल: ₹${b.totalAmount} | लागत: ₹${b.estimatedCost}", fontSize = 9.sp, color = Color(0xFF64748B))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                      Text(text = "+₹${String.format("%,.0f", profit)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
                      Text(text = "($margin% मार्जिन)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparDarkGreen)
                    }
                  }
                }
              }
            }

            "PURCHASES" -> {
              item {
                Surface(color = Color(0xFFFEF3C7), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "कुल खरीदी बिल: ${purchases.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                    Text(text = "कुल राशि: ₹${String.format("%,.2f", purchases.sumOf { it.totalAmount })}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color(0xFFB45309))
                  }
                }
              }
              items(purchases) { pur ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFFF8FAFC),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      onDismiss()
                      onPurchaseClick(pur)
                    }
                ) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(text = pur.vendorName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                      Text(text = "${pur.itemName} (${pur.quantity} ${pur.unit} @ ₹${pur.rate})", fontSize = 10.sp, color = TextSecondary)
                      Text(text = "बिल #${pur.billNumber} • ${pur.formattedDate}", fontSize = 9.sp, color = Color(0xFF64748B))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                      Text(text = "₹${String.format("%,.0f", pur.totalAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFFB45309))
                      Text(text = if (pur.dueAmount > 0) "बाकी: ₹${pur.dueAmount}" else "पूर्ण चुकता", fontSize = 9.sp, color = if (pur.dueAmount > 0) SoePrimary else VyaparGreen)
                    }
                  }
                }
              }
            }

            "EXPENSES" -> {
              item {
                Surface(color = Color(0xFFFFE4E6), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "कुल खर्चे प्रविष्टियां: ${expenses.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
                    Text(text = "कुल व्यय: ₹${String.format("%,.2f", expenses.sumOf { it.amount })}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = SoePrimary)
                  }
                }
              }
              items(expenses) { exp ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFFF8FAFC),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      onDismiss()
                      onExpenseClick(exp)
                    }
                ) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(text = exp.expenseTitle, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                      Text(text = "${exp.formattedDate} • श्रेणी: ${exp.category} • माध्यम: ${exp.paymentMode}", fontSize = 10.sp, color = TextSecondary)
                      if (exp.remarks.isNotBlank()) {
                        Text(text = "टिप्पणी: ${exp.remarks}", fontSize = 9.sp, color = Color(0xFF64748B))
                      }
                    }
                    Text(text = "- ₹${String.format("%,.0f", exp.amount)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = SoePrimary)
                  }
                }
              }
            }

            "RECEIVABLES" -> {
              val debtorBookings = bookings.filter { it.balanceDue > 0 && it.status != "CANCELLED" }
              item {
                Surface(color = Color(0xFFFFF1F2), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "बकायादार ग्राहक: ${debtorBookings.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
                    Text(text = "कुल बकाया: ₹${String.format("%,.2f", debtorBookings.sumOf { it.balanceDue })}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = SoePrimary)
                  }
                }
              }
              items(debtorBookings) { debtor ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFFF8FAFC),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      onDismiss()
                      onBookingClick(debtor)
                    }
                ) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(text = "${debtor.salutation} ${debtor.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                      Text(text = "📱 ${debtor.customerPhone} • इवेंट तिथि: ${debtor.formattedDate}", fontSize = 10.sp, color = TextSecondary)
                      Text(text = "कुल बिल: ₹${debtor.totalAmount} | प्राप्त एडवांस: ₹${debtor.advancePaid}", fontSize = 9.sp, color = Color(0xFF64748B))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                      Text(text = "₹${String.format("%,.0f", debtor.balanceDue)}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = SoePrimary)
                      Text(text = "बकाया शेष", fontSize = 9.sp, color = SoePrimary)
                    }
                  }
                }
              }
            }

            "STOCK_VALUATION" -> {
              val totalVal = items.sumOf { it.stock * it.purchaseCost }
              item {
                Surface(color = Color(0xFFEEF2FF), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "कुल इन्वेंट्री आइटम: ${items.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4338CA))
                    Text(text = "स्टॉक वैल्यू: ₹${String.format("%,.2f", totalVal)}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color(0xFF4338CA))
                  }
                }
              }
              items(items) { itm ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFFF8FAFC),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      onDismiss()
                      onItemClick(itm)
                    }
                ) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(text = itm.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                      Text(text = "उपलब्ध: ${itm.stock} ${itm.unit} • लागत: ₹${itm.purchaseCost} • रेट: ₹${itm.rate}", fontSize = 10.sp, color = TextSecondary)
                      Text(text = "कैटेगरी: ${itm.category} • SKU: ${itm.sku}", fontSize = 9.sp, color = Color(0xFF64748B))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                      Text(text = "₹${String.format("%,.0f", itm.stock * itm.purchaseCost)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFF4338CA))
                      Text(text = "स्टॉक मूल्य", fontSize = 9.sp, color = TextSecondary)
                    }
                  }
                }
              }
            }

            "ADVANCE_PAYMENTS" -> {
              val advanceBookings = bookings.filter { it.advancePaid > 0 }
              item {
                Surface(color = Color(0xFFF0FDF4), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "कुल एडवांस प्राप्तकर्ता: ${advanceBookings.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
                    Text(text = "कुल एडवांस: ₹${String.format("%,.2f", advanceBookings.sumOf { it.advancePaid })}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
                  }
                }
              }
              items(advanceBookings) { b ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFFF8FAFC),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      onDismiss()
                      onBookingClick(b)
                    }
                ) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(text = "${b.salutation} ${b.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                      Text(text = "बुकिंग: #${b.id} • माध्यम: ${b.paymentMode} • तारीख: ${b.formattedDate}", fontSize = 10.sp, color = TextSecondary)
                      Text(text = "कुल बिल: ₹${b.totalAmount} | बाकी: ₹${b.balanceDue}", fontSize = 9.sp, color = Color(0xFF64748B))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                      Text(text = "+₹${String.format("%,.0f", b.advancePaid)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
                      Text(text = "प्राप्त एडवांस", fontSize = 9.sp, color = VyaparDarkGreen)
                    }
                  }
                }
              }
            }

            "TOTAL_BOOKING_COST" -> {
              val validBookings = bookings.filter { it.status != "CANCELLED" }
              val totalCost = validBookings.sumOf { it.estimatedCost }
              item {
                Surface(color = Color(0xFFFEF3C7), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "कुल इवेंट्स: ${validBookings.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                    Text(text = "कुल लागत: ₹${String.format("%,.2f", totalCost)}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color(0xFFB45309))
                  }
                }
              }
              items(validBookings) { b ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFFF8FAFC),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                  modifier = Modifier.fillMaxWidth().clickable { onDismiss(); onBookingClick(b) }
                ) {
                  Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(text = "${b.salutation} ${b.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                      Text(text = "${b.formattedDate} • ${b.eventType}", fontSize = 10.sp, color = TextSecondary)
                      Text(text = "बिल: ₹${b.totalAmount} • अनुमानित लागत: ₹${b.estimatedCost}", fontSize = 9.sp, color = Color(0xFF64748B))
                    }
                    Text(text = "₹${String.format("%,.0f", b.estimatedCost)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFFB45309))
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Button(
          onClick = onDismiss,
          colors = ButtonDefaults.buttonColors(containerColor = headerColor),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(text = "बंद करें (Close)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
      }
    }
  }
}

// =========================================================================
// 2. EMPLOYEE MANAGEMENT MODALS (Requirement 4)
// =========================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEmployeeDialog(
  onDismiss: () -> Unit,
  onSave: (name: String, mobile: String, address: String, joiningDate: String, category: String, dailyWage: Double) -> Unit
) {
  var name by remember { mutableStateOf("") }
  var mobile by remember { mutableStateOf("") }
  var address by remember { mutableStateOf("उमरिया") }
  var joiningDate by remember { mutableStateOf("2026-11-10") }
  var dailyWage by remember { mutableStateOf("600") }
  val categories = listOf("साउंड व माइक ऑपरेटर", "लाइटिंग व पायरो कारीगर", "स्टेज डेकोरेटर व ट्रस फिटर", "लोडिंग व ट्रांसपोर्ट हेल्पर", "ड्राइवर", "मैनेजर व सुपरवाइजर")
  var category by remember { mutableStateOf(categories.first()) }
  var catExpanded by remember { mutableStateOf(false) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = Color.White,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text(text = "👷 नया कर्मचारी जोड़ें (Add Employee)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("कर्मचारी का पूरा नाम *") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        OutlinedTextField(
          value = mobile,
          onValueChange = { mobile = it },
          label = { Text("मोबाइल नंबर *") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        // Work Category Dropdown
        ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = it }) {
          OutlinedTextField(
            value = category,
            onValueChange = {},
            readOnly = true,
            label = { Text("कार्य पद / श्रेणी (Designation)") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catExpanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
          )
          ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
            categories.forEach { c ->
              DropdownMenuItem(
                text = { Text(c) },
                onClick = {
                  category = c
                  catExpanded = false
                }
              )
            }
          }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = dailyWage,
            onValueChange = { dailyWage = it },
            label = { Text("दैनिक मजदूरी दर (₹/दिन) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = joiningDate,
            onValueChange = { joiningDate = it },
            label = { Text("ज्वाइनिंग डेट") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        OutlinedTextField(
          value = address,
          onValueChange = { address = it },
          label = { Text("निवास पता") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
            Text("रद्द करें")
          }
          Button(
            onClick = {
              if (name.isNotBlank() && mobile.isNotBlank()) {
                val wage = dailyWage.toDoubleOrNull() ?: 600.0
                onSave(name.trim(), mobile.trim(), address.trim(), joiningDate.trim(), category, wage)
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("सुरक्षित करें")
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordAttendanceDialog(
  employees: List<EmployeeEntity>,
  bookings: List<BookingEntity>,
  onDismiss: () -> Unit,
  onSave: (empId: String, empName: String, date: String, formattedDate: String, status: String, dailyRate: Double, eventRef: String, notes: String) -> Unit
) {
  var selectedEmp by remember { mutableStateOf(employees.firstOrNull()) }
  var empExpanded by remember { mutableStateOf(false) }

  var date by remember { mutableStateOf("2026-11-10") }
  val statuses = listOf("PRESENT" to "पूर्ण दिवस (Present)", "HALF_DAY" to "आधा दिवस (Half Day)", "ABSENT" to "अनुपस्थित (Absent)", "LEAVE" to "छुट्टी (Leave)")
  var selectedStatus by remember { mutableStateOf("PRESENT") }

  var dailyRateInput by remember(selectedEmp) { mutableStateOf((selectedEmp?.dailyWage ?: 600.0).toString()) }
  var eventRef by remember { mutableStateOf(bookings.firstOrNull()?.let { "${it.customerName} (#${it.id})" } ?: "General Event") }
  var notes by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = Color.White,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text(text = "📅 कर्मचारी हाजिरी लगाएं (Attendance)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        // Employee Dropdown
        ExposedDropdownMenuBox(expanded = empExpanded, onExpandedChange = { empExpanded = it }) {
          OutlinedTextField(
            value = selectedEmp?.let { "${it.name} (${it.category})" } ?: "कर्मचारी चुनें",
            onValueChange = {},
            readOnly = true,
            label = { Text("कर्मचारी चुनें *") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = empExpanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
          )
          ExposedDropdownMenu(expanded = empExpanded, onDismissRequest = { empExpanded = false }) {
            employees.forEach { emp ->
              DropdownMenuItem(
                text = { Text("${emp.name} • ${emp.category} (₹${emp.dailyWage}/दिन)") },
                onClick = {
                  selectedEmp = emp
                  dailyRateInput = emp.dailyWage.toString()
                  empExpanded = false
                }
              )
            }
          }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = date,
            onValueChange = { date = it },
            label = { Text("तारीख (YYYY-MM-DD)") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = dailyRateInput,
            onValueChange = { dailyRateInput = it },
            label = { Text("दैनिक दर (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        // Status Selection Chips
        Text(text = "उपस्थिति स्थिति (Status):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          statuses.forEach { (code, label) ->
            val isSelected = selectedStatus == code
            val bg = when (code) {
              "PRESENT" -> if (isSelected) VyaparGreen else Color(0xFFDCFCE7)
              "HALF_DAY" -> if (isSelected) VyaparAmber else Color(0xFFFEF3C7)
              "ABSENT" -> if (isSelected) SoePrimary else Color(0xFFFFE4E6)
              else -> if (isSelected) Color(0xFF64748B) else Color(0xFFF1F5F9)
            }
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(bg)
                .clickable { selectedStatus = code }
                .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
              Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else Color.Black
              )
            }
          }
        }

        OutlinedTextField(
          value = eventRef,
          onValueChange = { eventRef = it },
          label = { Text("इवेंट / बुकिंग संदर्भ (Event Reference)") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("कार्य विवरण / टिप्पणी") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
            Text("रद्द करें")
          }
          Button(
            onClick = {
              if (selectedEmp != null) {
                val rate = dailyRateInput.toDoubleOrNull() ?: selectedEmp!!.dailyWage
                val fDate = date // simple format
                onSave(selectedEmp!!.employeeId, selectedEmp!!.name, date, fDate, selectedStatus, rate, eventRef, notes)
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = VyaparGreen),
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("हाजिरी दर्ज करें")
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordEmployeePaymentDialog(
  employees: List<EmployeeEntity>,
  bookings: List<BookingEntity>,
  onDismiss: () -> Unit,
  onSave: (empId: String, empName: String, date: String, formattedDate: String, amount: Double, mode: String, relatedEvent: String, ref: String, paymentType: String, notes: String) -> Unit
) {
  var selectedEmp by remember { mutableStateOf(employees.firstOrNull()) }
  var empExpanded by remember { mutableStateOf(false) }

  var date by remember { mutableStateOf("2026-11-10") }
  var amountInput by remember { mutableStateOf("") }
  var paymentMode by remember { mutableStateOf("CASH") }
  var relatedEvent by remember { mutableStateOf(bookings.firstOrNull()?.let { "${it.customerName} (#${it.id})" } ?: "दुकान/इवेंट") }
  var refNumber by remember { mutableStateOf("PAY-${System.currentTimeMillis() % 100000}") }
  var notes by remember { mutableStateOf("मजदूरी भुगतान") }
  var paymentType by remember { mutableStateOf("SALARY") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = Color.White,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text(text = "💰 कर्मचारी को मजदूरी/वेतन दें", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        // Employee Dropdown
        ExposedDropdownMenuBox(expanded = empExpanded, onExpandedChange = { empExpanded = it }) {
          OutlinedTextField(
            value = selectedEmp?.let { "${it.name} (${it.category})" } ?: "कर्मचारी चुनें",
            onValueChange = {},
            readOnly = true,
            label = { Text("कर्मचारी चुनें *") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = empExpanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
          )
          ExposedDropdownMenu(expanded = empExpanded, onDismissRequest = { empExpanded = false }) {
            employees.forEach { emp ->
              DropdownMenuItem(
                text = { Text("${emp.name} • ${emp.category}") },
                onClick = {
                  selectedEmp = emp
                  empExpanded = false
                }
              )
            }
          }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = amountInput,
            onValueChange = { amountInput = it },
            label = { Text("भुगतान राशि (₹) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
            singleLine = true
          )

          OutlinedTextField(
            value = date,
            onValueChange = { date = it },
            label = { Text("तारीख") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        // Payment Type & Mode
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("SALARY" to "वेतन/मजदूरी", "ADVANCE" to "एडवांस").forEach { (type, label) ->
            val isSel = paymentType == type
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSel) VyaparBlue else Color(0xFFF1F5F9))
                .clickable { paymentType = type }
                .padding(vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else TextPrimary)
            }
          }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("CASH" to "नकद (CASH)", "UPI" to "UPI / Online", "BANK" to "बैंक ट्रांसफर").forEach { (mode, label) ->
            val isSel = paymentMode == mode
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSel) VyaparGreen else Color(0xFFF1F5F9))
                .clickable { paymentMode = mode }
                .padding(vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else TextPrimary)
            }
          }
        }

        OutlinedTextField(
          value = relatedEvent,
          onValueChange = { relatedEvent = it },
          label = { Text("संबंधित इवेंट / संदर्भ") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("विवरण / नोट") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
            Text("रद्द करें")
          }
          Button(
            onClick = {
              val amt = amountInput.toDoubleOrNull() ?: 0.0
              if (selectedEmp != null && amt > 0) {
                onSave(selectedEmp!!.employeeId, selectedEmp!!.name, date, date, amt, paymentMode, relatedEvent, refNumber, paymentType, notes)
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = VyaparBlue),
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("पेमेंट दर्ज करें")
          }
        }
      }
    }
  }
}

@Composable
fun EmployeeDetailDialog(
  employee: EmployeeEntity,
  attendanceList: List<EmployeeAttendanceEntity>,
  paymentList: List<EmployeePaymentEntity>,
  onDismiss: () -> Unit,
  onRecordPaymentClick: () -> Unit,
  onCall: () -> Unit,
  onDeleteEmployee: () -> Unit
) {
  val empAttendance = remember(attendanceList, employee) {
    attendanceList.filter { it.employeeId == employee.employeeId }
  }
  val empPayments = remember(paymentList, employee) {
    paymentList.filter { it.employeeId == employee.employeeId }
  }

  val presentDays = empAttendance.count { it.status == "PRESENT" }
  val halfDays = empAttendance.count { it.status == "HALF_DAY" }
  val absentDays = empAttendance.count { it.status == "ABSENT" }
  val leaveDays = empAttendance.count { it.status == "LEAVE" }

  val totalEarnedSalary = empAttendance.sumOf {
    when (it.status) {
      "PRESENT" -> it.dailyRate
      "HALF_DAY" -> it.dailyRate * 0.5
      else -> 0.0
    }
  }
  val totalPaid = empPayments.sumOf { it.amount }
  val pendingSalary = (totalEarnedSalary - totalPaid).coerceAtLeast(0.0)

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .heightIn(max = 680.dp)
        .padding(vertical = 14.dp),
      shadowElevation = 8.dp
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .background(VyaparBlue.copy(alpha = 0.15f), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(imageVector = Icons.Default.Badge, contentDescription = null, tint = VyaparBlue, modifier = Modifier.size(24.dp))
            }
            Column {
              Text(text = employee.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
              Text(text = "${employee.employeeId} • ${employee.category} • ₹${employee.dailyWage}/दिन", fontSize = 11.sp, color = TextSecondary)
            }
          }
          IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Quick Stats & Salary KPI
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFFF8FAFC),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
              Text(text = "कुल अर्जित मजदूरी", fontSize = 10.sp, color = TextSecondary)
              Text(text = "₹${String.format("%,.0f", totalEarnedSalary)}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = TextPrimary)
            }
            Column {
              Text(text = "कुल भुगतान किया गया", fontSize = 10.sp, color = TextSecondary)
              Text(text = "₹${String.format("%,.0f", totalPaid)}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text(text = "शेष बकाया मजदूरी", fontSize = 10.sp, color = TextSecondary)
              Text(text = "₹${String.format("%,.0f", pendingSalary)}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = if (pendingSalary > 0) SoePrimary else VyaparGreen)
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Attendance Count Chips
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Box(modifier = Modifier.weight(1f).background(Color(0xFFDCFCE7), RoundedCornerShape(8.dp)).padding(6.dp), contentAlignment = Alignment.Center) {
            Text(text = "P: $presentDays दिन", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VyaparGreen)
          }
          Box(modifier = Modifier.weight(1f).background(Color(0xFFFEF3C7), RoundedCornerShape(8.dp)).padding(6.dp), contentAlignment = Alignment.Center) {
            Text(text = "HD: $halfDays दिन", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
          }
          Box(modifier = Modifier.weight(1f).background(Color(0xFFFFE4E6), RoundedCornerShape(8.dp)).padding(6.dp), contentAlignment = Alignment.Center) {
            Text(text = "A: $absentDays दिन", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SoePrimary)
          }
          Box(modifier = Modifier.weight(1f).background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp)).padding(6.dp), contentAlignment = Alignment.Center) {
            Text(text = "L: $leaveDays दिन", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Tabs of Work History vs Payment History
        var detailSubTab by remember { mutableStateOf("ATTENDANCE") }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = { detailSubTab = "ATTENDANCE" },
            colors = ButtonDefaults.buttonColors(containerColor = if (detailSubTab == "ATTENDANCE") VyaparBlue else Color(0xFFE2E8F0)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            Text("उपस्थिति इतिहास (${empAttendance.size})", fontSize = 11.sp, color = if (detailSubTab == "ATTENDANCE") Color.White else TextPrimary)
          }
          Button(
            onClick = { detailSubTab = "PAYMENTS" },
            colors = ButtonDefaults.buttonColors(containerColor = if (detailSubTab == "PAYMENTS") VyaparBlue else Color(0xFFE2E8F0)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            Text("पेमेंट रिकॉर्ड (${empPayments.size})", fontSize = 11.sp, color = if (detailSubTab == "PAYMENTS") Color.White else TextPrimary)
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          if (detailSubTab == "ATTENDANCE") {
            if (empAttendance.isEmpty()) {
              item { Text("कोई उपस्थिति रिकॉर्ड दर्ज नहीं है।", fontSize = 11.sp, color = TextSecondary) }
            } else {
              items(empAttendance) { att ->
                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFF8FAFC), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)), modifier = Modifier.fillMaxWidth()) {
                  Row(modifier = Modifier.padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                      Text(text = "${att.date} • ${att.eventReference}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      if (att.notes.isNotBlank()) Text(text = att.notes, fontSize = 9.sp, color = TextSecondary)
                    }
                    Text(
                      text = when (att.status) {
                        "PRESENT" -> "उपस्थित (+₹${att.dailyRate})"
                        "HALF_DAY" -> "आधा दिन (+₹${att.dailyRate * 0.5})"
                        "ABSENT" -> "अनुपस्थित (₹0)"
                        else -> "अवकाश"
                      },
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (att.status == "PRESENT") VyaparGreen else if (att.status == "HALF_DAY") VyaparAmber else SoePrimary
                    )
                  }
                }
              }
            }
          } else {
            if (empPayments.isEmpty()) {
              item { Text("कोई वेतन भुगतान रिकॉर्ड दर्ज नहीं है।", fontSize = 11.sp, color = TextSecondary) }
            } else {
              items(empPayments) { pay ->
                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFF0FDF4), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)), modifier = Modifier.fillMaxWidth()) {
                  Row(modifier = Modifier.padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                      Text(text = "${pay.paymentDate} • ${pay.paymentMode} • ${pay.paymentType}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      Text(text = "रेफरेंस: ${pay.paymentReference} • ${pay.notes}", fontSize = 9.sp, color = TextSecondary)
                    }
                    Text(text = "₹${String.format("%,.0f", pay.amount)}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Action Buttons: Call, Record Payment, Delete
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(
            onClick = onCall,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(imageVector = Icons.Default.Call, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("कॉल करें", fontSize = 11.sp)
          }

          Button(
            onClick = onRecordPaymentClick,
            colors = ButtonDefaults.buttonColors(containerColor = VyaparGreen),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1.3f)
          ) {
            Icon(imageVector = Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("वेतन दें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          IconButton(onClick = onDeleteEmployee, modifier = Modifier.size(38.dp)) {
            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = SoePrimary)
          }
        }
      }
    }
  }
}

// =========================================================================
// 3. ITEM PRICE HISTORY & COMPARISON MODAL (Requirement 3.D)
// =========================================================================

@Composable
fun ItemPriceComparisonModal(
  item: InventoryItemEntity,
  priceHistoryList: List<ItemPriceHistoryEntity>,
  onDismiss: () -> Unit
) {
  val historyForItem = remember(priceHistoryList, item) {
    priceHistoryList.filter { it.itemId == item.id }
  }

  val priceDiff = item.purchaseCost - item.previousPurchasePrice
  val isPriceHike = priceDiff > 0

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 600.dp)
        .padding(vertical = 12.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .background(Color(0xFFE0E7FF), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(imageVector = Icons.Default.Inventory2, contentDescription = null, tint = Color(0xFF4338CA), modifier = Modifier.size(20.dp))
            }
            Column {
              Text(text = item.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
              Text(text = "प्राइस हिस्ट्री व तुलना (Price Comparison)", fontSize = 10.sp, color = TextSecondary)
            }
          }
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Price Comparison Card
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = Color(0xFFF8FAFC),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Column {
                Text(text = "पिछला खरीदी रेट", fontSize = 10.sp, color = TextSecondary)
                Text(text = "₹${item.previousPurchasePrice}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
              }
              Column {
                Text(text = "वर्तमान खरीदी रेट", fontSize = 10.sp, color = TextSecondary)
                Text(text = "₹${item.purchaseCost}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color(0xFF4338CA))
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(text = "बाजार विक्रय दर", fontSize = 10.sp, color = TextSecondary)
                Text(text = "₹${item.rate}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = VyaparGreen)
              }
            }

            // Difference Banner
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (priceDiff > 0) Color(0xFFFFE4E6) else if (priceDiff < 0) Color(0xFFDCFCE7) else Color(0xFFF1F5F9),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = if (priceDiff > 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                    contentDescription = null,
                    tint = if (priceDiff > 0) SoePrimary else VyaparGreen,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = if (priceDiff > 0) "रेट में ₹${priceDiff} की वृद्धि" else if (priceDiff < 0) "रेट में ₹${-priceDiff} की कमी" else "रेट में कोई बदलाव नहीं",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (priceDiff > 0) SoePrimary else if (priceDiff < 0) VyaparGreen else TextPrimary
                  )
                }
                Text(text = "तारीख: ${item.priceChangeDate}", fontSize = 10.sp, color = TextSecondary)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(text = "पिछले खरीद बदलाव इतिहास (Timeline):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          if (historyForItem.isEmpty()) {
            item {
              Text(
                text = "वर्तमान दर ₹${item.purchaseCost} दर्ज है। नया पर्चेज बिल दर्ज करने पर इतिहास अपने आप जुड़ जाएगा।",
                fontSize = 11.sp,
                color = TextSecondary,
                modifier = Modifier.padding(vertical = 10.dp)
              )
            }
          } else {
            items(historyForItem) { hist ->
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFF8FAFC),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "${hist.changeFormattedDate} • ${hist.supplierName}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(text = "₹${hist.previousPrice} ➔ ₹${hist.newPrice}", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color(0xFF4338CA))
                  }
                  Text(text = "कारण: ${hist.reason}", fontSize = 9.sp, color = TextSecondary)
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Button(
          onClick = onDismiss,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4338CA)),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("बंद करें")
        }
      }
    }
  }
}
